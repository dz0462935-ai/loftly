import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../clothes.dart';
import '../models.dart';
import '../store.dart';
import '../ui.dart';
import '../widgets/avatar.dart';

/// Редактор персонажа: комната-фон, тело-«яйцо», нижняя панель с сеткой вещей,
/// вкладки «Гардероб / Наряды / Коллекции». Изменения копятся в черновике и
/// применяются (с покупкой недостающих вещей) по кнопке «Сохранить».
class CharacterEditorScreen extends StatefulWidget {
  const CharacterEditorScreen({super.key});

  @override
  State<CharacterEditorScreen> createState() => _CharacterEditorState();
}

const _cats = ['top', 'bottom', 'shoes', 'hair', 'hairc', 'hat', 'face'];
const _tabs = <(String, String?)>[
  ('Все', null),
  ('Топы', 'top'),
  ('Низ', 'bottom'),
  ('Обувь', 'shoes'),
  ('Волосы', 'hair'),
  ('Цвет волос', 'hairc'),
  ('Шляпы', 'hat'),
  ('Лицо', 'face'),
  ('Кожа', 'skin'),
];
const _catTitle = {
  'top': 'Топы',
  'bottom': 'Низ',
  'shoes': 'Обувь',
  'hair': 'Волосы',
  'hairc': 'Цвет волос',
  'hat': 'Шляпы',
  'face': 'Лицо',
  'skin': 'Кожа',
};

class _Opt {
  final String cat;
  final ShopItem? item;
  final int skin;
  const _Opt(this.cat, {this.item, this.skin = 0});
  String get id => item?.id ?? 'skin$skin';
  String get name => item?.name ?? 'Тон ${skin + 1}';
}

class _Snap {
  final Map<String, String?> sel;
  final int skin;
  const _Snap(this.sel, this.skin);
  @override
  bool operator ==(Object o) =>
      o is _Snap && o.skin == skin && o.sel.length == sel.length && sel.entries.every((e) => o.sel[e.key] == e.value);
  @override
  int get hashCode => Object.hash(skin, sel.length);
}

class _CharacterEditorState extends State<CharacterEditorScreen> {
  late final AppStore store = StoreScope.of(context);
  final Map<String, ShopItem> _byId = {};
  late _Snap _base;
  final List<_Snap> _hist = [];
  int _hi = 0;
  int _tab = 0; // вкладка категории
  int _page = 0; // 0 гардероб, 1 наряды, 2 коллекции
  int _filter = 0; // 0 все, 1 мои, 2 не куплено
  bool _search = false;
  String _q = '';
  bool _back = false;
  bool _clothes = true;
  bool _photo = false;
  int _zoom = 1;
  List<String> _outfits = [];
  bool _ready = false;

  _Snap get _cur => _hist[_hi];
  bool get _dirty => _cur != _base;
  bool get _offline => store.api == null;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_ready) return;
    _ready = true;
    for (final it in store.shop) {
      if (_cats.contains(it.cat) && (!it.custom || it.cat == 'face')) _byId[it.id] = it;
    }
    final sel = <String, String?>{for (final c in _cats) c: null};
    for (final it in _byId.values) {
      if (store.isEquipped(it)) sel[it.cat] = it.id;
    }
    final skin = math.max(0, skinTones.indexOf(store.me.skin));
    _base = _Snap(sel, skin);
    _hist.add(_base);
    SharedPreferences.getInstance().then((p) {
      if (mounted) setState(() => _outfits = p.getStringList('loftly_outfits') ?? []);
    }).catchError((_) {});
  }

  // ---------- черновик ----------

  void _push(Map<String, String?> sel, int skin) {
    final s = _Snap(sel, skin);
    if (s == _cur) return;
    setState(() {
      _hist.removeRange(_hi + 1, _hist.length);
      _hist.add(s);
      _hi = _hist.length - 1;
    });
  }

  void _pick(_Opt o) {
    final sel = Map<String, String?>.of(_cur.sel);
    if (o.cat == 'skin') return _push(sel, o.skin);
    sel[o.cat] = ((o.cat == 'hat' || o.cat == 'face') && sel[o.cat] == o.id) ? null : o.id;
    _push(sel, _cur.skin);
  }

  User _user(_Snap s) {
    final me = store.me;
    final u = User(
      id: 'draft',
      name: '',
      skin: skinTones[s.skin % skinTones.length],
      top: me.top,
      bottom: me.bottom,
      shoes: me.shoes,
      hairColor: me.hairColor,
      hair: me.hair,
    );
    for (final e in s.sel.entries) {
      final it = e.value == null ? null : _byId[e.value];
      if (it == null) continue;
      switch (it.cat) {
        case 'top':
          u.top = it.color!;
        case 'bottom':
          u.bottom = it.color!;
        case 'shoes':
          u.shoes = it.color!;
        case 'hair':
          u.hair = it.index;
        case 'hairc':
          u.hairColor = it.color!;
        case 'hat':
          u.hat = it.index;
        case 'face':
          u.custom['face'] = it.id;
      }
    }
    return u;
  }

  List<ShopItem> get _changed {
    final out = <ShopItem>[];
    for (final c in _cats) {
      final id = _cur.sel[c];
      if (id != null && id != _base.sel[c]) out.add(_byId[id]!);
    }
    return out;
  }

  int _cost(bool gems) =>
      _changed.where((i) => !store.owns(i) && i.gems == gems).fold(0, (a, i) => a + i.price);

  // ---------- действия ----------

  Future<void> _save() async {
    if (!_dirty) return;
    final items = _changed;
    final coins = _cost(false), gems = _cost(true);
    if (coins > store.me.coins || gems > store.me.gems) {
      store.toast(gems > store.me.gems ? 'Не хватает кристаллов 💎' : 'Не хватает монет 🪙');
      return;
    }
    if (coins + gems > 0) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Купить и надеть?'),
          content: Text('Новых вещей: ${items.where((i) => !store.owns(i)).length}\n'
              '${coins > 0 ? '🪙 $coins  ' : ''}${gems > 0 ? '💎 $gems' : ''}'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Купить')),
          ],
        ),
      );
      if (ok != true) return;
    }
    await store.applyLook(
      items,
      noHat: _cur.sel['hat'] == null && _base.sel['hat'] != null,
      noFace: _cur.sel['face'] == null && _base.sel['face'] != null,
      skin: _cur.skin != _base.skin ? _cur.skin : null,
    );
    if (!mounted) return;
    store.toast('Образ сохранён ✨');
    Navigator.of(context).pop();
  }

  Future<void> _confirmExit() async {
    final leave = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Выйти без сохранения?'),
        content: const Text('Изменения образа пропадут.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Остаться')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Выйти')),
        ],
      ),
    );
    if (leave == true && mounted) Navigator.of(context).pop();
  }

  /// OOTD — случайный образ из того, что уже куплено.
  void _ootd() {
    final r = math.Random();
    final sel = Map<String, String?>.of(_cur.sel);
    for (final c in _cats) {
      final own = _byId.values.where((i) => i.cat == c && store.owns(i)).toList();
      if (own.isEmpty) continue;
      if (c == 'hat' && r.nextBool()) {
        sel[c] = null;
      } else {
        sel[c] = own[r.nextInt(own.length)].id;
      }
    }
    _push(sel, _cur.skin);
  }

  Future<void> _saveOutfit() async {
    if (_outfits.length >= 11) return store.toast('Максимум 11 нарядов');
    final s = _cur;
    _outfits = [..._outfits, jsonEncode({'sel': s.sel, 'skin': s.skin})];
    setState(() {});
    try {
      (await SharedPreferences.getInstance()).setStringList('loftly_outfits', _outfits);
    } catch (_) {}
  }

  Future<void> _delOutfit(int i) async {
    _outfits = [..._outfits]..removeAt(i);
    setState(() {});
    try {
      (await SharedPreferences.getInstance()).setStringList('loftly_outfits', _outfits);
    } catch (_) {}
  }

  _Snap? _decode(String s) {
    try {
      final m = jsonDecode(s) as Map<String, dynamic>;
      final sel = <String, String?>{for (final c in _cats) c: null};
      (m['sel'] as Map<String, dynamic>).forEach((k, v) {
        // вещь могла пропасть из магазина — тогда слот остаётся пустым
        if (sel.containsKey(k) && (v == null || _byId.containsKey(v))) sel[k] = v as String?;
      });
      return _Snap(sel, (m['skin'] as int?) ?? 0);
    } catch (_) {
      return null;
    }
  }

  // ---------- список вещей ----------

  List<_Opt> _options(String? cat) {
    final out = <_Opt>[];
    for (final c in [..._cats, 'skin']) {
      if (cat != null && cat != c) continue;
      if (c == 'skin') {
        if (_offline) out.addAll([for (var i = 0; i < skinTones.length; i++) _Opt('skin', skin: i)]);
      } else {
        out.addAll([for (final it in _byId.values.where((i) => i.cat == c)) _Opt(c, item: it)]);
      }
    }
    return out.where((o) {
      final it = o.item;
      if (_filter == 1 && it != null && !store.owns(it)) return false;
      if (_filter == 2 && (it == null || store.owns(it))) return false;
      if (_q.isNotEmpty && !o.name.toLowerCase().contains(_q.toLowerCase())) return false;
      return true;
    }).toList();
  }

  bool _isSel(_Opt o) => o.cat == 'skin' ? _cur.skin == o.skin : _cur.sel[o.cat] == o.id;

  // ---------- интерфейс ----------

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final u = _user(_cur);
    return PopScope(
      canPop: !_dirty,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _confirmExit();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF121118),
        body: Column(
          children: [
            Expanded(
              child: Stack(
                children: [
                  const Positioned.fill(child: CustomPaint(painter: _RoomPainter())),
                  Positioned.fill(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 90, bottom: 8),
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: AnimatedScale(
                          duration: const Duration(milliseconds: 200),
                          scale: const [0.85, 1.0, 1.12][_zoom],
                          alignment: Alignment.bottomCenter,
                          child: AspectRatio(
                            aspectRatio: 104 / 320,
                            child: AnimatedSwitcher(
                              duration: const Duration(milliseconds: 180),
                              child: _Doll(
                                key: ValueKey(_back),
                                u: u,
                                back: _back,
                                clothes: _clothes,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(14, 8, 14, 0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _RoundBtn(Icons.close_rounded, () {
                            if (_dirty) {
                              _confirmExit();
                            } else {
                              Navigator.pop(context);
                            }
                          }),
                          const Spacer(),
                          _SaveBtn(
                            enabled: _dirty,
                            coins: _cost(false),
                            gems: _cost(true),
                            onTap: _save,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    right: 14,
                    top: MediaQuery.of(context).padding.top + 64,
                    child: Column(
                      children: [
                        _RoundBtn(Icons.photo_camera_rounded, () => setState(() => _photo = !_photo)),
                        const SizedBox(height: 10),
                        _RoundBtn(Icons.checkroom_rounded, _ootd, label: 'OOTD'),
                      ],
                    ),
                  ),
                  Positioned(
                    left: 14,
                    bottom: 24,
                    child: Column(
                      children: [
                        _RoundBtn(Icons.height_rounded, () => setState(() => _zoom = (_zoom + 1) % 3)),
                        const SizedBox(height: 10),
                        _RoundBtn(
                          Icons.layers_rounded,
                          () => setState(() => _clothes = !_clothes),
                          active: !_clothes,
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    right: 14,
                    bottom: 24,
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      decoration: BoxDecoration(
                        color: Ui.a(Colors.black, .45),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Column(
                        children: [
                          IconButton(
                            onPressed: _hi > 0 ? () => setState(() => _hi--) : null,
                            icon: const Icon(Icons.undo_rounded),
                          ),
                          IconButton(
                            onPressed: _hi < _hist.length - 1 ? () => setState(() => _hi++) : null,
                            icon: const Icon(Icons.redo_rounded),
                          ),
                          IconButton(
                            onPressed: () => setState(() => _back = !_back),
                            icon: const Icon(Icons.flip_camera_android_rounded),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (!_photo) SizedBox(height: h * 0.46, child: _panel()),
          ],
        ),
      ),
    );
  }

  Widget _panel() {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF15141C),
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          children: [
            Container(
              width: 44,
              height: 5,
              margin: const EdgeInsets.only(top: 10, bottom: 6),
              decoration: BoxDecoration(color: Ui.a(Colors.white, .25), borderRadius: BorderRadius.circular(3)),
            ),
            if (_page == 0) _chips(),
            Expanded(child: [_wardrobe, _outfitsPage, _collections][_page]()),
            _bottomNav(),
          ],
        ),
      ),
    );
  }

  Widget _chips() {
    return Column(
      children: [
        SizedBox(
          height: 46,
          child: Row(
            children: [
              Expanded(
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  itemCount: _tabs.length,
                  itemBuilder: (_, i) => GestureDetector(
                    onTap: () => setState(() => _tab = i),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Center(
                        child: Text(
                          _tabs[i].$1,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: i == _tab ? Colors.white : Ui.a(Colors.white, .45),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              IconButton(
                onPressed: () {
                  setState(() => _filter = (_filter + 1) % 3);
                  store.toast(const ['Все вещи', 'Только мои', 'Не куплено'][_filter]);
                },
                icon: Icon(Icons.filter_alt_rounded, color: _filter == 0 ? null : Ui.accent),
              ),
              IconButton(
                onPressed: () => setState(() {
                  _search = !_search;
                  if (!_search) _q = '';
                }),
                icon: Icon(Icons.search_rounded, color: _search ? Ui.accent : null),
              ),
            ],
          ),
        ),
        if (_search)
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 6),
            child: SizedBox(
              height: 38,
              child: TextField(
                autofocus: true,
                onChanged: (v) => setState(() => _q = v),
                decoration: InputDecoration(
                  hintText: 'Поиск вещи',
                  isDense: true,
                  filled: true,
                  fillColor: Ui.a(Colors.white, .08),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                ),
              ),
            ),
          ),
        Divider(height: 1, color: Ui.a(Colors.white, .08)),
      ],
    );
  }

  Widget _wardrobe() {
    final list = _options(_tabs[_tab].$2);
    if (list.isEmpty) {
      return const Center(child: Text('Ничего не найдено', style: TextStyle(color: Ui.dim)));
    }
    return GridView.builder(
      padding: const EdgeInsets.all(10),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
      ),
      itemCount: list.length,
      itemBuilder: (_, i) => _tile(list[i]),
    );
  }

  Widget _tile(_Opt o) {
    final it = o.item;
    final sel = _isSel(o);
    final owned = it == null || store.owns(it);
    return GestureDetector(
      onTap: () => _pick(o),
      onLongPress: () => store.toast(o.name),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        decoration: BoxDecoration(
          gradient: _rarity(it),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: sel ? Colors.white : Ui.a(Colors.white, .35), width: sel ? 3 : 1.5),
          boxShadow: sel ? [BoxShadow(color: Ui.a(Ui.accent, .6), blurRadius: 10)] : null,
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          fit: StackFit.expand,
          children: [
            _Thumb(o: o, base: _user(_cur)),
            if (!owned && it != null)
              Positioned(
                top: 4,
                right: 4,
                child: _Chip(it.gems ? '💎${it.price}' : '🪙${it.price}'),
              ),
            if (sel && o.cat != 'skin')
              const Positioned(
                bottom: 4,
                right: 4,
                child: Icon(Icons.check_circle_rounded, size: 18, color: Colors.white),
              ),
          ],
        ),
      ),
    );
  }

  Widget _outfitsPage() {
    return GridView.builder(
      padding: const EdgeInsets.all(10),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
      ),
      itemCount: _outfits.length + 1,
      itemBuilder: (_, i) {
        if (i == 0) {
          return GestureDetector(
            onTap: _saveOutfit,
            child: Container(
              decoration: BoxDecoration(
                color: Ui.a(Colors.white, .07),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Ui.a(Colors.white, .3)),
              ),
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.add_rounded, size: 30),
                  Text('Сохранить\nнаряд', textAlign: TextAlign.center, style: TextStyle(fontSize: 11)),
                ],
              ),
            ),
          );
        }
        final snap = _decode(_outfits[i - 1]);
        return GestureDetector(
          onTap: snap == null ? null : () => _push(snap.sel, snap.skin),
          onLongPress: () => _delOutfit(i - 1),
          child: Container(
            decoration: BoxDecoration(
              gradient: _rarity(null),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Ui.a(Colors.white, .35)),
            ),
            padding: const EdgeInsets.all(4),
            child: snap == null
                ? const SizedBox()
                : FittedBox(child: AvatarFigure(user: _user(snap), size: 80)),
          ),
        );
      },
    );
  }

  Widget _collections() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 6, 14, 10),
      children: [
        for (final c in _cats) ...[
          Builder(builder: (_) {
            final all = _options(c);
            final have = all.where((o) => store.owns(o.item!)).length;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 8, bottom: 4),
                  child: Row(
                    children: [
                      Text(_catTitle[c]!, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                      const Spacer(),
                      Text('$have / ${all.length}', style: const TextStyle(color: Ui.dim)),
                    ],
                  ),
                ),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: all.isEmpty ? 0 : have / all.length,
                    minHeight: 6,
                    color: Ui.accent,
                    backgroundColor: Ui.a(Colors.white, .1),
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  height: 56,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: all.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 6),
                    itemBuilder: (_, i) {
                      final o = all[i];
                      return GestureDetector(
                        onTap: () => setState(() {
                          _tab = _tabs.indexWhere((t) => t.$2 == c);
                          _page = 0;
                          _pick(o);
                        }),
                        child: Opacity(
                          opacity: store.owns(o.item!) ? 1 : .4,
                          child: Container(
                            width: 56,
                            clipBehavior: Clip.antiAlias,
                            decoration: BoxDecoration(
                              gradient: _rarity(o.item),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: _Thumb(o: o, base: _user(_cur)),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          }),
        ],
      ],
    );
  }

  Widget _bottomNav() {
    const names = ['Гардероб', 'Наряды', 'Коллекции'];
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 4, 14, 8),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(color: Ui.a(Colors.white, .07), borderRadius: BorderRadius.circular(18)),
      child: Row(
        children: [
          for (var i = 0; i < 3; i++)
            Expanded(
              child: GestureDetector(
                onTap: () => setState(() => _page = i),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 11),
                  decoration: BoxDecoration(
                    color: i == _page ? Ui.a(Colors.white, .14) : Colors.transparent,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(
                    names[i],
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                      color: i == _page ? Colors.white : Ui.a(Colors.white, .55),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ---------- мелкие виджеты ----------

LinearGradient _rarity(ShopItem? it) {
  List<Color> c;
  if (it == null || it.price == 0 && !it.gems) {
    c = const [Color(0xFFB5E8FF), Color(0xFFFFD6F5), Color(0xFFD9C8FF), Color(0xFFBFFFE6), Color(0xFFFFF0B8)];
  } else if (it.gems || it.price >= 120) {
    c = const [Color(0xFFF2A81D), Color(0xFFC77A06)];
  } else {
    c = const [Color(0xFFA21FE0), Color(0xFF6A12C8)];
  }
  return LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: c);
}

class _RoundBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final String? label;
  final bool active;
  const _RoundBtn(this.icon, this.onTap, {this.label, this.active = false});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: active ? Ui.a(Ui.accent, .8) : Ui.a(Colors.black, .45),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Icon(icon, size: 26),
          ),
          if (label != null)
            Text(label!, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _SaveBtn extends StatelessWidget {
  final bool enabled;
  final int coins, gems;
  final VoidCallback onTap;
  const _SaveBtn({required this.enabled, required this.coins, required this.gems, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final price = [if (coins > 0) '🪙$coins', if (gems > 0) '💎$gems'].join(' ');
    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: Container(
        height: 52,
        padding: const EdgeInsets.symmetric(horizontal: 22),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: enabled ? Ui.brand : null,
          color: enabled ? null : Ui.a(Colors.black, .45),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Text(
          price.isEmpty ? 'Сохранить' : 'Сохранить · $price',
          style: TextStyle(
            fontSize: 17,
            fontWeight: FontWeight.w800,
            color: enabled ? Colors.white : Ui.a(Colors.white, .4),
          ),
        ),
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String text;
  const _Chip(this.text);

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
        decoration: BoxDecoration(color: Ui.a(Colors.black, .55), borderRadius: BorderRadius.circular(8)),
        child: Text(text, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800)),
      );
}

/// Миниатюра вещи: приближенный фрагмент персонажа с этой вещью.
class _Thumb extends StatelessWidget {
  final _Opt o;
  final User base;
  const _Thumb({required this.o, required this.base});

  @override
  Widget build(BuildContext context) {
    final it = o.item;
    if (it != null && it.custom) {
      return LayoutBuilder(
        builder: (_, c) => Center(child: ClothThumb(id: it.id, slot: it.cat, size: c.biggest.shortestSide * .82)),
      );
    }
    final u = User(
      id: 't',
      name: '',
      skin: o.cat == 'skin' ? skinTones[o.skin] : base.skin,
      top: base.top,
      bottom: base.bottom,
      shoes: base.shoes,
      hairColor: base.hairColor,
      hair: base.hair == 0 ? 1 : base.hair,
    );
    if (it != null) {
      switch (it.cat) {
        case 'top':
          u.top = it.color!;
        case 'bottom':
          u.bottom = it.color!;
        case 'shoes':
          u.shoes = it.color!;
        case 'hair':
          u.hair = it.index;
        case 'hairc':
          u.hairColor = it.color!;
        case 'hat':
          u.hat = it.index;
          u.hair = base.hair == 0 ? 1 : base.hair;
      }
    }
    return CustomPaint(painter: _ThumbPainter(u, o.cat));
  }
}

class _ThumbPainter extends CustomPainter {
  final User u;
  final String cat;
  _ThumbPainter(this.u, this.cat);

  @override
  void paint(Canvas canvas, Size s) {
    // (масштаб относительно ширины, y центра кадра в координатах персонажа)
    final (z, cy) = switch (cat) {
      'top' => (34.0, -57.0),
      'bottom' => (28.0, -28.0),
      'shoes' => (26.0, -5.5),
      'hat' => (50.0, -108.0),
      _ => (46.0, -97.0),
    };
    final k = s.width / z;
    canvas.clipRect(Offset.zero & s);
    paintAvatar(canvas, u, Offset(s.width / 2, s.height / 2 - cy * k), k);
  }

  @override
  bool shouldRepaint(_ThumbPainter old) => true;
}

// ---------- тело и одежда на базовой модели ----------

class _Doll extends StatelessWidget {
  final User u;
  final bool back, clothes;
  const _Doll({super.key, required this.u, required this.back, required this.clothes});

  @override
  Widget build(BuildContext context) => FittedBox(
        child: SizedBox(
          width: 104,
          height: 320,
          child: CustomPaint(painter: _DollPainter(u, back, clothes)),
        ),
      );
}

class _DollPainter extends CustomPainter {
  final User u;
  final bool back, clothes;
  _DollPainter(this.u, this.back, this.clothes);

  @override
  void paint(Canvas c, Size size) => paintDoll(c, u, back: back, clothes: clothes);

  @override
  bool shouldRepaint(_DollPainter old) => true;
}

// ---------- фон: ночная комната ----------

class _RoomPainter extends CustomPainter {
  const _RoomPainter();

  @override
  void paint(Canvas c, Size s) {
    final p = Paint()..isAntiAlias = true;
    final w = s.width, h = s.height;
    // стена
    p.shader = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0xFFC96F7C), Color(0xFF8E4A63)],
    ).createShader(Offset.zero & s);
    c.drawRect(Offset.zero & s, p);
    p.shader = null;
    // окно с ночным небом
    final win = Rect.fromLTWH(w * .2, h * .08, w * .6, h * .34);
    p.shader = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0xFF1A2A6C), Color(0xFF3F6BC4)],
    ).createShader(win);
    c.drawRRect(RRect.fromRectAndRadius(win, const Radius.circular(6)), p);
    p.shader = null;
    p.color = Ui.a(Colors.white, .75);
    final r = math.Random(7);
    for (var i = 0; i < 22; i++) {
      c.drawCircle(
        Offset(win.left + r.nextDouble() * win.width, win.top + r.nextDouble() * win.height * .7),
        r.nextDouble() * 1.4 + .4,
        p,
      );
    }
    p.color = Ui.a(const Color(0xFF0E1B4A), .55);
    c.drawOval(Rect.fromLTWH(win.left - 10, win.bottom - 60, win.width * .55, 90), p);
    c.drawOval(Rect.fromLTWH(win.center.dx, win.bottom - 50, win.width * .6, 80), p);
    final fr = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6
      ..color = const Color(0xFFF3E6EA);
    c.drawRRect(RRect.fromRectAndRadius(win, const Radius.circular(6)), fr);
    c.drawLine(Offset(win.center.dx, win.top), Offset(win.center.dx, win.bottom), fr..strokeWidth = 4);
    c.drawLine(Offset(win.left, win.center.dy), Offset(win.right, win.center.dy), fr);
    // шторы
    p.color = const Color(0xFFD9606E);
    for (final left in [true, false]) {
      final x = left ? 0.0 : w * .84;
      c.drawPath(
        Path()
          ..moveTo(x, 0)
          ..lineTo(x + w * .16, 0)
          ..quadraticBezierTo(x + w * (left ? .08 : .0), h * .3, x + w * (left ? .14 : .02), h * .55)
          ..lineTo(x, h * .55)
          ..close(),
        p,
      );
    }
    // гирлянда
    p.color = const Color(0xFFFFE6A8);
    for (var i = 0; i < 14; i++) {
      c.drawCircle(Offset(w * i / 13, h * .03 + math.sin(i * 1.3) * 5 + (i.isEven ? 6 : 0)), 2.6, p);
    }
    // кровать
    p.color = const Color(0xFFD9707B);
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(-10, h * .55, w * .95, h * .3), const Radius.circular(14)), p);
    p.color = const Color(0xFFF1A0A6);
    c.drawOval(Rect.fromLTWH(w * .02, h * .5, w * .3, h * .1), p);
    // пол
    final fl = Rect.fromLTWH(0, h * .8, w, h * .2);
    p.shader = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0xFF6A3B2A), Color(0xFF4A2619)],
    ).createShader(fl);
    c.drawRect(fl, p);
    p.shader = null;
    p.color = const Color(0x22000000);
    for (var i = 1; i < 7; i++) {
      c.drawRect(Rect.fromLTWH(0, fl.top + fl.height * i / 7, w, 1.5), p);
    }
    // пол-тень под персонажем
    p.color = const Color(0x44000000);
    c.drawOval(Rect.fromCenter(center: Offset(w / 2, h - 10), width: w * .42, height: 22), p);
  }

  @override
  bool shouldRepaint(_RoomPainter old) => false;
}
