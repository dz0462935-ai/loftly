import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'api.dart';

/// Слот одежды, который можно нарисовать в студии.
/// [area] — прямоугольник на теле в условных единицах аватара (ноги в точке 0,0, вверх — минус).
/// Картинка рисуется в [w]×[h] пикселей, то есть по 2 пикселя на единицу.
class ClothSpec {
  final String slot;
  final String title;
  final int w;
  final int h;
  final Rect area;
  const ClothSpec(this.slot, this.title, this.w, this.h, this.area);
}

const Map<String, ClothSpec> clothSpecs = {
  'top': ClothSpec('top', 'Верх', 60, 64, Rect.fromLTRB(-15, -56, 15, -24)),
  'bottom': ClothSpec('bottom', 'Низ', 48, 48, Rect.fromLTRB(-12, -32, 12, -8)),
  'shoes': ClothSpec('shoes', 'Обувь', 48, 24, Rect.fromLTRB(-12, -11, 12, 1)),
  'hat': ClothSpec('hat', 'Шляпа', 120, 100, Rect.fromLTRB(-30, -120, 30, -70)),
};

const List<String> clothSlots = ['top', 'bottom', 'shoes', 'hat'];

final RegExp _customId = RegExp(r'^c\d{1,9}$');

/// Вещь из студии (в отличие от встроенных top0, hat1 и т.п.).
bool isCustomId(String? id) => id != null && _customId.hasMatch(id);

/// Собирает картинку из RGBA-байтов.
Future<ui.Image> imageFromPixels(Uint8List rgba, int w, int h) {
  final c = Completer<ui.Image>();
  ui.decodeImageFromPixels(rgba, w, h, ui.PixelFormat.rgba8888, c.complete);
  return c.future;
}

/// Кэш картинок одежды. Картинки других игроков подгружаются с сервера по мере надобности.
class ClothesCache extends ChangeNotifier {
  ApiClient? api;
  final Map<String, ui.Image> _images = {};
  final Map<String, Color> _avg = {};
  final Set<String> _pending = {};
  final Set<String> _failed = {};

  /// Картинка вещи или null, пока она не загружена (тогда запускается загрузка).
  ui.Image? image(String id) {
    final img = _images[id];
    if (img != null) return img;
    if (api != null && isCustomId(id) && !_pending.contains(id) && !_failed.contains(id)) {
      _fetch(id);
    }
    return null;
  }

  /// Средний цвет вещи — им закрашиваются рукава, штанины и т.п.
  Color? average(String id) => _avg[id];

  Future<void> _fetch(String id) async {
    final a = api;
    if (a == null) return;
    _pending.add(id);
    try {
      final r = await a.cloth(id);
      await putPng(id, base64Decode(r['png'] as String));
    } catch (_) {
      _failed.add(id);
    } finally {
      _pending.remove(id);
    }
  }

  /// Забыть вещь (например, после замены картинки админом).
  void forget(String id) {
    _images.remove(id);
    _avg.remove(id);
    _failed.remove(id);
    notifyListeners();
  }

  Future<void> putPng(String id, Uint8List bytes) async {
    final codec = await ui.instantiateImageCodec(bytes);
    final frame = await codec.getNextFrame();
    await putImage(id, frame.image);
  }

  Future<void> putImage(String id, ui.Image img) async {
    final color = await _averageColor(img);
    _images[id] = img;
    if (color != null) {
      _avg[id] = color;
    } else {
      _avg.remove(id);
    }
    notifyListeners();
  }

  static Future<Color?> _averageColor(ui.Image img) async {
    final data = await img.toByteData(format: ui.ImageByteFormat.rawRgba);
    if (data == null) return null;
    var r = 0, g = 0, b = 0, n = 0;
    for (var i = 0; i + 3 < data.lengthInBytes; i += 4) {
      if (data.getUint8(i + 3) < 128) continue;
      r += data.getUint8(i);
      g += data.getUint8(i + 1);
      b += data.getUint8(i + 2);
      n++;
    }
    if (n == 0) return null;
    return Color.fromARGB(255, r ~/ n, g ~/ n, b ~/ n);
  }
}

/// Единый кэш на всё приложение: рисование аватара — обычная функция без контекста.
final ClothesCache clothesCache = ClothesCache();

/// Рисует слой одежды на аватаре. [dx], [dy] — смещение (для шагающих ног).
/// [part] — какую половину картинки нарисовать: 0 — всю, 1 — левую, 2 — правую.
void paintClothLayer(Canvas canvas, String slot, ui.Image img,
    {double dx = 0, double dy = 0, int part = 0}) {
  final spec = clothSpecs[slot]!;
  final w = img.width.toDouble();
  final h = img.height.toDouble();
  final area = spec.area.shift(Offset(dx, dy));
  Rect src = Rect.fromLTWH(0, 0, w, h);
  Rect dst = area;
  if (part == 1) {
    src = Rect.fromLTWH(0, 0, w / 2, h);
    dst = Rect.fromLTRB(area.left, area.top, area.center.dx, area.bottom);
  } else if (part == 2) {
    src = Rect.fromLTWH(w / 2, 0, w / 2, h);
    dst = Rect.fromLTRB(area.center.dx, area.top, area.right, area.bottom);
  }
  canvas.drawImageRect(img, src, dst, Paint()..filterQuality = FilterQuality.low);
}

/// Миниатюра вещи (магазин, список в студии).
class ClothThumb extends StatelessWidget {
  final String id;
  final String slot;
  final double size;
  const ClothThumb({super.key, required this.id, required this.slot, this.size = 40});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: clothesCache,
      builder: (context, _) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: Colors.black12,
          borderRadius: BorderRadius.circular(8),
        ),
        child: CustomPaint(painter: _ThumbPainter(clothesCache.image(id))),
      ),
    );
  }
}

class _ThumbPainter extends CustomPainter {
  final ui.Image? img;
  _ThumbPainter(this.img);

  @override
  void paint(Canvas canvas, Size size) {
    final i = img;
    if (i == null) return;
    final iw = i.width.toDouble();
    final ih = i.height.toDouble();
    final s = (size.width - 6) / iw < (size.height - 6) / ih ? (size.width - 6) / iw : (size.height - 6) / ih;
    final dst = Rect.fromCenter(center: size.center(Offset.zero), width: iw * s, height: ih * s);
    canvas.drawImageRect(i, Rect.fromLTWH(0, 0, iw, ih), dst, Paint()..filterQuality = FilterQuality.low);
  }

  @override
  bool shouldRepaint(_ThumbPainter old) => old.img != img;
}
