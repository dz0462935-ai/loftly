import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../ui.dart';
import '../widgets/avatar.dart';
import '../widgets/iso.dart';
import 'room_screen.dart';

enum _Filter { all, mine, friends }

class RoomsTab extends StatefulWidget {
  const RoomsTab({super.key});

  @override
  State<RoomsTab> createState() => _RoomsTabState();
}

class _RoomsTabState extends State<RoomsTab> {
  _Filter _filter = _Filter.all;

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    var rooms = [...store.rooms];
    switch (_filter) {
      case _Filter.all:
        break;
      case _Filter.mine:
        rooms = rooms.where((r) => r.ownerId == 'me').toList();
        break;
      case _Filter.friends:
        rooms = rooms
            .where((r) =>
                store.friends.contains(r.ownerId) ||
                store.occupants(r.id).keys.any(store.friends.contains))
            .toList();
        break;
    }
    rooms.sort((a, b) {
      final am = a.ownerId == 'me' ? 1 : 0;
      final bm = b.ownerId == 'me' ? 1 : 0;
      if (am != bm) return bm - am;
      return store.onlineCount(b.id).compareTo(store.onlineCount(a.id));
    });

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 120),
      children: [
        _CreateBanner(onTap: () => _showCreateSheet(context)),
        const SizedBox(height: 12),
        SizedBox(
          height: 40,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              for (final f in _Filter.values)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(switch (f) {
                      _Filter.all => 'Все',
                      _Filter.mine => 'Мои',
                      _Filter.friends => 'У друзей',
                    }),
                    selected: _filter == f,
                    showCheckmark: false,
                    onSelected: (_) => setState(() => _filter = f),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (rooms.isEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 40),
            child: EmptyState(
              icon: Icons.meeting_room_outlined,
              title: 'Здесь пока пусто',
              text: 'Создайте комнату или переключите фильтр.',
            ),
          )
        else
          for (final r in rooms) _RoomCard(room: r),
      ],
    );
  }

  void _showCreateSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => const _CreateRoomSheet(),
    );
  }
}

class _CreateBanner extends StatelessWidget {
  final VoidCallback onTap;
  const _CreateBanner({required this.onTap});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final free = !store.rooms.any((r) => r.ownerId == 'me');
    return GlassCard(
      onTap: onTap,
      gradient: LinearGradient(colors: [Ui.a(Ui.violet, .55), Ui.a(Ui.accent, .5)]),
      borderColor: Ui.a(Colors.white, .22),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Ui.a(Colors.white, .18),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(Icons.add_home_work_rounded, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Создать комнату',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(
                  free ? 'Первая комната бесплатно' : 'Стоимость: ${store.settings.roomCost} 🪙',
                  style: TextStyle(color: Ui.a(Colors.white, .8), fontSize: 13),
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, size: 28),
        ],
      ),
    );
  }
}

class _RoomCard extends StatelessWidget {
  final Room room;
  const _RoomCard({required this.room});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final owner = store.users[room.ownerId];
    final online = store.onlineCount(room.id);
    final mine = room.ownerId == 'me';
    final canDelete = mine || store.me.role == Role.admin;
    final wall = room.t.wall;

    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(24),
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => RoomScreen(roomId: room.id)),
          ),
          child: Ink(
            height: 170,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: Ui.a(Colors.white, .16)),
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [shade(wall, .45), shade(wall, .75)],
              ),
              boxShadow: [
                BoxShadow(color: Ui.a(Colors.black, .35), blurRadius: 14, offset: const Offset(0, 6)),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(23),
              child: Stack(
                children: [
                  Positioned.fill(
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 34),
                      child: CustomPaint(
                        painter: RoomPainter(
                          room: room,
                          pos: const {},
                          users: const {},
                          emotes: const {},
                          bubbles: const {},
                          moving: const {},
                          backFacing: const {},
                          t: 0,
                        ),
                      ),
                    ),
                  ),
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Ui.a(Colors.black, .35),
                            Colors.transparent,
                            Colors.transparent,
                            Ui.a(Colors.black, .82),
                          ],
                          stops: const [0, .25, .55, 1],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 10,
                    left: 10,
                    child: Row(
                      children: [
                        _Badge(
                          icon: Icons.circle,
                          iconColor: online > 0 ? Ui.green : Ui.dim,
                          iconSize: 9,
                          text: '$online',
                        ),
                        const SizedBox(width: 6),
                        _Badge(
                          icon: Icons.favorite_rounded,
                          iconColor: Ui.accent,
                          iconSize: 14,
                          text: '${room.likes}',
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    top: 10,
                    right: 10,
                    child: Row(
                      children: [
                        if (room.closed)
                          const Tag('Закрыта', color: Colors.redAccent, icon: Icons.block)
                        else if (!room.isPublic)
                          const Tag('По приглашению', color: Ui.gold, icon: Icons.lock_rounded),
                        if (canDelete)
                          Padding(
                            padding: const EdgeInsets.only(left: 6),
                            child: Material(
                              color: Ui.a(Colors.black, .45),
                              shape: const CircleBorder(),
                              child: InkWell(
                                customBorder: const CircleBorder(),
                                onTap: () => _confirmDelete(context, store),
                                child: const Padding(
                                  padding: EdgeInsets.all(6),
                                  child: Icon(Icons.delete_outline_rounded, size: 18),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  Positioned(
                    left: 14,
                    right: 14,
                    bottom: 10,
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                room.name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                              ),
                              Text(
                                mine ? 'Ваша комната' : 'Хозяин: ${owner?.name ?? '—'}',
                                style: TextStyle(color: Ui.a(Colors.white, .75), fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          decoration: BoxDecoration(
                            gradient: Ui.brand,
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: const Text('Войти', style: TextStyle(fontWeight: FontWeight.w800)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _confirmDelete(BuildContext context, AppStore store) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Удалить «${room.name}»?'),
        content: const Text('Это действие нельзя отменить.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Отмена')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () {
              store.deleteRoom(room.id);
              Navigator.pop(ctx);
            },
            child: const Text('Удалить'),
          ),
        ],
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final double iconSize;
  final String text;
  const _Badge({
    required this.icon,
    required this.iconColor,
    required this.iconSize,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: Ui.a(Colors.black, .5),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Ui.a(Colors.white, .14)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: iconSize, color: iconColor),
          const SizedBox(width: 5),
          Text(text, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
        ],
      ),
    );
  }
}

class _CreateRoomSheet extends StatefulWidget {
  const _CreateRoomSheet();

  @override
  State<_CreateRoomSheet> createState() => _CreateRoomSheetState();
}

class _CreateRoomSheetState extends State<_CreateRoomSheet> {
  final _name = TextEditingController();
  int _theme = 0;
  bool _public = true;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    return SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(20, 0, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Новая комната', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14),
          TextField(
            controller: _name,
            maxLength: 30,
            decoration: Ui.input('Название'),
          ),
          const SizedBox(height: 4),
          const Text('Тема', style: TextStyle(fontWeight: FontWeight.w700, color: Ui.dim)),
          const SizedBox(height: 8),
          SizedBox(
            height: 78,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                for (var i = 0; i < roomThemes.length; i++)
                  if (store.owned.contains('theme$i'))
                    GestureDetector(
                      onTap: () => setState(() => _theme = i),
                      child: Container(
                        width: 74,
                        margin: const EdgeInsets.only(right: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            width: 2.5,
                            color: _theme == i ? Ui.accent : Ui.a(Colors.white, .15),
                          ),
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              roomThemes[i].wall,
                              roomThemes[i].wall,
                              roomThemes[i].floorA,
                              roomThemes[i].floorA,
                            ],
                            stops: const [0, .5, .5, 1],
                          ),
                        ),
                        alignment: Alignment.bottomCenter,
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Text(
                          roomThemes[i].name,
                          style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            shadows: [Shadow(blurRadius: 4, color: Colors.black)],
                          ),
                        ),
                      ),
                    ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Открытая комната', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: const Text('Закрытая — только по приглашению'),
            value: _public,
            onChanged: (v) => setState(() => _public = v),
          ),
          Text(
            store.rooms.any((r) => r.ownerId == 'me')
                ? 'Стоимость: ${store.settings.roomCost} 🪙'
                : 'Первая комната бесплатно',
            style: const TextStyle(color: Ui.dim, fontSize: 13),
          ),
          const SizedBox(height: 12),
          GradientButton(
            label: 'Создать и войти',
            icon: Icons.meeting_room_rounded,
            onPressed: () async {
              final name = _name.text.trim();
              if (name.isEmpty) return;
              final room = store.api != null
                  ? await store.createRoomRemote(name: name, theme: _theme, isPublic: _public)
                  : store.createRoom(name: name, theme: _theme, isPublic: _public);
              if (room == null || !context.mounted) return;
              final nav = Navigator.of(context);
              nav.pop();
              nav.push(MaterialPageRoute<void>(
                builder: (_) => RoomScreen(roomId: room.id),
              ));
            },
          ),
        ],
      ),
    );
  }
}
