import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../widgets/avatar.dart';

/// Админ-панель: статистика, экономика, игроки, комнаты, жалобы, цены, журнал.
/// В настоящем приложении все эти действия должны выполняться на сервере
/// с проверкой роли — клиенту доверять нельзя.
class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final open = store.reports.where((r) => !r.resolved).length;
    return DefaultTabController(
      length: 6,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Админ-панель'),
          bottom: TabBar(
            isScrollable: true,
            tabs: [
              const Tab(text: 'Обзор'),
              const Tab(text: 'Игроки'),
              const Tab(text: 'Комнаты'),
              Tab(text: open == 0 ? 'Жалобы' : 'Жалобы ($open)'),
              const Tab(text: 'Цены'),
              const Tab(text: 'Журнал'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            _Overview(),
            _Players(),
            _AdminRooms(),
            _Reports(),
            _Prices(),
            _LogTab(),
          ],
        ),
      ),
    );
  }
}

class _Overview extends StatefulWidget {
  const _Overview();

  @override
  State<_Overview> createState() => _OverviewState();
}

class _OverviewState extends State<_Overview> {
  final _announce = TextEditingController();
  final _word = TextEditingController();

  @override
  void dispose() {
    _announce.dispose();
    _word.dispose();
    super.dispose();
  }

  Widget _slider(String label, int value, double max, int div, void Function(int) set) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('$label: $value'),
        Slider(
          value: value.toDouble().clamp(0, max).toDouble(),
          max: max,
          divisions: div,
          onChanged: (v) {
            set(v.round());
            StoreScope.of(context).touch();
          },
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final s = store.settings;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _StatCard('Игроков', '${store.users.length}'),
            _StatCard('Онлайн', '${store.onlineTotal}'),
            _StatCard('Комнат', '${store.rooms.length}'),
            _StatCard('Монет в обороте', '${store.coinsInCirculation}'),
            _StatCard('Сообщений', '${store.messagesSent}'),
          ],
        ),
        const SizedBox(height: 20),
        Text('Объявление всем комнатам', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        TextField(
          controller: _announce,
          decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'Текст объявления'),
        ),
        const SizedBox(height: 8),
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton.icon(
            onPressed: () {
              store.broadcast(_announce.text);
              _announce.clear();
            },
            icon: const Icon(Icons.campaign),
            label: const Text('Отправить'),
          ),
        ),
        const SizedBox(height: 12),
        Text('Экономика', style: Theme.of(context).textTheme.titleMedium),
        _slider('Бонус дня (🪙)', s.dailyBonus, 500, 50, (v) => s.dailyBonus = v),
        _slider('За 30 секунд в комнате (🪙)', s.presenceReward, 20, 20, (v) => s.presenceReward = v),
        _slider('Цена новой комнаты (🪙)', s.roomCost, 1000, 20, (v) => s.roomCost = v),
        const SizedBox(height: 12),
        Text('Стоп-слова в чате', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        Wrap(
          spacing: 6,
          children: [
            for (final w in store.badWords.toList())
              InputChip(label: Text(w), onDeleted: () => store.removeBadWord(w)),
          ],
        ),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _word,
                decoration: const InputDecoration(hintText: 'Добавить слово'),
                onSubmitted: (v) {
                  store.addBadWord(v);
                  _word.clear();
                },
              ),
            ),
            IconButton(
              onPressed: () {
                store.addBadWord(_word.text);
                _word.clear();
              },
              icon: const Icon(Icons.add),
            ),
          ],
        ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  const _StatCard(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 150,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value, style: Theme.of(context).textTheme.headlineSmall),
              Text(label, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
      ),
    );
  }
}

class _Players extends StatelessWidget {
  const _Players();

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final list = store.users.values.toList();
    return ListView(
      children: [
        for (final u in list)
          ListTile(
            leading: AvatarBadge(user: u),
            title: Row(
              children: [
                Flexible(child: Text(u.name, overflow: TextOverflow.ellipsis)),
                const SizedBox(width: 6),
                if (u.isStaff) Chip(label: Text(roleName(u.role)), visualDensity: VisualDensity.compact),
                if (u.muted) const Padding(padding: EdgeInsets.only(left: 4), child: Icon(Icons.volume_off, size: 16)),
                if (u.banned) const Padding(padding: EdgeInsets.only(left: 4), child: Icon(Icons.block, size: 16, color: Colors.red)),
              ],
            ),
            subtitle: Text(
              '${u.coins} 🪙  ${u.gems} 💎'
              '${store.locationOf(u.id) == null ? '' : '  · в «${store.roomById(store.locationOf(u.id)!)?.name ?? ''}»'}',
            ),
            trailing: PopupMenuButton<String>(
              onSelected: (a) {
                switch (a) {
                  case 'mute':
                    store.setMuted(u.id, !u.muted);
                  case 'ban':
                    store.setBanned(u.id, !u.banned);
                  case 'kick':
                    store.kick(u.id);
                  case 'mod':
                    store.setRole(u.id, Role.moderator);
                  case 'player':
                    store.setRole(u.id, Role.player);
                  case 'coins':
                    store.grant(u.id, coins: 500);
                  case 'gems':
                    store.grant(u.id, gems: 5);
                  case 'take':
                    store.grant(u.id, coins: -500);
                }
              },
              itemBuilder: (_) => [
                if (u.id != 'me') ...[
                  PopupMenuItem(value: 'mute', child: Text(u.muted ? 'Снять мут' : 'Мут')),
                  PopupMenuItem(value: 'ban', child: Text(u.banned ? 'Разбанить' : 'Забанить')),
                  if (store.locationOf(u.id) != null)
                    const PopupMenuItem(value: 'kick', child: Text('Выгнать из комнаты')),
                  const PopupMenuItem(value: 'mod', child: Text('Сделать модератором')),
                  const PopupMenuItem(value: 'player', child: Text('Сделать игроком')),
                  const PopupMenuItem(value: 'take', child: Text('Списать 500 🪙')),
                ],
                const PopupMenuItem(value: 'coins', child: Text('Выдать 500 🪙')),
                const PopupMenuItem(value: 'gems', child: Text('Выдать 5 💎')),
              ],
            ),
          ),
      ],
    );
  }
}

class _AdminRooms extends StatelessWidget {
  const _AdminRooms();

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    return ListView(
      children: [
        for (final r in store.rooms)
          ListTile(
            leading: Icon(r.closed ? Icons.block : Icons.meeting_room, color: r.closed ? Colors.red : null),
            title: Text(r.name),
            subtitle: Text(
              'Хозяин: ${store.users[r.ownerId]?.name ?? '—'} · онлайн ${store.onlineCount(r.id)} · ♥ ${r.likes}',
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  tooltip: r.closed ? 'Открыть' : 'Закрыть',
                  icon: Icon(r.closed ? Icons.lock_open : Icons.lock_outline),
                  onPressed: () => store.closeRoom(r.id, !r.closed),
                ),
                IconButton(
                  tooltip: 'Удалить',
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => store.deleteRoom(r.id),
                ),
              ],
            ),
          ),
      ],
    );
  }
}

class _Reports extends StatelessWidget {
  const _Reports();

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    if (store.reports.isEmpty) {
      return const Center(child: Text('Жалоб нет. Игроки отправляют их из карточки пользователя.'));
    }
    return ListView(
      children: [
        for (final r in store.reports)
          Card(
            margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${store.users[r.fromId]?.name} → ${store.users[r.targetId]?.name}',
                      style: Theme.of(context).textTheme.titleSmall),
                  Text(r.reason),
                  const SizedBox(height: 8),
                  if (r.resolved)
                    const Text('Обработана', style: TextStyle(color: Colors.green))
                  else
                    Wrap(
                      spacing: 8,
                      children: [
                        OutlinedButton(
                          onPressed: () {
                            store.setMuted(r.targetId, true);
                            store.resolveReport(r);
                          },
                          child: const Text('Мут'),
                        ),
                        OutlinedButton(
                          onPressed: () {
                            store.setBanned(r.targetId, true);
                            store.resolveReport(r);
                          },
                          child: const Text('Бан'),
                        ),
                        TextButton(
                          onPressed: () => store.resolveReport(r),
                          child: const Text('Отклонить'),
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class _Prices extends StatelessWidget {
  const _Prices();

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    return ListView(
      children: [
        for (final it in store.shop)
          ListTile(
            title: Text(it.name),
            subtitle: Text(it.cat),
            trailing: Text('${it.price} ${it.gems ? '💎' : '🪙'}',
                style: Theme.of(context).textTheme.titleMedium),
            onTap: () => _edit(context, store, it),
          ),
      ],
    );
  }

  void _edit(BuildContext context, AppStore store, ShopItem it) {
    final c = TextEditingController(text: '${it.price}');
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(it.name),
        content: TextField(
          controller: c,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: 'Цена (${it.gems ? '💎' : '🪙'})'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Отмена')),
          FilledButton(
            onPressed: () {
              final v = int.tryParse(c.text);
              if (v != null && v >= 0) {
                it.price = v;
                store.touch();
              }
              Navigator.pop(ctx);
            },
            child: const Text('Сохранить'),
          ),
        ],
      ),
    ).then((_) => c.dispose());
  }
}

class _LogTab extends StatelessWidget {
  const _LogTab();

  String _t(DateTime d) =>
      '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}:${d.second.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    return ListView(
      children: [
        for (final e in store.log) ListTile(dense: true, title: Text(e.text), trailing: Text(_t(e.time))),
      ],
    );
  }
}
