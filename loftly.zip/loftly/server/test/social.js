import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';

const { server } = createApp({ dbPath: ':memory:', adminUsername: 'boss' });
await new Promise((r) => server.listen(0, r));
const port = server.address().port;
const base = `http://127.0.0.1:${port}`;

async function call(method, path, body, token) {
  const res = await fetch(base + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return { status: res.status, json: await res.json() };
}
const ok = (r) => { assert.equal(r.status, 200, JSON.stringify(r.json)); return r.json; };
function openWs(token) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(`ws://127.0.0.1:${port}/ws?token=${token}`);
    const inbox = [];
    const waiters = [];
    ws.onmessage = (e) => {
      const m = JSON.parse(e.data);
      const i = waiters.findIndex((w) => w.pred(m));
      if (i >= 0) waiters.splice(i, 1)[0].res(m); else inbox.push(m);
    };
    ws.onerror = reject;
    ws.onopen = () => resolve({
      send: (o) => ws.send(JSON.stringify(o)),
      close: () => ws.close(),
      next: (pred) => new Promise((res, rej) => {
        const i = inbox.findIndex(pred);
        if (i >= 0) return res(inbox.splice(i, 1)[0]);
        const t = setTimeout(() => rej(new Error('ws timeout')), 3000);
        waiters.push({ pred, res: (m) => { clearTimeout(t); res(m); } });
      }),
    });
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const a = ok(await call('POST', '/api/register', { username: 'anna', password: 'secret1', name: 'Анна' }));
const b = ok(await call('POST', '/api/register', { username: 'boris', password: 'secret1', name: 'Борис' }));
const A = a.token;
const B = b.token;
const aid = a.profile.id;
const bid = b.profile.id;

// --- личные сообщения ---
assert.equal((await call('POST', `/api/dm/${aid}`, { text: 'сам себе' }, A)).status, 400);
assert.equal((await call('POST', '/api/dm/9999', { text: 'привет' }, A)).status, 404);
const wb0 = await openWs(B);
await wb0.next((m) => m.t === 'hello');
const sent = ok(await call('POST', `/api/dm/${bid}`, { text: 'привет, дурак' }, A));
assert.equal(sent.message.text, 'привет, ***');
const pushed = await wb0.next((m) => m.t === 'dm');
assert.equal(pushed.message.fromId, aid);
assert.equal((await call('POST', `/api/dm/${bid}`, { text: 'ещё' }, A)).status, 429); // слишком быстро
await sleep(750);
assert.equal((await call('POST', `/api/dm/${bid}`, { text: '   ' }, A)).status, 400);
let inbox = ok(await call('GET', '/api/dm', undefined, B));
assert.equal(inbox.unreadTotal, 1);
assert.equal(inbox.chats[0].name, 'Анна');
const thread = ok(await call('GET', `/api/dm/${aid}`, undefined, B));
assert.equal(thread.messages.length, 1);
inbox = ok(await call('GET', '/api/dm', undefined, B));
assert.equal(inbox.unreadTotal, 0);
assert.equal(ok(await call('GET', `/api/dm/${bid}`, undefined, A)).messages.length, 1);
wb0.close();
await sleep(200);

// --- подписки ---
assert.equal((await call('POST', `/api/follow/${aid}`, {}, A)).status, 400);
let f = ok(await call('POST', `/api/follow/${bid}`, {}, A));
assert.equal(f.following, true);
assert.equal(f.followers, 1);
let prof = ok(await call('GET', `/api/users/${bid}`, undefined, A));
assert.equal(prof.following, true);
assert.equal(prof.online, false);
assert.equal(ok(await call('GET', `/api/users/${aid}`, undefined, B)).followsMe, true);
assert.equal(ok(await call('GET', '/api/following', undefined, A)).following[0].name, 'Борис');
f = ok(await call('POST', `/api/follow/${bid}`, {}, A));
assert.equal(f.following, false);
ok(await call('POST', `/api/follow/${bid}`, {}, A));

// --- комната с диваном, сортировка, события ---
ok(await call('POST', '/api/shop/buy', { itemId: 'furn:sofa' }, A));
const room = ok(await call('POST', '/api/rooms', { name: 'Гостиная', theme: 0, isPublic: true }, A)).room;
const room2 = ok(await call('POST', '/api/rooms', { name: 'Вторая', theme: 0, isPublic: true }, B)).room;
ok(await call('PUT', `/api/rooms/${room.id}/layout`, { items: [{ kind: 'sofa', x: 2, y: 2 }] }, A));
assert.equal(ok(await call('GET', '/api/rooms?q=гост', undefined, B)).rooms.length, 1);
assert.equal(ok(await call('GET', '/api/rooms?sort=new', undefined, B)).rooms[0].id, room2.id);
assert.equal((await call('POST', `/api/rooms/${room.id}/event`, { title: 'Вечеринка', minutes: 30 }, B)).status, 403);
assert.equal((await call('POST', `/api/rooms/${room.id}/event`, { title: '', minutes: 30 }, A)).status, 400);
const ev = ok(await call('POST', `/api/rooms/${room.id}/event`, { title: 'Вечеринка', minutes: 30 }, A));
assert.equal(ev.room === undefined ? ev.event.title : ev.room.event.title, 'Вечеринка');
assert.equal(ok(await call('GET', '/api/rooms?sort=new', undefined, B)).rooms[0].id, room.id); // событие сверху
ok(await call('POST', `/api/rooms/${room.id}/event`, { minutes: 0 }, A));
assert.equal(ok(await call('GET', '/api/rooms?sort=new', undefined, B)).rooms[0].id, room2.id);

// --- посадка и парные эмоции ---
const wa = await openWs(A);
const wb = await openWs(B);
await wa.next((m) => m.t === 'hello');
await wb.next((m) => m.t === 'hello');
wa.send({ t: 'join', room: room.id });
await wa.next((m) => m.t === 'joined');
wb.send({ t: 'join', room: room.id });
const jb = await wb.next((m) => m.t === 'joined');
assert.equal(jb.players.every((p) => p.sit === false), true);
await wa.next((m) => m.t === 'player_join');

wa.send({ t: 'sit', x: 0, y: 0 }); // не сиденье
assert.equal((await wa.next((m) => m.t === 'error')).code, 'not_seat');
wa.send({ t: 'sit', x: 2, y: 2 });
const sa = await wb.next((m) => m.t === 'move' && m.sit === true);
assert.deepEqual(sa.path.at(-1), [2, 2]);
await sleep(200);
wb.send({ t: 'sit', x: 2, y: 2 });
assert.equal((await wb.next((m) => m.t === 'error')).code, 'seat_taken');
wb.send({ t: 'sit', x: 3, y: 2 });
const sb = await wa.next((m) => m.t === 'move' && m.sit === true && m.id === bid);
assert.deepEqual(sb.path.at(-1), [3, 2]);
await sleep(200);
wa.send({ t: 'move', x: 5, y: 5 }); // встаёт
const stand = await wb.next((m) => m.t === 'move' && m.id === aid && m.sit === false);
assert.deepEqual(stand.path.at(-1), [5, 5]);

// парная эмоция: слишком далеко, потом ближе
await sleep(200);
wb.send({ t: 'pair', target: aid, kind: 'hug' });
assert.equal((await wb.next((m) => m.t === 'error')).code, 'too_far');
wb.send({ t: 'move', x: 4, y: 5 });
await sleep(200);
wb.send({ t: 'pair', target: aid, kind: 'hug' });
const inv = await wa.next((m) => m.t === 'pair_invite');
assert.equal(inv.from, bid);
wa.send({ t: 'pair_accept', from: bid });
const pr = await wb.next((m) => m.t === 'pair');
assert.equal(pr.emoji, '🤗');
wa.send({ t: 'pair_accept', from: bid }); // повторно нельзя
assert.equal((await wa.next((m) => m.t === 'error')).code, 'pair_expired');

// ЛС приходит по сокету, даже когда игрок в комнате
await sleep(750);
ok(await call('POST', `/api/dm/${aid}`, { text: 'ты тут?' }, B));
assert.equal((await wa.next((m) => m.t === 'dm')).message.text, 'ты тут?');

wa.close();
wb.close();
console.log('SOCIAL OK');
server.close();
process.exit(0);
