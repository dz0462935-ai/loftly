// Каталог предметов. id совпадают с id в клиенте (lib/store.dart -> _initShop).

export const FURN = {
  sofa: { name: 'Диван', w: 2, d: 1, walkable: false },
  table: { name: 'Журнальный столик', w: 2, d: 1, walkable: false },
  rug: { name: 'Ковёр', w: 3, d: 2, walkable: true },
  tv: { name: 'Телевизор', w: 1, d: 1, walkable: false },
  plant: { name: 'Растение', w: 1, d: 1, walkable: false },
  bed: { name: 'Кровать', w: 2, d: 2, walkable: false },
  lamp: { name: 'Торшер', w: 1, d: 1, walkable: false },
  fridge: { name: 'Холодильник', w: 1, d: 1, walkable: false },
  shelf: { name: 'Книжный шкаф', w: 2, d: 1, walkable: false },
  desk: { name: 'Стол с ноутбуком', w: 2, d: 1, walkable: false },
  chair: { name: 'Кресло', w: 1, d: 1, walkable: false },
  arcade: { name: 'Аркадный автомат', w: 1, d: 1, walkable: false },
};
const furnPrice = {
  sofa: 300, table: 120, rug: 80, tv: 400, plant: 60, bed: 500,
  lamp: 90, fridge: 250, shelf: 200, desk: 180, chair: 90, arcade: 350,
};

export const ROOM_GRID = 8;
export const THEME_COUNT = 5;

// slot: куда надевается. Бесплатные стартовые предметы — free: true.
export const ITEMS = {};
function add(id, slot, name, price, extra = {}) {
  ITEMS[id] = { id, slot, name, price, gems: false, free: price === 0, ...extra };
}
['Фиолетовая кофта', 'Красная кофта', 'Бирюзовая кофта', 'Оранжевая кофта', 'Синяя кофта', 'Розовая кофта']
  .forEach((n, i) => add(`top${i}`, 'top', n, i === 0 ? 0 : 60 + i * 15));
['Тёмные джинсы', 'Голубые джинсы', 'Бежевые брюки', 'Красная юбка']
  .forEach((n, i) => add(`bottom${i}`, 'bottom', n, i === 0 ? 0 : 70));
['Белые кеды', 'Чёрные кеды', 'Красные кеды']
  .forEach((n, i) => add(`shoes${i}`, 'shoes', n, i === 0 ? 0 : 50));
add('hair1', 'hair', 'Короткие волосы', 0);
add('hair2', 'hair', 'Длинные волосы', 100);
add('hair3', 'hair', 'Пучок', 120);
add('hair0', 'hair', 'Без волос', 30);
['Тёмно-каштановые', 'Каштановые', 'Блонд', 'Рыжие', 'Синие', 'Белые']
  .forEach((n, i) => add(`hc${i}`, 'hairc', n, i === 0 ? 0 : 40));
add('hat1', 'hat', 'Кепка', 100);
add('hat3', 'hat', 'Шапка с помпоном', 130);
add('hat4', 'hat', 'Бант', 90);
add('hat2', 'hat', 'Золотая корона', 8, { gems: true });
for (let i = 1; i < THEME_COUNT; i++) add(`theme${i}`, 'theme', `Тема ${i}`, 150 + i * 30);
add('theme0', 'theme', 'Лофт', 0);
for (const [k, v] of Object.entries(FURN)) add(`furn:${k}`, 'furn', v.name, furnPrice[k]);

export const FREE_ITEMS = Object.values(ITEMS).filter((i) => i.free && i.slot !== 'furn').map((i) => i.id);
export const DEFAULT_EQUIP = { top: 'top0', bottom: 'bottom0', shoes: 'shoes0', hair: 'hair1', hairc: 'hc0', hat: null };
export const EQUIP_SLOTS = ['top', 'bottom', 'shoes', 'hair', 'hairc', 'hat'];

// ---------- Лотерея ----------
export const RARITIES = ['common', 'rare', 'epic', 'legendary'];
export const RARITY_NAMES = { common: 'Обычный', rare: 'Редкий', epic: 'Эпический', legendary: 'Легендарный' };

// Пулы предметов по редкости.
export const POOLS = {
  common: ['top1', 'top2', 'top3', 'top4', 'top5', 'bottom1', 'bottom2', 'bottom3', 'shoes1', 'shoes2',
    'hc1', 'hc2', 'hc3', 'hc4', 'hc5', 'furn:plant', 'furn:rug', 'furn:lamp'],
  rare: ['hair0', 'hair2', 'hair3', 'hat1', 'hat3', 'hat4', 'theme1', 'theme2',
    'furn:chair', 'furn:table', 'furn:desk', 'furn:shelf'],
  epic: ['theme3', 'theme4', 'furn:sofa', 'furn:fridge', 'furn:arcade'],
  legendary: ['hat2', 'furn:tv', 'furn:bed'],
};

// Если предмет уже есть — возвращаем часть стоимости.
export const DUPLICATE_REFUND = {
  common: { coins: 15, gems: 0 },
  rare: { coins: 50, gems: 0 },
  epic: { coins: 140, gems: 0 },
  legendary: { coins: 0, gems: 3 },
};

// Шансы в процентах (сумма = 100). Показываются игрокам в приложении.
export const BOXES = {
  basic: {
    name: 'Обычная капсула',
    cost: { coins: 100, gems: 0 },
    odds: { common: 70, rare: 24, epic: 5.5, legendary: 0.5 },
    // Гарантии: если N круток подряд не выпало >= редкости — следующая гарантированно выпадет.
    pity: [{ atLeast: 'rare', every: 10 }, { atLeast: 'epic', every: 50 }],
  },
  premium: {
    name: 'Премиум-капсула',
    cost: { coins: 0, gems: 5 },
    odds: { common: 0, rare: 60, epic: 33, legendary: 7 },
    pity: [{ atLeast: 'epic', every: 10 }, { atLeast: 'legendary', every: 40 }],
  },
};

for (const [name, b] of Object.entries(BOXES)) {
  const sum = Object.values(b.odds).reduce((a, x) => a + x, 0);
  if (Math.abs(sum - 100) > 1e-9) throw new Error(`odds of ${name} sum to ${sum}`);
}
for (const pool of Object.values(POOLS)) for (const id of pool) if (!ITEMS[id]) throw new Error(`unknown item ${id}`);
