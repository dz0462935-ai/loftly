import 'dart:async';

import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../ui.dart';
import 'room_screen.dart';

/// Карточка-вход на вкладке «Друзья»: сообщения, подписки.
class SocialEntryCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final int badge;
  final VoidCallback onTap;

  const SocialEntryCard({
    super.key,
    required this.icon,
    required this.title,
    required this.onTap,
    this.badge = 0,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      onTap: onTap,
      child: Row(
        children: [
          Icon(icon, size: 26),
          const SizedBox(width: 10),
          Expanded(
            child: Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
          ),
          if (badge > 0)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
              decoration: BoxDecoration(color: Ui.accent, borderRadius: BorderRadius.circular(10)),
              child: Text('$badge', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
            ),
        ],
      ),
    );
  }
}

void openDm(BuildContext context, int otherId, String name) {
  Navigator.of(context).push(
    MaterialPageRoute<void>(builder: (_) => DmScreen(otherId: otherId, name: name)),
  );
}

/// Список личных переписок.
class DmInboxScreen extends StatefulWidget {
  const DmInboxScreen({super.key});

  @override
  State<DmInboxScreen> createState() => _DmInboxScreenState();
}

class _DmInboxScreenState extends State<DmInboxScreen> {
  Timer? _poll;
  AppStore? _store;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_store == null) {
      final s = StoreScope.of(context);
      _store = s;
      s.loadDmInbox();
      _poll = Timer.periodic(const Duration(seconds: 5), (_) => s.loadDmInbox());
    }
  }

  @override
  void dispose() {
    _poll?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final chats = store.dmChats;
    return Scaffold(
      appBar: AppBar(title: const Text('Сообщения')),
      body: GameBackground(
        child: store.api == null
            ? const Center(child: Text('Личные сообщения доступны после входа на сервер'))
            : chats.isEmpty
                ? const EmptyState(
                    icon: Icons.chat_bubble_outline_rounded,
                    title: 'Пока нет переписок',
                    text: 'Откройте карточку игрока в комнате и нажмите «Написать».',
                  )
                : ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      for (final c in chats)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: GlassCard(
                            onTap: () => openDm(context, c.userId, c.name),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(c.name,
                                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                                      const SizedBox(height: 2),
                                      Text(
                                        (c.mine ? 'Вы: ' : '') + c.last,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(color: Ui.dim, fontSize: 13),
                                      ),
                                    ],
                                  ),
                                ),
                                if (c.unread > 0)
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: Ui.accent,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Text('${c.unread}',
                                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
                                  ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
      ),
    );
  }
}

/// Переписка с одним игроком.
class DmScreen extends StatefulWidget {
  final int otherId;
  final String name;
  const DmScreen({super.key, required this.otherId, required this.name});

  @override
  State<DmScreen> createState() => _DmScreenState();
}

class _DmScreenState extends State<DmScreen> {
  final _text = TextEditingController();
  final _scroll = ScrollController();
  Timer? _poll;
  AppStore? _store;
  int _shown = 0;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_store == null) {
      final s = StoreScope.of(context);
      _store = s;
      s.openDmWith = widget.otherId;
      s.loadDmThread(widget.otherId);
      _poll = Timer.periodic(const Duration(seconds: 3), (_) => s.loadDmThread(widget.otherId));
    }
  }

  @override
  void dispose() {
    _poll?.cancel();
    final s = _store;
    if (s != null) {
      if (s.openDmWith == widget.otherId) s.openDmWith = null;
      s.loadDmInbox();
    }
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final s = _store;
    if (s == null) return;
    final t = _text.text;
    if (t.trim().isEmpty) return;
    _text.clear();
    final ok = await s.sendDm(widget.otherId, t);
    if (!ok && mounted) _text.text = t;
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final list = store.dmThreads[widget.otherId] ?? const <DmMessage>[];
    final myId = store.serverIdOf('me');
    if (list.length != _shown) {
      _shown = list.length;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
      });
    }
    return Scaffold(
      appBar: AppBar(title: Text(widget.name)),
      body: GameBackground(
        child: Column(
          children: [
            Expanded(
              child: list.isEmpty
                  ? const Center(child: Text('Напишите первое сообщение', style: TextStyle(color: Ui.dim)))
                  : ListView.builder(
                      controller: _scroll,
                      padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
                      itemCount: list.length,
                      itemBuilder: (_, i) {
                        final m = list[i];
                        final mine = m.fromId == myId;
                        return Align(
                          alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 6),
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                            decoration: BoxDecoration(
                              color: mine ? Ui.a(Ui.violet, .75) : Ui.a(Colors.white, .12),
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Text(m.text),
                          ),
                        );
                      },
                    ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _text,
                        maxLength: 120,
                        textInputAction: TextInputAction.send,
                        onSubmitted: (_) => _send(),
                        decoration: const InputDecoration(hintText: 'Сообщение', counterText: ''),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.filled(onPressed: _send, icon: const Icon(Icons.send_rounded)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Лента: на кого подписан, кто онлайн и где.
class FollowingScreen extends StatefulWidget {
  const FollowingScreen({super.key});

  @override
  State<FollowingScreen> createState() => _FollowingScreenState();
}

class _FollowingScreenState extends State<FollowingScreen> {
  Timer? _poll;
  AppStore? _store;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_store == null) {
      final s = StoreScope.of(context);
      _store = s;
      s.refreshFollowing();
      _poll = Timer.periodic(const Duration(seconds: 8), (_) => s.refreshFollowing());
    }
  }

  @override
  void dispose() {
    _poll?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final feed = store.followFeed;
    return Scaffold(
      appBar: AppBar(title: const Text('Подписки')),
      body: GameBackground(
        child: store.api == null
            ? const Center(child: Text('Подписки доступны после входа на сервер'))
            : feed.isEmpty
                ? const EmptyState(
                    icon: Icons.notifications_none_rounded,
                    title: 'Вы ни на кого не подписаны',
                    text: 'Нажмите «Подписаться» в карточке игрока — и увидите, где он сейчас.',
                  )
                : ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      for (final f in feed)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: GlassCard(
                            onTap: f.roomId == null
                                ? null
                                : () => Navigator.of(context).push(
                                      MaterialPageRoute<void>(builder: (_) => RoomScreen(roomId: f.roomId!)),
                                    ),
                            child: Row(
                              children: [
                                Icon(Icons.circle, size: 10, color: f.online ? Ui.green : Ui.dim),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(f.name,
                                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                                      Text(
                                        f.roomName != null
                                            ? 'В комнате «${f.roomName}»'
                                            : (f.online ? 'Онлайн' : 'Не в сети'),
                                        style: const TextStyle(color: Ui.dim, fontSize: 13),
                                      ),
                                    ],
                                  ),
                                ),
                                IconButton(
                                  tooltip: 'Написать',
                                  onPressed: () => openDm(context, f.id, f.name),
                                  icon: const Icon(Icons.chat_bubble_outline_rounded),
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
      ),
    );
  }
}
