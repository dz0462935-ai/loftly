import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../widgets/avatar.dart';
import '../widgets/iso.dart';
import 'admin_screen.dart';

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final me = store.me;
    final stock = store.furnInv.entries.where((e) => e.value > 0).toList();
    final myRooms = store.rooms.where((r) => r.ownerId == 'me').length;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Center(child: AvatarFigure(user: me, size: 110)),
        const SizedBox(height: 8),
        Center(
          child: TextButton.icon(
            onPressed: () => _rename(context, store),
            icon: const Icon(Icons.edit, size: 18),
            label: Text(me.name, style: const TextStyle(fontSize: 20)),
          ),
        ),
        Center(child: Text(roleName(me.role), style: Theme.of(context).textTheme.bodySmall)),
        const SizedBox(height: 16),
        Row(
          children: [
            _Stat('🪙', '${me.coins}', 'монеты'),
            _Stat('💎', '${me.gems}', 'кристаллы'),
            _Stat('🏠', '$myRooms', 'комнаты'),
            _Stat('🔥', '${store.streak}', 'серия'),
          ],
        ),
        const SizedBox(height: 16),
        const Text('Одежду, причёски и шляпы выбирайте во вкладке «Магазин».'),
        const SizedBox(height: 16),
        Text('Склад мебели', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        stock.isEmpty
            ? const Text('Пусто')
            : Wrap(
                spacing: 8,
                children: [
                  for (final e in stock)
                    Chip(label: Text('${furnCatalog[e.key]!.emoji} ${furnCatalog[e.key]!.name} ×${e.value}')),
                ],
              ),
        if (me.role == Role.admin && store.api == null) ...[
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const AdminScreen()),
            ),
            icon: const Icon(Icons.admin_panel_settings),
            label: const Text('Админ-панель'),
          ),
        ],
      ],
    );
  }

  void _rename(BuildContext context, AppStore store) {
    final c = TextEditingController(text: store.me.name);
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Ваше имя'),
        content: TextField(controller: c, maxLength: 20, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Отмена')),
          FilledButton(
            onPressed: () {
              store.updateProfile(name: c.text);
              Navigator.pop(ctx);
            },
            child: const Text('Сохранить'),
          ),
        ],
      ),
    ).then((_) => c.dispose());
  }
}

class _Stat extends StatelessWidget {
  final String icon;
  final String value;
  final String label;
  const _Stat(this.icon, this.value, this.label);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Text(icon, style: const TextStyle(fontSize: 22)),
          Text(value, style: Theme.of(context).textTheme.titleMedium),
          Text(label, style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}
