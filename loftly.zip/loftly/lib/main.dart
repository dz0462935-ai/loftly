import 'package:flutter/material.dart';

import 'api.dart';
import 'screens/auth_screen.dart';
import 'screens/home.dart';
import 'store.dart';

void main() => runApp(const LoftlyApp());

class LoftlyApp extends StatefulWidget {
  const LoftlyApp({super.key});

  @override
  State<LoftlyApp> createState() => _LoftlyAppState();
}

class _LoftlyAppState extends State<LoftlyApp> {
  late AppStore _store;
  bool _loading = true;
  bool _inGame = false;
  String _url = '';

  @override
  void initState() {
    super.initState();
    _store = _newStore();
    _boot();
  }

  AppStore _newStore() => AppStore()..onLogout = _logout;

  /// Пробуем войти по сохранённому токену.
  Future<void> _boot() async {
    final s = await loadSession();
    _url = s.url;
    final token = s.token;
    if (token != null && s.url.isNotEmpty) {
      try {
        final api = ApiClient(s.url, token);
        final profile = await api.me();
        if (!mounted) return;
        _enter(api, profile);
        return;
      } on ApiException catch (e) {
        if (e.code == 'unauthorized') await clearToken();
      }
    }
    if (mounted) setState(() => _loading = false);
  }

  void _enter(ApiClient api, Map<String, dynamic> profile) {
    _store.goOnline(api, profile);
    setState(() {
      _inGame = true;
      _loading = false;
    });
  }

  void _enterDemo() => setState(() => _inGame = true);

  Future<void> _logout() async {
    await clearToken();
    if (!mounted) return;
    final old = _store;
    setState(() {
      _store = _newStore();
      _inGame = false;
    });
    // Старое хранилище освобождаем после перерисовки.
    WidgetsBinding.instance.addPostFrameCallback((_) => old.dispose());
  }

  @override
  void dispose() {
    _store.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Widget home;
    if (_loading) {
      home = const Scaffold(body: Center(child: CircularProgressIndicator()));
    } else if (_inGame) {
      home = const HomeScreen();
    } else {
      home = AuthScreen(initialUrl: _url, onLoggedIn: _enter, onDemo: _enterDemo);
    }
    return StoreScope(
      store: _store,
      child: MaterialApp(
        scaffoldMessengerKey: messengerKey,
        title: 'Loftly',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7E57C2)),
        ),
        darkTheme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF7E57C2),
            brightness: Brightness.dark,
          ),
        ),
        home: home,
      ),
    );
  }
}
