import { ApiError } from './game.js';

const bad = (code, msg) => new ApiError(400, code, msg);

/** Личные сообщения, подписки и публичные профили. */
export function createSocial(db, game) {
  const lastSent = new Map(); // userId -> время последнего ЛС (мс)

  const userRow = (id) => {
    const u = game.userById(id);
    if (!u) throw new ApiError(404, 'no_user', 'Игрок не найден');
    return u;
  };

  // ---------- Личные сообщения ----------

  /** Отправляет ЛС. Возвращает сообщение (для получателя тоже, через onPush). */
  function sendDm(fromId, toId, rawText) {
    if (fromId === toId) throw bad('self_dm', 'Нельзя писать самому себе');
    const from = userRow(fromId);
    const to = userRow(toId);
    if (from.muted) throw new ApiError(403, 'muted', 'Вам запрещено писать');
    if (to.banned) throw bad('no_user', 'Игрок недоступен');
    const t = Date.now();
    if (t - (lastSent.get(fromId) ?? 0) < 700) throw new ApiError(429, 'slow_down', 'Не так быстро');
    const text = game.filterChat(rawText);
    if (!text) throw bad('empty', 'Пустое сообщение');
    lastSent.set(fromId, t);
    const r = db.prepare('INSERT INTO dm_messages (from_id, to_id, text) VALUES (?, ?, ?)').run(fromId, toId, text);
    return {
      id: Number(r.lastInsertRowid), fromId, toId, fromName: from.name, text, at: t,
    };
  }

  function dmThread(userId, otherId, afterId = 0) {
    userRow(otherId);
    const rows = db.prepare(`SELECT id, from_id, to_id, text, created_at FROM dm_messages
      WHERE ((from_id = ? AND to_id = ?) OR (from_id = ? AND to_id = ?)) AND id > ?
      ORDER BY id DESC LIMIT 100`).all(userId, otherId, otherId, userId, Number(afterId) || 0);
    db.prepare('UPDATE dm_messages SET read = 1 WHERE to_id = ? AND from_id = ? AND read = 0').run(userId, otherId);
    return {
      messages: rows.reverse().map((r) => ({
        id: r.id, fromId: r.from_id, toId: r.to_id, text: r.text, at: r.created_at,
      })),
    };
  }

  function dmInbox(userId) {
    const rows = db.prepare(`
      SELECT other AS user_id, MAX(id) AS last_id,
             SUM(CASE WHEN to_id = ? AND read = 0 THEN 1 ELSE 0 END) AS unread
      FROM (SELECT id, to_id, read, CASE WHEN from_id = ? THEN to_id ELSE from_id END AS other
            FROM dm_messages WHERE from_id = ? OR to_id = ?)
      GROUP BY other ORDER BY last_id DESC LIMIT 100`).all(userId, userId, userId, userId);
    return {
      chats: rows.map((r) => {
        const m = db.prepare('SELECT text, from_id, created_at FROM dm_messages WHERE id = ?').get(r.last_id);
        const u = game.userById(r.user_id);
        return {
          userId: r.user_id, name: u?.name ?? 'Игрок', last: m.text, mine: m.from_id === userId,
          at: m.created_at, unread: r.unread,
        };
      }),
      unreadTotal: rows.reduce((a, r) => a + r.unread, 0),
    };
  }

  // ---------- Подписки ----------

  function toggleFollow(userId, targetId) {
    if (userId === targetId) throw bad('self_follow', 'Нельзя подписаться на себя');
    userRow(targetId);
    const has = db.prepare('SELECT 1 FROM follows WHERE follower_id = ? AND followee_id = ?').get(userId, targetId);
    if (has) db.prepare('DELETE FROM follows WHERE follower_id = ? AND followee_id = ?').run(userId, targetId);
    else db.prepare('INSERT INTO follows (follower_id, followee_id) VALUES (?, ?)').run(userId, targetId);
    return { following: !has, ...counts(targetId) };
  }

  function counts(id) {
    return {
      followers: db.prepare('SELECT COUNT(*) AS c FROM follows WHERE followee_id = ?').get(id).c,
      followingCount: db.prepare('SELECT COUNT(*) AS c FROM follows WHERE follower_id = ?').get(id).c,
    };
  }

  /** Лента: на кого подписан, кто онлайн и в какой комнате. presence: { whereIs(id) -> roomId|null, isOnline(id) }. */
  function feed(userId, presence) {
    const rows = db.prepare(`SELECT u.id FROM follows f JOIN users u ON u.id = f.followee_id
      WHERE f.follower_id = ? AND u.banned = 0 ORDER BY u.name`).all(userId);
    const list = rows.map((r) => {
      const u = game.userById(r.id);
      const roomId = presence.whereIs(r.id);
      let room = null;
      if (roomId) {
        const row = game.getRoom(roomId);
        if (row.is_public || row.owner_id === userId) room = { id: row.id, name: row.name };
      }
      return { ...game.publicUser(u), online: presence.isOnline(r.id), room };
    });
    list.sort((a, b) => (!!b.room - !!a.room) || (b.online - a.online));
    return { following: list };
  }

  function publicProfile(viewerId, id, presence) {
    const u = userRow(id);
    const following = !!db.prepare('SELECT 1 FROM follows WHERE follower_id = ? AND followee_id = ?').get(viewerId, id);
    const followsMe = !!db.prepare('SELECT 1 FROM follows WHERE follower_id = ? AND followee_id = ?').get(id, viewerId);
    return {
      ...game.publicUser(u), ...counts(id), following, followsMe,
      online: presence.isOnline(id), createdAt: u.created_at,
    };
  }

  return { sendDm, dmThread, dmInbox, toggleFollow, feed, publicProfile };
}
