import http from 'node:http';
import { openDb } from './db.js';
import { createGame, ApiError } from './game.js';
import { createHub } from './realtime.js';
import { handleUpgrade } from './ws.js';
import { CLOTH_SPEC } from './catalog.js';

export function createApp({ dbPath = ':memory:', adminUsername = '', badWords } = {}) {
  const db = openDb(dbPath);
  const game = createGame(db, { adminUsername, badWords });
  const hub = createHub(game);

  // Простой ограничитель попыток входа/регистрации по IP: 10 за 10 минут.
  const attempts = new Map();
  function throttle(ip) {
    const t = Date.now();
    const list = (attempts.get(ip) || []).filter((x) => t - x < 600000);
    if (list.length >= 10) throw new ApiError(429, 'too_many_attempts', 'Слишком много попыток, подождите');
    list.push(t);
    attempts.set(ip, list);
  }

  const routes = [];
  const route = (method, pattern, handler, { auth = true } = {}) => {
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => (keys.push(k), '([^/]+)')) + '$');
    routes.push({ method, re, keys, handler, auth });
  };

  const intParam = (v) => {
    const n = Number(v);
    if (!Number.isInteger(n)) throw new ApiError(400, 'bad_id');
    return n;
  };

  // --- Аккаунт ---
  route('POST', '/api/register', (c) => { throttle(c.ip); return game.register(c.body); }, { auth: false });
  route('POST', '/api/login', (c) => { throttle(c.ip); return game.login(c.body); }, { auth: false });
  route('POST', '/api/logout', (c) => { game.logout(c.token); return { ok: true }; });
  route('GET', '/api/me', (c) => game.profile(c.user.id));
  route('POST', '/api/me/name', (c) => game.updateName(c.user.id, c.body.name));
  route('POST', '/api/daily', (c) => game.claimDaily(c.user.id));

  // --- Магазин и одежда ---
  route('POST', '/api/shop/buy', (c) => game.buy(c.user.id, c.body.itemId));
  route('POST', '/api/equip', (c) => game.equip(c.user.id, c.body.slot, c.body.itemId ?? null));

  // --- Одежда из студии ---
  route('GET', '/api/clothes', () => ({ clothes: game.listClothes(), spec: CLOTH_SPEC }));
  route('GET', '/api/clothes/:id', (c) => game.getCloth(c.params.id));
  route('GET', '/api/admin/clothes', (c) => ({ clothes: game.adminListClothes(c.user.id) }));
  route('POST', '/api/admin/clothes', (c) => game.adminCreateCloth(c.user.id, c.body));
  route('POST', '/api/admin/clothes/:id', (c) => game.adminUpdateCloth(c.user.id, c.params.id, c.body));

  // --- Лотерея ---
  route('GET', '/api/lottery', (c) => game.lotteryInfo(c.user.id));
  route('POST', '/api/lottery/roll', (c) => game.roll(c.user.id, c.body.box, c.body.count ?? 1));

  // --- Комнаты ---
  route('GET', '/api/rooms', (c) => ({ rooms: game.listRooms(c.user.id, hub.online) }));
  route('POST', '/api/rooms', (c) => game.createRoom(c.user.id, c.body));
  route('POST', '/api/rooms/:id/like', (c) => game.roomRow(game.getRoom(intParam(c.params.id)), c.user.id) && game.toggleLike(c.user.id, intParam(c.params.id)));
  route('POST', '/api/rooms/:id/theme', (c) => {
    const id = intParam(c.params.id);
    const r = game.setRoomTheme(c.user.id, id, c.body.theme);
    hub.roomChanged(id);
    return r;
  });
  route('PUT', '/api/rooms/:id/layout', (c) => {
    const id = intParam(c.params.id);
    const r = game.saveLayout(c.user.id, id, c.body.items);
    hub.roomChanged(id);
    return r;
  });
  route('DELETE', '/api/rooms/:id', (c) => game.deleteRoom(c.user.id, intParam(c.params.id)));

  // --- Розыгрыши владельца комнаты ---
  const settle = () => game.settleDue().forEach((r) => hub.roomMessage(r.roomId, r.text));
  route('GET', '/api/rooms/:id/grab', (c) => { settle(); return { grab: game.activeGrab(intParam(c.params.id), c.user.id) }; });
  route('POST', '/api/rooms/:id/grab', (c) => {
    settle();
    const roomId = intParam(c.params.id);
    const r = game.createGrab(c.user.id, roomId, c.body);
    hub.roomMessage(roomId, r.text);
    return { grab: r.grab };
  });
  route('POST', '/api/grabs/:id/join', (c) => { settle(); return game.joinGrab(c.user.id, intParam(c.params.id)); });

  // --- Личные сообщения ---
  route('GET', '/api/dm', (c) => ({ threads: game.dmThreads(c.user.id), unread: game.dmUnread(c.user.id) }));
  route('GET', '/api/dm/:id', (c) => game.dmThread(c.user.id, intParam(c.params.id), c.query.after));
  route('POST', '/api/dm/:id', (c) => {
    const message = game.sendDm(c.user.id, intParam(c.params.id), c.body.text);
    hub.notify(message.to, { t: 'dm', message });
    return { message };
  });

  // --- Админка ---
  route('GET', '/api/admin/users', (c) => ({ users: game.adminUsers(c.user.id) }));
  route('POST', '/api/admin/users/:id', (c) => {
    const id = intParam(c.params.id);
    const r = game.adminSet(c.user.id, id, c.body);
    if (c.body.banned) hub.disconnect(id);
    return r;
  });
  route('POST', '/api/admin/users/:id/kick', (c) => {
    if (!['admin', 'moderator'].includes(c.user.role)) throw new ApiError(403, 'forbidden');
    return { kicked: hub.kick(intParam(c.params.id)) };
  });
  route('POST', '/api/admin/users/:id/grant', (c) => game.adminGrant(c.user.id, intParam(c.params.id), c.body.coins ?? 0, c.body.gems ?? 0));
  route('POST', '/api/admin/users/:id/award', (c) => game.adminAward(c.user.id, intParam(c.params.id), c.body.itemId, c.body.note));
  route('POST', '/api/admin/rooms/:id/closed', (c) => game.adminCloseRoom(c.user.id, intParam(c.params.id), !!c.body.closed));
  route('POST', '/api/admin/announce', (c) => {
    if (c.user.role !== 'admin') throw new ApiError(403, 'forbidden');
    hub.announce(String(c.body.text ?? '').slice(0, 200));
    return { ok: true };
  });

  route('GET', '/health', () => ({ ok: true, online: hub.onlineTotal() }), { auth: false });

  const MAX_BODY = 160 * 1024;
  const readBody = (req) =>
    new Promise((resolve, reject) => {
      const chunks = [];
      let n = 0;
      req.on('data', (d) => {
        n += d.length;
        if (n > MAX_BODY) {
          reject(new ApiError(413, 'too_large'));
          req.destroy();
        } else chunks.push(d);
      });
      req.on('end', () => {
        if (!n) return resolve({});
        try {
          const v = JSON.parse(Buffer.concat(chunks).toString('utf8'));
          resolve(v && typeof v === 'object' ? v : {});
        } catch {
          reject(new ApiError(400, 'bad_json'));
        }
      });
      req.on('error', reject);
    });

  const server = http.createServer(async (req, res) => {
    const out = (status, obj) => {
      res.writeHead(status, {
        'Content-Type': 'application/json; charset=utf-8',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Authorization, Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      });
      res.end(JSON.stringify(obj));
    };
    try {
      if (req.method === 'OPTIONS') return out(204, {});
      const url = new URL(req.url, 'http://x');
      let matched = null;
      let pathExists = false;
      for (const r of routes) {
        const m = r.re.exec(url.pathname);
        if (!m) continue;
        pathExists = true;
        if (r.method !== req.method) continue;
        matched = { r, params: Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])])) };
        break;
      }
      if (!matched) return out(pathExists ? 405 : 404, { error: pathExists ? 'method_not_allowed' : 'not_found' });
      const ctx = {
        params: matched.params,
        query: Object.fromEntries(url.searchParams),
        ip: req.socket.remoteAddress || '?',
        body: req.method === 'GET' || req.method === 'DELETE' ? {} : await readBody(req),
      };
      if (matched.r.auth) {
        const token = (req.headers.authorization || '').replace(/^Bearer /, '');
        const user = game.authenticate(token);
        if (!user) return out(401, { error: 'unauthorized', message: 'Войдите заново' });
        ctx.user = user;
        ctx.token = token;
      }
      out(200, matched.r.handler(ctx));
    } catch (e) {
      if (e instanceof ApiError) return out(e.status, { error: e.code, message: e.message });
      console.error(e);
      out(500, { error: 'server_error' });
    }
  });

  server.on('upgrade', (req, socket) => {
    socket.on('error', () => {});
    handleUpgrade(
      req,
      socket,
      (r) => {
        const url = new URL(r.url, 'http://x');
        if (url.pathname !== '/ws') return null;
        return game.authenticate(url.searchParams.get('token'));
      },
      (conn, user) => hub.attach(conn, user),
    );
  });

  const hb = setInterval(() => hub.heartbeat(), 30000);
  const gb = setInterval(settle, 5000);
  gb.unref();
  hb.unref();
  server.on('close', () => { clearInterval(hb); clearInterval(gb); });

  return { server, game, hub, db };
}

// Запуск как основной модуль.
if (import.meta.url === `file://${process.argv[1]}`) {
  const port = Number(process.env.PORT || 8080);
  const { server } = createApp({
    dbPath: process.env.DB_PATH || './data/loftly.db',
    adminUsername: process.env.ADMIN_USERNAME || '',
  });
  server.listen(port, () => console.log(`Loftly server listening on :${port}`));
}
