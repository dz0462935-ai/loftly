import 'dart:collection';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../clothes.dart';
import '../models.dart';
import '../store.dart';
import '../ui.dart';
import '../widgets/avatar.dart';

/// Импорт одежды из своей картинки (PNG/JPG/WebP): убирает фон, обрезает по краю,
/// даёт подогнать вещь по размеру и положению прямо на теле и публикует в магазин.
/// Используйте только свои рисунки или картинки с подходящей лицензией.
class ImportClothScreen extends StatefulWidget {
  const ImportClothScreen({super.key});

  @override
  State<ImportClothScreen> createState() => _ImportClothState();
}

class _ImportClothState extends State<ImportClothScreen> {
  static const _draftId = 'draft:imp';
  String _slot = 'top';
  Uint8List? _raw;
  int _rw = 0, _rh = 0;
  ui.Image? _src;
  double _tol = 40;
  double _scale = 1;
  double _dx = 0;
  double _dy = 0;
  bool _back = false;
  bool _busy = false;
  bool _gems = false;
  int _gen = 0;
  final _name = TextEditingController();
  final _price = TextEditingController(text: '100');

  @override
  void dispose() {
    _name.dispose();
    _price.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (x == null) return;
    final bytes = await x.readAsBytes();
    // крупные картинки сразу уменьшаем: для вещи хватает ~600 пикселей
    final codec = await ui.instantiateImageCodec(bytes, targetWidth: 600);
    final img = (await codec.getNextFrame()).image;
    final data = await img.toByteData(format: ui.ImageByteFormat.rawRgba);
    if (data == null) return;
    _raw = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
    _rw = img.width;
    _rh = img.height;
    await _prepare();
  }

  /// Убирает фон (если у картинки нет прозрачности), обрезает по содержимому.
  Future<void> _prepare() async {
    final raw = _raw;
    if (raw == null) return;
    final w = _rw, h = _rh;
    final px = Uint8List.fromList(raw);
    var clear = 0;
    for (var i = 3; i < px.length; i += 4) {
      if (px[i] < 128) clear++;
    }
    if (clear < w * h * 0.01) _removeBg(px, w, h, _tol.round() * 3);
    var x0 = w, y0 = h, x1 = -1, y1 = -1;
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        if (px[(y * w + x) * 4 + 3] > 10) {
          x0 = math.min(x0, x);
          x1 = math.max(x1, x);
          y0 = math.min(y0, y);
          y1 = math.max(y1, y);
        }
      }
    }
    if (x1 < 0) {
      StoreScope.of(context).toast('На картинке ничего не осталось — уменьшите «Фон»');
      return;
    }
    final cw = x1 - x0 + 1, ch = y1 - y0 + 1;
    final out = Uint8List(cw * ch * 4);
    for (var y = 0; y < ch; y++) {
      out.setRange(y * cw * 4, (y + 1) * cw * 4, px, ((y + y0) * w + x0) * 4);
    }
    _src = await imageFromPixels(out, cw, ch);
    await _refresh();
  }

  /// Заливка от краёв: всё, что похоже на цвет фона по углам, становится прозрачным.
  void _removeBg(Uint8List px, int w, int h, int tol) {
    int at(int x, int y, int ch) => px[(y * w + x) * 4 + ch];
    final corners = [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)];
    final bg = [
      for (var ch = 0; ch < 3; ch++) corners.fold<int>(0, (a, c) => a + at(c.$1, c.$2, ch)) ~/ 4,
    ];
    bool isBg(int i) =>
        (px[i * 4] - bg[0]).abs() + (px[i * 4 + 1] - bg[1]).abs() + (px[i * 4 + 2] - bg[2]).abs() <= tol;
    final seen = Uint8List(w * h);
    final q = Queue<int>();
    void add(int x, int y) {
      final i = y * w + x;
      if (seen[i] == 0 && isBg(i)) {
        seen[i] = 1;
        q.add(i);
      }
    }

    for (var x = 0; x < w; x++) {
      add(x, 0);
      add(x, h - 1);
    }
    for (var y = 0; y < h; y++) {
      add(0, y);
      add(w - 1, y);
    }
    while (q.isNotEmpty) {
      final i = q.removeFirst();
      final x = i % w, y = i ~/ w;
      if (x > 0) add(x - 1, y);
      if (x < w - 1) add(x + 1, y);
      if (y > 0) add(x, y - 1);
      if (y < h - 1) add(x, y + 1);
    }
    for (var i = 0; i < w * h; i++) {
      if (seen[i] == 1) px[i * 4 + 3] = 0;
    }
    // полупрозрачная кромка, чтобы не оставалось светлого ободка
    for (var y = 1; y < h - 1; y++) {
      for (var x = 1; x < w - 1; x++) {
        final i = y * w + x;
        if (seen[i] == 0 && (seen[i - 1] == 1 || seen[i + 1] == 1 || seen[i - w] == 1 || seen[i + w] == 1)) {
          px[i * 4 + 3] = 140;
        }
      }
    }
  }

  /// Кладёт вещь на холст слота ([k]-кратного размера) с учётом масштаба и сдвига.
  Future<ui.Image?> _compose(int k) async {
    final src = _src;
    if (src == null) return null;
    final spec = clothSpecs[_slot]!;
    final tw = spec.w * k, th = spec.h * k;
    final rec = ui.PictureRecorder();
    final c = Canvas(rec);
    final fit = math.min(tw / src.width, th / src.height) * _scale;
    c.drawImageRect(
      src,
      Rect.fromLTWH(0, 0, src.width.toDouble(), src.height.toDouble()),
      Rect.fromCenter(
        center: Offset(tw / 2 + _dx * tw, th / 2 + _dy * th),
        width: src.width * fit,
        height: src.height * fit,
      ),
      Paint()..filterQuality = FilterQuality.high,
    );
    return rec.endRecording().toImage(tw, th);
  }

  Future<void> _refresh() async {
    final g = ++_gen;
    final img = await _compose(2);
    if (img == null || g != _gen) return;
    await clothesCache.putImage(_draftId, img);
    if (mounted) setState(() {});
  }

  Future<Uint8List?> _png(int k) async {
    final img = await _compose(k);
    final bd = await img?.toByteData(format: ui.ImageByteFormat.png);
    return bd == null ? null : bd.buffer.asUint8List(bd.offsetInBytes, bd.lengthInBytes);
  }

  Future<void> _publish() async {
    final store = StoreScope.of(context);
    final name = _name.text.trim();
    final price = int.tryParse(_price.text.trim());
    if (_src == null) return store.toast('Сначала выберите картинку');
    if (name.isEmpty) return store.toast('Введите название вещи');
    if (price == null || price < 0) return store.toast('Цена: целое число от 0');
    setState(() => _busy = true);
    String? err;
    try {
      var png = await _png(2);
      if (png != null && png.length > 90000) png = await _png(1);
      if (png == null || png.length > 90000) {
        err = 'Картинка слишком сложная — возьмите проще';
      } else {
        err = await store.publishCloth(slot: _slot, name: name, price: price, gems: _gems, png: png);
      }
    } catch (_) {
      err = 'Не удалось сохранить вещь';
    }
    if (!mounted) return;
    setState(() => _busy = false);
    store.toast(err ?? 'Вещь в магазине! Она уже надета на вас');
  }

  User _preview(AppStore s) {
    final m = s.me;
    final u = User(
      id: 'preview',
      name: '',
      skin: m.skin,
      top: m.top,
      bottom: m.bottom,
      shoes: m.shoes,
      hairColor: m.hairColor,
      hair: m.hair,
    );
    if (_src != null) u.custom[_slot] = _draftId;
    return u;
  }

  Widget _slider(String label, double v, double min, double max, void Function(double) set, {bool bg = false}) {
    return Row(
      children: [
        SizedBox(width: 78, child: Text(label, style: const TextStyle(color: Ui.dim))),
        Expanded(
          child: Slider(
            value: v,
            min: min,
            max: max,
            onChanged: (x) {
              setState(() => set(x));
              if (!bg) _refresh();
            },
            onChangeEnd: (_) {
              if (bg) _prepare();
            },
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Импорт одежды')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
        children: [
          const Text(
            'Загружайте только свои рисунки или картинки, на которые у вас есть права.',
            style: TextStyle(color: Ui.dim, fontSize: 12),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 340,
            child: Stack(
              children: [
                Positioned.fill(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: Ui.background,
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                ),
                Center(
                  child: ListenableBuilder(
                    listenable: clothesCache,
                    builder: (_, __) => AspectRatio(
                      aspectRatio: 104 / 320,
                      child: FittedBox(
                        child: SizedBox(
                          width: 104,
                          height: 320,
                          child: CustomPaint(painter: _PreviewPainter(_preview(store), _back)),
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  right: 6,
                  top: 6,
                  child: IconButton.filledTonal(
                    onPressed: () => setState(() => _back = !_back),
                    icon: const Icon(Icons.flip_camera_android_rounded),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            children: [
              for (final s in clothSlots)
                ChoiceChip(
                  label: Text(clothSpecs[s]!.title),
                  selected: _slot == s,
                  onSelected: (_) {
                    setState(() {
                      _slot = s;
                      _dx = 0;
                      _dy = 0;
                      _scale = 1;
                    });
                    _refresh();
                  },
                ),
            ],
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: _pick,
            icon: const Icon(Icons.image_rounded),
            label: Text(_src == null ? 'Выбрать картинку' : 'Выбрать другую'),
          ),
          if (_src != null) ...[
            const SizedBox(height: 4),
            _slider('Фон', _tol, 5, 100, (v) => _tol = v, bg: true),
            _slider('Размер', _scale, .3, 1.8, (v) => _scale = v),
            _slider('Влево/вправо', _dx, -.5, .5, (v) => _dx = v),
            _slider('Вверх/вниз', _dy, -.5, .5, (v) => _dy = v),
          ],
          const SizedBox(height: 8),
          TextField(
            controller: _name,
            maxLength: 24,
            decoration: const InputDecoration(labelText: 'Название вещи'),
          ),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _price,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Цена'),
                ),
              ),
              const SizedBox(width: 12),
              const Text('💎'),
              Switch(value: _gems, onChanged: (v) => setState(() => _gems = v)),
            ],
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: _busy ? null : _publish,
            child: Text(_busy ? 'Публикую…' : 'Опубликовать в магазин'),
          ),
        ],
      ),
    );
  }
}

class _PreviewPainter extends CustomPainter {
  final User u;
  final bool back;
  _PreviewPainter(this.u, this.back);

  @override
  void paint(Canvas c, Size s) => paintDoll(c, u, back: back);

  @override
  bool shouldRepaint(_PreviewPainter old) => true;
}
