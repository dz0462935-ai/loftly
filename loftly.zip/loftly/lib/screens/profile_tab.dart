import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../ui.dart';
import '../widgets/avatar.dart';
import '../widgets/iso.dart';
import 'admin_screen.dart';
import 'character_editor.dart';
import 'clothes_studio.dart';
import 'import_cloth.dart';

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final me = store.me;
    final stock = store.furnInv.entries.where((e) => e.value > 0).toList();
    final myRooms = store.rooms.where((r) => r.ownerId == 'me').length;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 120),
      children: [
        GlassCard(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Ui.a(Ui.violet, .45), Ui.a(Ui.accent, .18)],
          ),
          borderColor: Ui.a(Colors.white, .22),
          child: Column(
            children: [
              SizedBox(
                height: 190,
                child: Stack(
                  alignment: Alignment.bottomCenter,
                  children: [
                    Positioned(
                      bottom: 6,
                      child: Container(
                        width: 190,
                        height: 44,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [Ui.a(Ui.accent, .55), Ui.a(Ui.accent, 0)],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 10,
                      child: Container(
                        width: 120,
                        height: 22,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(60),
                          color: Ui.a(Colors.black, .28),
                        ),
                      ),
                    ),
                    Positioned(bottom: 18, child: AvatarFigure(user: me, size: 118)),
                  ],
                ),
              ),
              const SizedBox(height: 6),
              InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => _rename(context, store),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Flexible(
                        child: Text(
                          me.name,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Icon(Icons.edit_rounded, size: 18, color: Ui.dim),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Tag(
                roleName(me.role),
                color: me.role == Role.admin
                    ? Ui.accent
                    : me.role == Role.moderator
                        ? Ui.green
                        : Ui.violet,
                icon: me.role == Role.player ? null : Icons.star_rounded,
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            _Stat('🪙', '${me.coins}', 'монеты'),
            const SizedBox(width: 8),
            _Stat('💎', '${me.gems}', 'кристаллы'),
            const SizedBox(width: 8),
            _Stat('🏠', '$myRooms', 'комнаты'),
            const SizedBox(width: 8),
            _Stat('🔥', '${store.streak}', 'серия'),
          ],
        ),
        const SizedBox(height: 4),
        const SectionTitle('Склад мебели'),
        stock.isEmpty
            ? const GlassCard(
                child: Text(
                  'Пусто. Мебель можно купить в магазине и расставить в своей комнате.',
                  style: TextStyle(color: Ui.dim),
                ),
              )
            : Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final e in stock)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: Ui.a(Colors.white, .08),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Ui.a(Colors.white, .14)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(furnCatalog[e.key]!.emoji, style: const TextStyle(fontSize: 20)),
                          const SizedBox(width: 8),
                          Text(furnCatalog[e.key]!.name,
                              style: const TextStyle(fontWeight: FontWeight.w700)),
                          const SizedBox(width: 8),
                          Tag('×${e.value}', color: Ui.gold),
                        ],
                      ),
                    ),
                ],
              ),
        const SizedBox(height: 4),
        const SectionTitle('Одежда'),
        _AdminTile(
          icon: Icons.face_retouching_natural_rounded,
          title: 'Редактор персонажа',
          subtitle: 'Одежда, причёска, цвет кожи, наряды и коллекции',
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => const CharacterEditorScreen()),
          ),
        ),
        if (me.role == Role.admin) ...[
          const SectionTitle('Администрирование'),
          _AdminTile(
            icon: Icons.checkroom_rounded,
            title: 'Студия одежды',
            subtitle: 'Рисуйте свою одежду и публикуйте в магазин',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const ClothesStudioScreen()),
            ),
          ),
          const SizedBox(height: 8),
          _AdminTile(
            icon: Icons.add_photo_alternate_rounded,
            title: 'Импорт одежды из картинки',
            subtitle: 'Загрузите PNG/JPG — фон уберётся, вещь встанет на тело',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const ImportClothScreen()),
            ),
          ),
          if (store.api == null) ...[
            const SizedBox(height: 8),
            _AdminTile(
              icon: Icons.admin_panel_settings_rounded,
              title: 'Админ-панель',
              subtitle: 'Игроки, комнаты, экономика',
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const AdminScreen()),
              ),
            ),
          ],
        ],
      ],
    );
  }

  void _rename(BuildContext context, AppStore store) {
    final c = TextEditingController(text: store.me.name);
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Ваше имя'),
        content: TextField(
          controller: c,
          maxLength: 20,
          autofocus: true,
          decoration: Ui.input('Имя в игре'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Отмена')),
          FilledButton(
            onPressed: () {
              store.updateProfile(name: c.text);
              Navigator.pop(ctx);
            },
            child: const Text('Сохранить'),
          ),
        ],
      ),
    ).then((_) => c.dispose());
  }
}

class _Stat extends StatelessWidget {
  final String icon;
  final String value;
  final String label;
  const _Stat(this.icon, this.value, this.label);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: Ui.a(Colors.white, .07),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Ui.a(Colors.white, .12)),
        ),
        child: Column(
          children: [
            Text(icon, style: const TextStyle(fontSize: 22)),
            const SizedBox(height: 2),
            Text(value, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
            Text(label, style: const TextStyle(fontSize: 11, color: Ui.dim)),
          ],
        ),
      ),
    );
  }
}

class _AdminTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _AdminTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(gradient: Ui.brand, borderRadius: BorderRadius.circular(14)),
            child: Icon(icon),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                Text(subtitle, style: const TextStyle(color: Ui.dim, fontSize: 12.5)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded),
        ],
      ),
    );
  }
}
