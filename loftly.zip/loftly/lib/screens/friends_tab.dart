import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../ui.dart';
import '../widgets/avatar.dart';
import 'room_screen.dart';

class FriendsTab extends StatelessWidget {
  const FriendsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final friends = store.friendList;
    final requests = store.incomingRequests;
    final online = friends.where((f) => store.locationOf(f.id) != null).toList();
    final offline = friends.where((f) => store.locationOf(f.id) == null).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 120),
      children: [
        GlassCard(
          onTap: () => showModalBottomSheet<void>(
            context: context,
            showDragHandle: true,
            isScrollControlled: true,
            builder: (_) => const _FindSheet(),
          ),
          gradient: LinearGradient(colors: [Ui.a(Ui.cyan, .3), Ui.a(Ui.violet, .45)]),
          borderColor: Ui.a(Colors.white, .22),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: Ui.a(Colors.white, .18),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.person_search_rounded, size: 28),
              ),
              const SizedBox(width: 14),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Найти друзей',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    SizedBox(height: 2),
                    Text('Люди, которые сейчас в игре',
                        style: TextStyle(color: Ui.dim, fontSize: 13)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, size: 28),
            ],
          ),
        ),
        if (requests.isNotEmpty) ...[
          SectionTitle('Запросы в друзья',
              trailing: Tag('${requests.length}', color: Ui.accent)),
          for (final id in requests)
            if (store.users[id] != null) _RequestTile(user: store.users[id]!),
        ],
        SectionTitle('В сети', trailing: Tag('${online.length}', color: Ui.green)),
        if (online.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 4),
            child: Text('Сейчас никого из друзей нет в комнатах.', style: TextStyle(color: Ui.dim)),
          ),
        for (final f in online) _FriendTile(user: f),
        SectionTitle('Не в сети', trailing: Tag('${offline.length}', color: Ui.dim)),
        if (friends.isEmpty)
          const EmptyState(
            icon: Icons.group_add_rounded,
            title: 'Друзей пока нет',
            text: 'Нажмите «Найти друзей», чтобы добавить первых.',
          ),
        for (final f in offline) _FriendTile(user: f),
      ],
    );
  }
}

class _RequestTile extends StatelessWidget {
  final User user;
  const _RequestTile({required this.user});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GlassCard(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            AvatarBadge(user: user, radius: 22),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(user.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                  const Text('хочет дружить', style: TextStyle(color: Ui.dim, fontSize: 12)),
                ],
              ),
            ),
            IconButton.filled(
              tooltip: 'Принять',
              style: IconButton.styleFrom(backgroundColor: Ui.green, foregroundColor: Colors.white),
              icon: const Icon(Icons.check_rounded),
              onPressed: () => store.acceptRequest(user.id),
            ),
            const SizedBox(width: 4),
            IconButton.filledTonal(
              tooltip: 'Отклонить',
              icon: const Icon(Icons.close_rounded),
              onPressed: () => store.declineRequest(user.id),
            ),
          ],
        ),
      ),
    );
  }
}

class _FriendTile extends StatelessWidget {
  final User user;
  const _FriendTile({required this.user});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final roomId = store.locationOf(user.id);
    final room = roomId == null ? null : store.roomById(roomId);
    final isOnline = room != null;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GlassCard(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        onTap: room == null
            ? null
            : () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => RoomScreen(roomId: room.id)),
                ),
        child: Row(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                AvatarBadge(user: user, radius: 22),
                Positioned(
                  right: -1,
                  bottom: -1,
                  child: Container(
                    width: 13,
                    height: 13,
                    decoration: BoxDecoration(
                      color: isOnline ? Ui.green : const Color(0xFF6C60A8),
                      shape: BoxShape.circle,
                      border: Border.all(color: Ui.bg1, width: 2),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(user.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                  Text(
                    isOnline ? 'В комнате «${room.name}»' : 'Не в сети',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: isOnline ? Ui.green : Ui.dim, fontSize: 12.5),
                  ),
                ],
              ),
            ),
            if (isOnline)
              FilledButton(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => RoomScreen(roomId: room.id)),
                ),
                style: FilledButton.styleFrom(minimumSize: const Size(64, 38)),
                child: const Text('Зайти'),
              ),
            IconButton(
              tooltip: 'Удалить из друзей',
              icon: const Icon(Icons.person_remove_outlined, size: 20),
              onPressed: () => showDialog<void>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: Text('Удалить ${user.name} из друзей?'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Отмена')),
                    FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: Colors.redAccent),
                      onPressed: () {
                        store.removeFriend(user.id);
                        Navigator.pop(ctx);
                      },
                      child: const Text('Удалить'),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FindSheet extends StatelessWidget {
  const _FindSheet();

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final list = store.discoverable;
    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.7),
        child: list.isEmpty
            ? const Padding(
                padding: EdgeInsets.all(24),
                child: EmptyState(icon: Icons.groups_rounded, title: 'Новых людей пока нет'),
              )
            : ListView(
                shrinkWrap: true,
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                children: [
                  const Padding(
                    padding: EdgeInsets.fromLTRB(4, 0, 4, 10),
                    child: Text('Люди рядом',
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                  ),
                  for (final u in list)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: GlassCard(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        child: Row(
                          children: [
                            AvatarBadge(user: u, radius: 22),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(u.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                            ),
                            FilledButton.tonal(
                              onPressed: () => store.sendRequest(u.id),
                              style: FilledButton.styleFrom(minimumSize: const Size(64, 38)),
                              child: const Text('Добавить'),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
      ),
    );
  }
}
