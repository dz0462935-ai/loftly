import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../clothes.dart';
import '../models.dart';
import '../store.dart';
import '../widgets/avatar.dart';

/// Студия одежды (только для админа): рисуем вещь по пикселям поверх силуэта тела,
/// смотрим её на аватаре и публикуем в магазин.
class ClothesStudioScreen extends StatefulWidget {
  const ClothesStudioScreen({super.key});

  @override
  State<ClothesStudioScreen> createState() => _ClothesStudioScreenState();
}

class _ClothesStudioScreenState extends State<ClothesStudioScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabs;
  final GlobalKey<_EditorState> _editorKey = GlobalKey<_EditorState>();

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this)..addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _edit(Map<String, dynamic> meta) async {
    final ok = await _editorKey.currentState?.loadFromItem(meta) ?? false;
    if (ok) _tabs.animateTo(0);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Студия одежды'),
        bottom: TabBar(
          controller: _tabs,
          tabs: const [Tab(text: 'Рисовать'), Tab(text: 'Мои вещи')],
        ),
      ),
      body: IndexedStack(
        index: _tabs.index,
        children: [
          _Editor(key: _editorKey),
          _MyClothes(onEdit: _edit, active: _tabs.index == 1),
        ],
      ),
    );
  }
}

// ---------- Палитра ----------

int _hsl(double h, double s, double l) {
  final c = (1 - (2 * l - 1).abs()) * s;
  final x = c * (1 - ((h / 60) % 2 - 1).abs());
  final m = l - c / 2;
  double r = 0, g = 0, b = 0;
  if (h < 60) {
    r = c;
    g = x;
  } else if (h < 120) {
    r = x;
    g = c;
  } else if (h < 180) {
    g = c;
    b = x;
  } else if (h < 240) {
    g = x;
    b = c;
  } else if (h < 300) {
    r = x;
    b = c;
  } else {
    r = c;
    b = x;
  }
  int to(double v) => math.max(0, math.min(255, ((v + m) * 255).round()));
  return 0xFF000000 | (to(r) << 16) | (to(g) << 8) | to(b);
}

final List<int> _palette = () {
  final out = <int>[0xFFFFFFFF, 0xFFD9D9D9, 0xFFA6A6A6, 0xFF737373, 0xFF404040, 0xFF000000];
  out.addAll(const [0xFFF7D5BC, 0xFFF1C27D, 0xFFC68642, 0xFF8D5524]);
  for (final l in const [0.85, 0.68, 0.52, 0.38, 0.24]) {
    for (final h in const [0.0, 25.0, 50.0, 90.0, 150.0, 190.0, 215.0, 250.0, 285.0, 325.0]) {
      out.add(_hsl(h, 0.72, l));
    }
  }
  return out;
}();

// ---------- Слой (рисунок одного слота) ----------

class _Layer {
  final int w;
  final int h;
  Uint32List px;
  final List<Uint32List> undo = [];
  final List<Uint32List> redo = [];

  _Layer(this.w, this.h) : px = Uint32List(w * h);

  bool get isEmpty => px.every((v) => (v >>> 24) == 0);

  void snapshot() {
    undo.add(Uint32List.fromList(px));
    if (undo.length > 40) undo.removeAt(0);
    redo.clear();
  }
}

enum _Tool { pen, eraser, fill, pick }

// ---------- Редактор ----------

class _Editor extends StatefulWidget {
  const _Editor({super.key});

  @override
  State<_Editor> createState() => _EditorState();
}

class _EditorState extends State<_Editor> {
  String _slot = 'top';
  final Map<String, _Layer> _layers = {
    for (final s in clothSlots) s: _Layer(clothSpecs[s]!.w, clothSpecs[s]!.h),
  };
  _Tool _tool = _Tool.pen;
  int _brush = 1;
  bool _mirror = true;
  bool _grid = true;
  bool _guide = true;
  int _rgb = 0xFFE53935;
  bool _drawing = false;
  bool _busy = false;
  String? _editingId;
  int _lx = -1;
  int _ly = -1;
  Timer? _previewTimer;

  final TextEditingController _name = TextEditingController();
  final TextEditingController _price = TextEditingController(text: '100');
  bool _gems = false;

  _Layer get _layer => _layers[_slot]!;
  ClothSpec get _spec => clothSpecs[_slot]!;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _pushDraft());
  }

  @override
  void dispose() {
    _previewTimer?.cancel();
    _name.dispose();
    _price.dispose();
    super.dispose();
  }

  // ----- рисование -----

  (int, int) _cellOf(Offset p, double cell) => ((p.dx / cell).floor(), (p.dy / cell).floor());

  bool _inside(int x, int y) => x >= 0 && y >= 0 && x < _spec.w && y < _spec.h;

  void _put(int x, int y, int v) {
    if (!_inside(x, y)) return;
    final w = _spec.w;
    _layer.px[y * w + x] = v;
    if (_mirror) _layer.px[y * w + (w - 1 - x)] = v;
  }

  void _stamp(int x, int y) {
    final v = _tool == _Tool.eraser ? 0 : _rgb;
    final off = _brush ~/ 2;
    for (var dx = 0; dx < _brush; dx++) {
      for (var dy = 0; dy < _brush; dy++) {
        _put(x + dx - off, y + dy - off, v);
      }
    }
  }

  void _line(int x0, int y0, int x1, int y1) {
    var x = x0, y = y0;
    final dx = (x1 - x0).abs();
    final dy = -(y1 - y0).abs();
    final sx = x0 < x1 ? 1 : -1;
    final sy = y0 < y1 ? 1 : -1;
    var err = dx + dy;
    while (true) {
      _stamp(x, y);
      if (x == x1 && y == y1) break;
      final e2 = 2 * err;
      if (e2 >= dy) {
        err += dy;
        x += sx;
      }
      if (e2 <= dx) {
        err += dx;
        y += sy;
      }
    }
  }

  void _flood(int sx, int sy, int v) {
    if (!_inside(sx, sy)) return;
    final w = _spec.w;
    final h = _spec.h;
    final px = _layer.px;
    final target = px[sy * w + sx];
    if (target == v) return;
    final stack = <int>[sy * w + sx];
    while (stack.isNotEmpty) {
      final i = stack.removeLast();
      if (px[i] != target) continue;
      px[i] = v;
      final x = i % w;
      final y = i ~/ w;
      if (x > 0) stack.add(i - 1);
      if (x < w - 1) stack.add(i + 1);
      if (y > 0) stack.add(i - w);
      if (y < h - 1) stack.add(i + w);
    }
  }

  void _down(Offset p, double cell) {
    final (x, y) = _cellOf(p, cell);
    if (!_inside(x, y)) return;
    if (_tool == _Tool.pick) {
      final v = _layer.px[y * _spec.w + x];
      if ((v >>> 24) != 0) setState(() => _rgb = v);
      return;
    }
    _layer.snapshot();
    _drawing = true;
    if (_tool == _Tool.fill) {
      _flood(x, y, _rgb);
      if (_mirror) _flood(_spec.w - 1 - x, y, _rgb);
      _drawing = false;
    } else {
      _lx = x;
      _ly = y;
      _stamp(x, y);
    }
    setState(() {});
    _schedulePreview();
  }

  void _move(Offset p, double cell) {
    if (!_drawing || _tool == _Tool.fill || _tool == _Tool.pick) return;
    var (x, y) = _cellOf(p, cell);
    x = math.max(0, math.min(_spec.w - 1, x));
    y = math.max(0, math.min(_spec.h - 1, y));
    if (x == _lx && y == _ly) return;
    _line(_lx, _ly, x, y);
    _lx = x;
    _ly = y;
    setState(() {});
    _schedulePreview();
  }

  void _up() {
    if (!_drawing) return;
    _drawing = false;
    _schedulePreview();
  }

  void _undo() {
    final l = _layer;
    if (l.undo.isEmpty) return;
    l.redo.add(Uint32List.fromList(l.px));
    l.px = l.undo.removeLast();
    setState(() {});
    _schedulePreview();
  }

  void _redo() {
    final l = _layer;
    if (l.redo.isEmpty) return;
    l.undo.add(Uint32List.fromList(l.px));
    l.px = l.redo.removeLast();
    setState(() {});
    _schedulePreview();
  }

  void _clear() {
    _layer.snapshot();
    _layer.px = Uint32List(_spec.w * _spec.h);
    setState(() {});
    _schedulePreview();
  }

  // ----- предпросмотр и экспорт -----

  void _schedulePreview() {
    _previewTimer ??= Timer(const Duration(milliseconds: 120), () {
      _previewTimer = null;
      if (mounted) _pushDraft();
    });
  }

  Uint8List _rgba(_Layer l) {
    final out = Uint8List(l.w * l.h * 4);
    for (var i = 0; i < l.px.length; i++) {
      final v = l.px[i];
      out[i * 4] = (v >> 16) & 255;
      out[i * 4 + 1] = (v >> 8) & 255;
      out[i * 4 + 2] = v & 255;
      out[i * 4 + 3] = (v >>> 24) & 255;
    }
    return out;
  }

  Future<void> _pushDraft() async {
    final slot = _slot;
    final l = _layers[slot]!;
    final img = await imageFromPixels(_rgba(l), l.w, l.h);
    await clothesCache.putImage('draft:$slot', img);
  }

  Future<Uint8List> _encodePng() async {
    final l = _layer;
    final img = await imageFromPixels(_rgba(l), l.w, l.h);
    final bd = await img.toByteData(format: ui.ImageByteFormat.png);
    return Uint8List.view(bd!.buffer, bd.offsetInBytes, bd.lengthInBytes);
  }

  /// Загружает готовую вещь в редактор (кнопка «Править» в списке).
  Future<bool> loadFromItem(Map<String, dynamic> meta) async {
    final store = StoreScope.of(context);
    final id = meta['id'] as String;
    final slot = meta['slot'] as String;
    final spec = clothSpecs[slot];
    if (spec == null) return false;
    ui.Image? img = clothesCache.image(id);
    for (var i = 0; i < 20 && img == null; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 150));
      img = clothesCache.image(id);
    }
    if (img == null || img.width != spec.w || img.height != spec.h) {
      store.toast('Не удалось загрузить картинку вещи');
      return false;
    }
    final data = await img.toByteData(format: ui.ImageByteFormat.rawRgba);
    if (data == null || !mounted) return false;
    final l = _Layer(spec.w, spec.h);
    for (var i = 0; i < spec.w * spec.h; i++) {
      final r = data.getUint8(i * 4);
      final g = data.getUint8(i * 4 + 1);
      final b = data.getUint8(i * 4 + 2);
      final a = data.getUint8(i * 4 + 3);
      l.px[i] = a < 128 ? 0 : (0xFF000000 | (r << 16) | (g << 8) | b);
    }
    setState(() {
      _layers[slot] = l;
      _slot = slot;
      _editingId = id;
      _name.text = meta['name'] as String;
      _price.text = '${meta['price']}';
      _gems = meta['gems'] == true;
    });
    _schedulePreview();
    return true;
  }

  void _newItem() {
    setState(() {
      _editingId = null;
      _name.clear();
    });
  }

  Future<void> _publish() async {
    final store = StoreScope.of(context);
    final name = _name.text.trim();
    final price = int.tryParse(_price.text.trim());
    if (name.isEmpty) {
      store.toast('Введите название вещи');
      return;
    }
    if (price == null || price < 0) {
      store.toast('Цена: целое число от 0');
      return;
    }
    if (_layer.isEmpty) {
      store.toast('Сначала нарисуйте вещь');
      return;
    }
    setState(() => _busy = true);
    String? err;
    try {
      final png = await _encodePng();
      if (png.length > 36000) {
        err = 'Слишком сложный рисунок — упростите его';
      } else if (_editingId != null) {
        err = await store.updateCloth(_editingId!, name: name, price: price, gems: _gems, png: png);
      } else {
        err = await store.publishCloth(slot: _slot, name: name, price: price, gems: _gems, png: png);
      }
    } catch (_) {
      err = 'Не удалось сохранить вещь';
    }
    if (!mounted) return;
    setState(() => _busy = false);
    store.toast(err ?? (_editingId != null ? 'Вещь обновлена' : 'Вещь в магазине! Она уже надета на вас'));
    if (err == null && _editingId == null) {
      setState(() => _editingId = null);
    }
  }

  // ----- интерфейс -----

  User _previewUser(AppStore s, {required bool withDraft}) {
    final m = s.me;
    final u = User(
      id: 'preview',
      name: '',
      skin: m.skin,
      top: m.top,
      bottom: m.bottom,
      shoes: m.shoes,
      hairColor: m.hairColor,
      hair: m.hair,
      hat: m.hat,
    );
    u.custom.addAll(m.custom);
    if (withDraft) {
      u.custom[_slot] = 'draft:$_slot';
    } else {
      u.custom.remove(_slot);
    }
    if (_slot == 'hat') u.hat = 0;
    return u;
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final spec = _spec;
    final guideUser = _previewUser(store, withDraft: false);
    final wearUser = _previewUser(store, withDraft: true);

    return LayoutBuilder(builder: (context, c) {
      final maxCanvasH = c.maxHeight * 0.46;
      final cell = math.max(2.0, math.min((c.maxWidth - 24) / spec.w, maxCanvasH / spec.h));
      final cw = spec.w * cell;
      final ch = spec.h * cell;
      return Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Wrap(
                        spacing: 6,
                        runSpacing: 0,
                        children: [
                          for (final s in clothSlots)
                            ChoiceChip(
                              label: Text(clothSpecs[s]!.title),
                              selected: _slot == s,
                              onSelected: (_) {
                                setState(() {
                                  _slot = s;
                                  _editingId = null;
                                });
                                _pushDraft();
                              },
                            ),
                        ],
                      ),
                      Row(
                        children: [
                          IconButton(
                            tooltip: 'Отменить',
                            onPressed: _layer.undo.isEmpty ? null : _undo,
                            icon: const Icon(Icons.undo),
                          ),
                          IconButton(
                            tooltip: 'Вернуть',
                            onPressed: _layer.redo.isEmpty ? null : _redo,
                            icon: const Icon(Icons.redo),
                          ),
                          IconButton(
                            tooltip: 'Очистить',
                            onPressed: _layer.isEmpty ? null : _clear,
                            icon: const Icon(Icons.delete_outline),
                          ),
                          Text('${spec.w}×${spec.h}', style: Theme.of(context).textTheme.bodySmall),
                        ],
                      ),
                    ],
                  ),
                ),
                ListenableBuilder(
                  listenable: clothesCache,
                  builder: (context, _) => AvatarFigure(user: wearUser, size: 72),
                ),
              ],
            ),
          ),
          Container(
            width: cw,
            height: ch,
            foregroundDecoration: BoxDecoration(border: Border.all(color: Colors.black26)),
            child: Listener(
              behavior: HitTestBehavior.opaque,
              onPointerDown: (e) => _down(e.localPosition, cell),
              onPointerMove: (e) => _move(e.localPosition, cell),
              onPointerUp: (_) => _up(),
              onPointerCancel: (_) => _up(),
              child: CustomPaint(
                size: Size(cw, ch),
                painter: _PixelPainter(
                  px: _layer.px,
                  spec: spec,
                  cell: cell,
                  guideUser: guideUser,
                  showGuide: _guide,
                  showGrid: _grid,
                  mirror: _mirror,
                  stamp: _layer.undo.length * 1000003 + _layer.redo.length + _rgb,
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
              children: [
                if (store.api == null)
                  const Padding(
                    padding: EdgeInsets.only(bottom: 8),
                    child: Text(
                      'Демо-режим: вещь появится только на этом устройстве. '
                      'Войдите на сервер под админом, чтобы продавать её всем.',
                      style: TextStyle(fontSize: 12),
                    ),
                  ),
                Wrap(
                  spacing: 6,
                  children: [
                    for (final t in _Tool.values)
                      ChoiceChip(
                        avatar: Icon(_toolIcon(t), size: 18),
                        label: Text(_toolName(t)),
                        selected: _tool == t,
                        onSelected: (_) => setState(() => _tool = t),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Wrap(
                  spacing: 6,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    for (final b in const [1, 2, 3])
                      ChoiceChip(
                        label: Text('$b px'),
                        selected: _brush == b,
                        onSelected: (_) => setState(() => _brush = b),
                      ),
                    FilterChip(
                      label: const Text('Симметрия'),
                      selected: _mirror,
                      onSelected: (v) => setState(() => _mirror = v),
                    ),
                    FilterChip(
                      label: const Text('Сетка'),
                      selected: _grid,
                      onSelected: (v) => setState(() => _grid = v),
                    ),
                    FilterChip(
                      label: const Text('Силуэт тела'),
                      selected: _guide,
                      onSelected: (v) => setState(() => _guide = v),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: Color(_rgb),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.black38),
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Expanded(child: Text('Цвет рисования')),
                  ],
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 4,
                  runSpacing: 4,
                  children: [
                    for (final v in _palette)
                      GestureDetector(
                        onTap: () => setState(() {
                          _rgb = v;
                          if (_tool == _Tool.eraser || _tool == _Tool.pick) _tool = _Tool.pen;
                        }),
                        child: Container(
                          width: 28,
                          height: 28,
                          decoration: BoxDecoration(
                            color: Color(v),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                              width: _rgb == v ? 3 : 1,
                              color: _rgb == v ? Theme.of(context).colorScheme.primary : Colors.black26,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                ExpansionTile(
                  tilePadding: EdgeInsets.zero,
                  title: const Text('Свой цвет'),
                  children: [
                    _channel('R', (_rgb >> 16) & 255, (v) => _rgb = (_rgb & 0xFF00FFFF) | (v << 16)),
                    _channel('G', (_rgb >> 8) & 255, (v) => _rgb = (_rgb & 0xFFFF00FF) | (v << 8)),
                    _channel('B', _rgb & 255, (v) => _rgb = (_rgb & 0xFFFFFF00) | v),
                  ],
                ),
                const Divider(),
                if (_editingId != null)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.edit_note),
                    title: Text('Правка вещи $_editingId'),
                    trailing: TextButton(onPressed: _newItem, child: const Text('Новая вещь')),
                  ),
                TextField(
                  controller: _name,
                  maxLength: 30,
                  decoration: const InputDecoration(labelText: 'Название вещи', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _price,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Цена', border: OutlineInputBorder()),
                      ),
                    ),
                    const SizedBox(width: 12),
                    FilterChip(
                      label: Text(_gems ? '💎 кристаллы' : '🪙 монеты'),
                      selected: _gems,
                      onSelected: (v) => setState(() => _gems = v),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: _busy ? null : _publish,
                  icon: _busy
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.storefront),
                  label: Text(_editingId != null ? 'Сохранить изменения' : 'Опубликовать в магазин'),
                ),
              ],
            ),
          ),
        ],
      );
    });
  }

  Widget _channel(String label, int value, void Function(int) set) {
    return Row(
      children: [
        SizedBox(width: 20, child: Text(label)),
        Expanded(
          child: Slider(
            value: value.toDouble(),
            max: 255,
            onChanged: (v) => setState(() => set(v.round())),
          ),
        ),
        SizedBox(width: 30, child: Text('$value')),
      ],
    );
  }

  IconData _toolIcon(_Tool t) => switch (t) {
        _Tool.pen => Icons.brush,
        _Tool.eraser => Icons.cleaning_services,
        _Tool.fill => Icons.format_color_fill,
        _Tool.pick => Icons.colorize,
      };

  String _toolName(_Tool t) => switch (t) {
        _Tool.pen => 'Кисть',
        _Tool.eraser => 'Ластик',
        _Tool.fill => 'Заливка',
        _Tool.pick => 'Пипетка',
      };
}

// ---------- Холст ----------

class _PixelPainter extends CustomPainter {
  final Uint32List px;
  final ClothSpec spec;
  final double cell;
  final User guideUser;
  final bool showGuide;
  final bool showGrid;
  final bool mirror;
  final int stamp;

  _PixelPainter({
    required this.px,
    required this.spec,
    required this.cell,
    required this.guideUser,
    required this.showGuide,
    required this.showGrid,
    required this.mirror,
    required this.stamp,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final full = Offset.zero & size;
    canvas.save();
    canvas.clipRect(full);

    // шахматка для прозрачности
    canvas.drawRect(full, Paint()..color = const Color(0xFFF4F4F4));
    final dark = Paint()..color = const Color(0xFFDCDCDC);
    final block = cell * 2;
    for (var y = 0; y * block < size.height; y++) {
      for (var x = 0; x * block < size.width; x++) {
        if ((x + y).isOdd) canvas.drawRect(Rect.fromLTWH(x * block, y * block, block, block), dark);
      }
    }

    // силуэт тела под рисунком
    if (showGuide) {
      final s = cell * 2; // пикселей экрана на одну единицу аватара
      canvas.saveLayer(full, Paint()..color = const Color.fromARGB(150, 255, 255, 255));
      paintAvatar(canvas, guideUser, Offset(-spec.area.left * s, -spec.area.top * s), s, legacy: true);
      canvas.restore();
    }

    // пиксели
    final paint = Paint()..isAntiAlias = false;
    for (var y = 0; y < spec.h; y++) {
      for (var x = 0; x < spec.w; x++) {
        final v = px[y * spec.w + x];
        if ((v >>> 24) == 0) continue;
        paint.color = Color(v);
        canvas.drawRect(
          Rect.fromLTRB(
            (x * cell).floorToDouble(),
            (y * cell).floorToDouble(),
            ((x + 1) * cell).ceilToDouble(),
            ((y + 1) * cell).ceilToDouble(),
          ),
          paint,
        );
      }
    }

    // сетка
    if (showGrid && cell >= 3) {
      final step = cell >= 5 ? 1 : 4;
      final g = Paint()
        ..strokeWidth = 1
        ..color = const Color(0x22000000);
      for (var x = 0; x <= spec.w; x += step) {
        canvas.drawLine(Offset(x * cell, 0), Offset(x * cell, size.height), g);
      }
      for (var y = 0; y <= spec.h; y += step) {
        canvas.drawLine(Offset(0, y * cell), Offset(size.width, y * cell), g);
      }
    }

    // ось симметрии
    if (mirror) {
      canvas.drawLine(
        Offset(size.width / 2, 0),
        Offset(size.width / 2, size.height),
        Paint()
          ..strokeWidth = 1.5
          ..color = const Color(0x882196F3),
      );
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(_PixelPainter old) => true;
}

// ---------- Мои вещи ----------

class _MyClothes extends StatefulWidget {
  final void Function(Map<String, dynamic>) onEdit;
  final bool active;
  const _MyClothes({required this.onEdit, required this.active});

  @override
  State<_MyClothes> createState() => _MyClothesState();
}

class _MyClothesState extends State<_MyClothes> {
  Future<List<Map<String, dynamic>>>? _future;

  @override
  void didUpdateWidget(_MyClothes old) {
    super.didUpdateWidget(old);
    if (widget.active && !old.active) _reload();
  }

  void _reload() {
    final store = StoreScope.of(context);
    setState(() => _future = store.adminClothes());
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    _future ??= store.adminClothes();
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Не удалось загрузить список'),
                TextButton(onPressed: _reload, child: const Text('Повторить')),
              ],
            ),
          );
        }
        final items = snap.data ?? const [];
        if (items.isEmpty) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text('Вы ещё не создали ни одной вещи. Нарисуйте её на вкладке «Рисовать».',
                  textAlign: TextAlign.center),
            ),
          );
        }
        return RefreshIndicator(
          onRefresh: () async => _reload(),
          child: ListView(
            children: [
              for (final m in items)
                ListTile(
                  leading: ClothThumb(id: m['id'] as String, slot: m['slot'] as String, size: 48),
                  title: Text(m['name'] as String),
                  subtitle: Text(
                    '${clothSpecs[m['slot']]?.title ?? m['slot']} · '
                    '${m['price']} ${m['gems'] == true ? '💎' : '🪙'}'
                    '${m['active'] == false ? ' · снята с продажи' : ''}',
                  ),
                  onTap: () => widget.onEdit(m),
                  trailing: store.api == null
                      ? const Icon(Icons.edit)
                      : Switch(
                          value: m['active'] != false,
                          onChanged: (v) async {
                            final err = await store.updateCloth(m['id'] as String, active: v);
                            if (err != null) store.toast(err);
                            _reload();
                          },
                        ),
                ),
            ],
          ),
        );
      },
    );
  }
}
