import 'dart:async';

import 'package:flutter/material.dart';

import '../api.dart';
import '../store.dart';
import '../ui.dart';

/// Список переписок. Работает только при входе на сервер (не в демо-режиме).
class MessagesScreen extends StatefulWidget {
  const MessagesScreen({super.key});

  @override
  State<MessagesScreen> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  List<Map<String, dynamic>> _threads = [];
  bool _loading = true;
  String? _error;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _load();
      _timer = Timer.periodic(const Duration(seconds: 8), (_) => _load());
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final api = StoreScope.of(context).api;
    if (api == null) {
      setState(() {
        _loading = false;
        _error = 'Личные сообщения доступны при входе на сервер.';
      });
      return;
    }
    try {
      final r = await api.dmThreads();
      if (!mounted) return;
      setState(() {
        _threads = (r['threads'] as List).cast<Map<String, dynamic>>();
        _loading = false;
        _error = null;
      });
    } on ApiException catch (e) {
      if (mounted) setState(() { _loading = false; _error = e.message; });
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget body;
    if (_loading) {
      body = const Center(child: CircularProgressIndicator());
    } else if (_error != null) {
      body = EmptyState(icon: Icons.cloud_off_rounded, title: 'Нет связи', text: _error!);
    } else if (_threads.isEmpty) {
      body = const EmptyState(
        icon: Icons.chat_bubble_outline_rounded,
        title: 'Сообщений пока нет',
        text: 'Откройте карточку игрока в комнате, чтобы написать ему.',
      );
    } else {
      body = ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        itemCount: _threads.length,
        itemBuilder: (context, i) {
          final t = _threads[i];
          final user = t['user'] as Map<String, dynamic>;
          final name = user['name'] as String;
          final unread = t['unread'] as int;
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: GlassCard(
              onTap: () async {
                await Navigator.of(context).push(MaterialPageRoute<void>(
                  builder: (_) => ChatScreen(peerId: user['id'] as int, peerName: name),
                ));
                _load();
              },
              child: Row(children: [
                CircleAvatar(backgroundColor: Ui.violet, child: Text(name.characters.first.toUpperCase())),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(name, style: const TextStyle(fontWeight: FontWeight.w700)),
                    Text((t['last'] as Map<String, dynamic>)['text'] as String,
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                  ]),
                ),
                if (unread > 0) Badge(label: Text('$unread')),
              ]),
            ),
          );
        },
      );
    }
    return Scaffold(appBar: AppBar(title: const Text('Сообщения')), body: body);
  }
}

/// Переписка с одним игроком. Новые сообщения подтягиваются раз в 3 секунды.
class ChatScreen extends StatefulWidget {
  final int peerId;
  final String peerName;
  const ChatScreen({super.key, required this.peerId, required this.peerName});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _msgs = <Map<String, dynamic>>[];
  final _input = TextEditingController();
  final _scroll = ScrollController();
  Timer? _timer;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _poll();
      _timer = Timer.periodic(const Duration(seconds: 3), (_) => _poll());
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  int get _lastId => _msgs.isEmpty ? 0 : _msgs.last['id'] as int;

  Future<void> _poll() async {
    final api = StoreScope.of(context).api;
    if (api == null) return;
    try {
      final r = await api.dmThread(widget.peerId, _lastId);
      final fresh = (r['messages'] as List).cast<Map<String, dynamic>>();
      if (fresh.isNotEmpty && mounted) {
        setState(() => _msgs.addAll(fresh.where((m) => (m['id'] as int) > _lastId)));
        _toBottom();
      }
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    }
  }

  void _toBottom() => WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
      });

  Future<void> _send() async {
    final text = _input.text.trim();
    final api = StoreScope.of(context).api;
    if (text.isEmpty || api == null) return;
    _input.clear();
    try {
      final r = await api.dmSend(widget.peerId, text);
      setState(() {
        _error = null;
        _msgs.add(r['message'] as Map<String, dynamic>);
      });
      _toBottom();
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.peerName)),
      body: Column(children: [
        Expanded(
          child: ListView.builder(
            controller: _scroll,
            padding: const EdgeInsets.all(16),
            itemCount: _msgs.length,
            itemBuilder: (context, i) {
              final m = _msgs[i];
              final mine = m['to'] == widget.peerId;
              return Align(
                alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                  constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .75),
                  decoration: BoxDecoration(
                    color: mine ? Ui.violet : Ui.surfaceHi,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(m['text'] as String),
                ),
              );
            },
          ),
        ),
        if (_error != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(_error!, style: const TextStyle(color: Colors.redAccent)),
          ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 6, 12, 8),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _input,
                  maxLength: 120,
                  onSubmitted: (_) => _send(),
                  decoration: const InputDecoration(hintText: 'Сообщение', counterText: ''),
                ),
              ),
              IconButton(onPressed: _send, icon: const Icon(Icons.send_rounded)),
            ]),
          ),
        ),
      ]),
    );
  }
}
