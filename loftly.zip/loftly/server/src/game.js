import { randomBytes, randomInt, scryptSync, timingSafeEqual, createHash } from 'node:crypto';
import { tx } from './db.js';
import {
  ITEMS, FURN, ROOM_GRID, THEME_COUNT, FREE_ITEMS, DEFAULT_EQUIP, EQUIP_SLOTS,
  RARITIES, RARITY_NAMES, POOLS, DUPLICATE_REFUND, BOXES, CLOTH_SPEC,
} from './catalog.js';

export class ApiError extends Error {
  constructor(status, code, message) {
    super(message || code);
    this.status = status;
    this.code = code;
  }
}
const bad = (code, msg) => new ApiError(400, code, msg);

export const ECONOMY = { dailyBonus: 100, roomCost: 200, startCoins: 500, startGems: 5 };

const sha = (s) => createHash('sha256').update(s).digest('hex');

// ---------- Пароли и сессии ----------

function hashPassword(pw) {
  const salt = randomBytes(16);
  const h = scryptSync(pw, salt, 64);
  return `scrypt$${salt.toString('hex')}$${h.toString('hex')}`;
}
function checkPassword(pw, stored) {
  const [alg, saltHex, hashHex] = stored.split('$');
  if (alg !== 'scrypt') return false;
  const h = scryptSync(pw, Buffer.from(saltHex, 'hex'), 64);
  const want = Buffer.from(hashHex, 'hex');
  return h.length === want.length && timingSafeEqual(h, want);
}

export function createGame(db, opts = {}) {
  const adminUsername = (opts.adminUsername || '').toLowerCase();
  const badWords = new Set((opts.badWords || ['дурак', 'идиот']).map((w) => w.toLowerCase()));
  const now = opts.now || (() => new Date());

  const q = {
    userById: db.prepare('SELECT * FROM users WHERE id = ?'),
    userByName: db.prepare('SELECT * FROM users WHERE username = ?'),
    owned: db.prepare('SELECT item_id, count FROM inventory WHERE user_id = ?'),
    invGet: db.prepare('SELECT count FROM inventory WHERE user_id = ? AND item_id = ?'),
    invAdd: db.prepare(`INSERT INTO inventory (user_id, item_id, count) VALUES (?, ?, ?)
      ON CONFLICT(user_id, item_id) DO UPDATE SET count = count + excluded.count`),
    cloth: db.prepare('SELECT num, slot, name, price, gems, active FROM custom_items WHERE num = ?'),
    clothPng: db.prepare('SELECT num, slot, png FROM custom_items WHERE num = ?'),
  };

  // ---------- Предметы: встроенные и созданные в студии одежды ----------

  const clothNum = (id) => (typeof id === 'string' && /^c\d{1,9}$/.test(id) ? Number(id.slice(1)) : null);

  /** Предмет по id: встроенный из каталога или пользовательская одежда из БД. */
  function itemOf(id) {
    if (typeof id !== 'string') return null;
    if (Object.hasOwn(ITEMS, id)) return ITEMS[id];
    const n = clothNum(id);
    const r = n === null ? null : q.cloth.get(n);
    if (!r) return null;
    return {
      id: `c${r.num}`, slot: r.slot, name: r.name, price: r.price, gems: !!r.gems,
      free: false, custom: true, active: !!r.active,
    };
  }

  const today = () => now().toISOString().slice(0, 10);
  const yesterday = () => new Date(now().getTime() - 86400000).toISOString().slice(0, 10);

  function profile(userId) {
    const u = q.userById.get(userId);
    if (!u) throw new ApiError(404, 'no_user');
    const inv = q.owned.all(userId);
    const owned = [];
    const furniture = {};
    for (const r of inv) {
      if (r.item_id.startsWith('furn:')) furniture[r.item_id.slice(5)] = r.count;
      else owned.push(r.item_id);
    }
    return {
      id: u.id, username: u.username, name: u.name, role: u.role,
      coins: u.coins, gems: u.gems, skin: u.skin,
      equip: JSON.parse(u.equip), owned, furniture,
      streak: u.streak, dailyReady: u.last_daily !== today(),
      muted: !!u.muted, banned: !!u.banned,
    };
  }
  const publicUser = (u) => ({ id: u.id, name: u.name, skin: u.skin, equip: JSON.parse(u.equip), role: u.role });

  // ---------- Регистрация и вход ----------

  function validateUsername(s) {
    if (typeof s !== 'string' || !/^[A-Za-z0-9_]{3,20}$/.test(s)) {
      throw bad('bad_username', 'Логин: 3–20 символов, латиница, цифры и _');
    }
  }
  function validatePassword(s) {
    if (typeof s !== 'string' || s.length < 6 || s.length > 100) {
      throw bad('bad_password', 'Пароль: от 6 символов');
    }
  }
  function cleanName(s, fallback) {
    const n = (typeof s === 'string' ? s : '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, 20);
    return n || fallback;
  }

  function newSession(userId) {
    const token = randomBytes(32).toString('hex');
    db.prepare('INSERT INTO sessions (token_hash, user_id) VALUES (?, ?)').run(sha(token), userId);
    return token;
  }

  function register({ username, password, name }) {
    validateUsername(username);
    validatePassword(password);
    if (q.userByName.get(username)) throw new ApiError(409, 'username_taken', 'Логин занят');
    const role = username.toLowerCase() === adminUsername ? 'admin' : 'player';
    const id = tx(db, () => {
      const r = db.prepare(`INSERT INTO users (username, pass_hash, name, role, coins, gems, equip)
        VALUES (?, ?, ?, ?, ?, ?, ?)`).run(username, hashPassword(password), cleanName(name, username), role,
        ECONOMY.startCoins, ECONOMY.startGems, JSON.stringify(DEFAULT_EQUIP));
      const uid = Number(r.lastInsertRowid);
      for (const it of FREE_ITEMS) q.invAdd.run(uid, it, 1);
      q.invAdd.run(uid, 'furn:sofa', 1);
      q.invAdd.run(uid, 'furn:lamp', 1);
      return uid;
    });
    return { token: newSession(id), profile: profile(id) };
  }

  function login({ username, password }) {
    const u = typeof username === 'string' ? q.userByName.get(username) : null;
    // Одинаковая работа и для несуществующего пользователя, чтобы не выдавать наличие логина.
    const ok = checkPassword(String(password ?? ''), u ? u.pass_hash : hashPassword('x'));
    if (!u || !ok) throw new ApiError(401, 'bad_credentials', 'Неверный логин или пароль');
    if (u.banned) throw new ApiError(403, 'banned', 'Аккаунт заблокирован');
    return { token: newSession(u.id), profile: profile(u.id) };
  }

  function authenticate(token) {
    if (typeof token !== 'string' || token.length < 20) return null;
    const row = db.prepare('SELECT user_id FROM sessions WHERE token_hash = ?').get(sha(token));
    if (!row) return null;
    const u = q.userById.get(row.user_id);
    if (!u || u.banned) return null;
    return u;
  }

  function logout(token) {
    db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha(token));
  }

  function updateName(userId, name) {
    const n = cleanName(name, '');
    if (!n) throw bad('bad_name', 'Пустое имя');
    db.prepare('UPDATE users SET name = ? WHERE id = ?').run(n, userId);
    return profile(userId);
  }

  // ---------- Бонус, магазин, одежда ----------

  function claimDaily(userId) {
    return tx(db, () => {
      const u = q.userById.get(userId);
      if (u.last_daily === today()) throw bad('already_claimed', 'Бонус уже получен');
      const streak = u.last_daily === yesterday() ? u.streak + 1 : 1;
      const coins = ECONOMY.dailyBonus + Math.min(streak - 1, 5) * 20;
      const gems = streak % 7 === 0 ? 1 : 0;
      db.prepare('UPDATE users SET coins = coins + ?, gems = gems + ?, streak = ?, last_daily = ? WHERE id = ?')
        .run(coins, gems, streak, today(), userId);
      return { gained: { coins, gems }, profile: profile(userId) };
    });
  }

  function buy(userId, itemId) {
    const it = itemOf(itemId);
    if (!it) throw bad('no_item', 'Нет такого предмета');
    if (it.custom && !it.active) throw bad('not_for_sale', 'Снято с продажи');
    return tx(db, () => {
      const u = q.userById.get(userId);
      const has = q.invGet.get(userId, itemId);
      if (it.slot !== 'furn' && has) throw bad('already_owned', 'Уже куплено');
      const bal = it.gems ? u.gems : u.coins;
      if (bal < it.price) throw bad(it.gems ? 'no_gems' : 'no_coins', it.gems ? 'Не хватает кристаллов' : 'Не хватает монет');
      db.prepare(`UPDATE users SET ${it.gems ? 'gems' : 'coins'} = ${it.gems ? 'gems' : 'coins'} - ? WHERE id = ?`).run(it.price, userId);
      q.invAdd.run(userId, itemId, 1);
      return profile(userId);
    });
  }

  function equip(userId, slot, itemId) {
    if (!EQUIP_SLOTS.includes(slot)) throw bad('bad_slot');
    return tx(db, () => {
      const u = q.userById.get(userId);
      const eq = JSON.parse(u.equip);
      if (itemId === null) {
        if (slot !== 'hat' && slot !== 'face') throw bad('cannot_remove', 'Этот слот нельзя оставить пустым');
        eq[slot] = null;
      } else {
        const it = itemOf(itemId);
        if (!it || it.slot !== slot) throw bad('bad_item');
        if (!q.invGet.get(userId, itemId)) throw bad('not_owned', 'Предмет не куплен');
        eq[slot] = itemId;
      }
      db.prepare('UPDATE users SET equip = ? WHERE id = ?').run(JSON.stringify(eq), userId);
      return profile(userId);
    });
  }

  // ---------- Лотерея ----------

  const rank = (r) => RARITIES.indexOf(r);

  function rollRarity(box, pity) {
    // pity: { rare, epic, legendary } — сколько круток прошло без выпадения этого уровня или выше.
    let forcedMin = 0;
    for (const rule of box.pity) {
      const counter = rule.atLeast === 'rare' ? pity.rare : rule.atLeast === 'epic' ? pity.epic : pity.legendary;
      if (counter >= rule.every - 1) forcedMin = Math.max(forcedMin, rank(rule.atLeast));
    }
    // Целые веса (шанс * 1000) для честного randomInt.
    const weights = RARITIES.map((r, i) => (i < forcedMin ? 0 : Math.round(box.odds[r] * 1000)));
    const total = weights.reduce((a, b) => a + b, 0);
    let x = randomInt(total);
    for (let i = 0; i < weights.length; i++) {
      if (x < weights[i]) return RARITIES[i];
      x -= weights[i];
    }
    return RARITIES[RARITIES.length - 1];
  }

  function lotteryInfo(userId) {
    const boxes = {};
    for (const [key, b] of Object.entries(BOXES)) {
      const p = db.prepare('SELECT * FROM pity WHERE user_id = ? AND box = ?').get(userId, key);
      boxes[key] = {
        key, name: b.name, cost: b.cost, odds: b.odds,
        pity: b.pity.map((r) => ({ atLeast: r.atLeast, every: r.every })),
        progress: { rare: p?.since_rare ?? 0, epic: p?.since_epic ?? 0, legendary: p?.since_legendary ?? 0 },
      };
    }
    const pools = {};
    for (const r of RARITIES) {
      pools[r] = { name: RARITY_NAMES[r], items: POOLS[r].map((id) => ({ id, name: ITEMS[id].name })) };
    }
    return { boxes, pools, duplicateRefund: DUPLICATE_REFUND };
  }

  function roll(userId, boxKey, count) {
    const box = BOXES[boxKey];
    if (!box) throw bad('no_box', 'Нет такой капсулы');
    if (count !== 1 && count !== 10) throw bad('bad_count', 'Можно крутить 1 или 10 раз');
    return tx(db, () => {
      const u = q.userById.get(userId);
      const needCoins = box.cost.coins * count;
      const needGems = box.cost.gems * count;
      if (u.coins < needCoins) throw bad('no_coins', 'Не хватает монет');
      if (u.gems < needGems) throw bad('no_gems', 'Не хватает кристаллов');
      db.prepare('UPDATE users SET coins = coins - ?, gems = gems - ? WHERE id = ?').run(needCoins, needGems, userId);

      const row = db.prepare('SELECT * FROM pity WHERE user_id = ? AND box = ?').get(userId, boxKey);
      const pity = { rare: row?.since_rare ?? 0, epic: row?.since_epic ?? 0, legendary: row?.since_legendary ?? 0 };
      const results = [];
      let refundCoins = 0;
      let refundGems = 0;

      for (let i = 0; i < count; i++) {
        const rarity = rollRarity(box, pity);
        const pool = POOLS[rarity];
        const itemId = pool[randomInt(pool.length)];
        const it = ITEMS[itemId];
        const isFurn = it.slot === 'furn';
        const duplicate = !isFurn && !!q.invGet.get(userId, itemId);
        let refund = { coins: 0, gems: 0 };
        if (duplicate) {
          refund = DUPLICATE_REFUND[rarity];
          refundCoins += refund.coins;
          refundGems += refund.gems;
        } else {
          q.invAdd.run(userId, itemId, 1);
        }
        const rk = rank(rarity);
        pity.rare = rk >= 1 ? 0 : pity.rare + 1;
        pity.epic = rk >= 2 ? 0 : pity.epic + 1;
        pity.legendary = rk >= 3 ? 0 : pity.legendary + 1;
        db.prepare('INSERT INTO lottery_log (user_id, box, item_id, rarity, duplicate) VALUES (?, ?, ?, ?, ?)')
          .run(userId, boxKey, itemId, rarity, duplicate ? 1 : 0);
        results.push({ itemId, name: it.name, slot: it.slot, rarity, rarityName: RARITY_NAMES[rarity], duplicate, refund });
      }
      if (refundCoins || refundGems) {
        db.prepare('UPDATE users SET coins = coins + ?, gems = gems + ? WHERE id = ?').run(refundCoins, refundGems, userId);
      }
      db.prepare(`INSERT INTO pity (user_id, box, since_rare, since_epic, since_legendary) VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(user_id, box) DO UPDATE SET since_rare = excluded.since_rare,
        since_epic = excluded.since_epic, since_legendary = excluded.since_legendary`)
        .run(userId, boxKey, pity.rare, pity.epic, pity.legendary);
      return { results, profile: profile(userId) };
    });
  }

  // ---------- Комнаты ----------

  const roomRow = (r, userId, online = 0) => ({
    id: r.id, name: r.name, ownerId: r.owner_id, ownerName: r.owner_name, theme: r.theme,
    isPublic: !!r.is_public, closed: !!r.closed, likes: r.likes,
    liked: userId ? !!db.prepare('SELECT 1 FROM room_likes WHERE room_id = ? AND user_id = ?').get(r.id, userId) : false,
    furniture: JSON.parse(r.furniture), online,
  });
  const ROOM_SELECT = `SELECT r.*, u.name AS owner_name,
    (SELECT COUNT(*) FROM room_likes l WHERE l.room_id = r.id) AS likes
    FROM rooms r JOIN users u ON u.id = r.owner_id`;

  function getRoom(roomId) {
    const r = db.prepare(`${ROOM_SELECT} WHERE r.id = ?`).get(roomId);
    if (!r) throw new ApiError(404, 'no_room', 'Комната не найдена');
    return r;
  }

  function listRooms(userId, onlineOf = () => 0) {
    const rows = db.prepare(`${ROOM_SELECT} WHERE r.is_public = 1 OR r.owner_id = ? ORDER BY likes DESC, r.id LIMIT 100`).all(userId);
    return rows.map((r) => roomRow(r, userId, onlineOf(r.id)));
  }

  function ownsTheme(userId, theme) {
    return theme === 0 || !!q.invGet.get(userId, `theme${theme}`);
  }

  function createRoom(userId, { name, theme = 0, isPublic = true }) {
    const nm = cleanName(name, '');
    if (!nm) throw bad('bad_name', 'Введите название комнаты');
    if (!Number.isInteger(theme) || theme < 0 || theme >= THEME_COUNT) throw bad('bad_theme');
    return tx(db, () => {
      if (!ownsTheme(userId, theme)) throw bad('theme_locked', 'Тема не куплена');
      const count = db.prepare('SELECT COUNT(*) AS c FROM rooms WHERE owner_id = ?').get(userId).c;
      if (count >= 10) throw bad('too_many_rooms', 'Не больше 10 комнат');
      const cost = count === 0 ? 0 : ECONOMY.roomCost;
      const u = q.userById.get(userId);
      if (u.coins < cost) throw bad('no_coins', 'Не хватает монет');
      if (cost) db.prepare('UPDATE users SET coins = coins - ? WHERE id = ?').run(cost, userId);
      const r = db.prepare('INSERT INTO rooms (name, owner_id, theme, is_public) VALUES (?, ?, ?, ?)')
        .run(nm, userId, theme, isPublic ? 1 : 0);
      return { room: roomRow(getRoom(Number(r.lastInsertRowid)), userId), profile: profile(userId) };
    });
  }

  function requireRoomOwner(userId, roomId) {
    const r = getRoom(roomId);
    const u = q.userById.get(userId);
    if (r.owner_id !== userId && u.role !== 'admin') throw new ApiError(403, 'forbidden', 'Это не ваша комната');
    return r;
  }

  function setRoomTheme(userId, roomId, theme) {
    requireRoomOwner(userId, roomId);
    if (!Number.isInteger(theme) || theme < 0 || theme >= THEME_COUNT) throw bad('bad_theme');
    if (!ownsTheme(userId, theme)) throw bad('theme_locked', 'Тема не куплена');
    db.prepare('UPDATE rooms SET theme = ? WHERE id = ?').run(theme, roomId);
    return roomRow(getRoom(roomId), userId);
  }

  function deleteRoom(userId, roomId) {
    requireRoomOwner(userId, roomId);
    db.prepare('DELETE FROM rooms WHERE id = ?').run(roomId);
    return { ok: true };
  }

  function toggleLike(userId, roomId) {
    getRoom(roomId);
    const has = db.prepare('SELECT 1 FROM room_likes WHERE room_id = ? AND user_id = ?').get(roomId, userId);
    if (has) db.prepare('DELETE FROM room_likes WHERE room_id = ? AND user_id = ?').run(roomId, userId);
    else db.prepare('INSERT INTO room_likes (room_id, user_id) VALUES (?, ?)').run(roomId, userId);
    return roomRow(getRoom(roomId), userId);
  }

  /** Проверка расстановки: границы, пересечения, и что мебели не больше, чем куплено. */
  function validateLayout(userId, roomId, items) {
    if (!Array.isArray(items) || items.length > 60) throw bad('bad_layout', 'Слишком много предметов');
    const placed = [];
    for (const it of items) {
      const spec = FURN[it?.kind];
      if (!spec || !Number.isInteger(it.x) || !Number.isInteger(it.y)) throw bad('bad_layout');
      if (it.x < 0 || it.y < 0 || it.x + spec.w > ROOM_GRID || it.y + spec.d > ROOM_GRID) throw bad('out_of_room', 'Предмет вне комнаты');
      for (const o of placed) {
        const os = FURN[o.kind];
        if (os.walkable !== spec.walkable) continue;
        if (it.x < o.x + os.w && it.x + spec.w > o.x && it.y < o.y + os.d && it.y + spec.d > o.y) {
          throw bad('overlap', 'Предметы пересекаются');
        }
      }
      placed.push({ kind: it.kind, x: it.x, y: it.y });
    }
    const need = {};
    for (const p of placed) need[p.kind] = (need[p.kind] || 0) + 1;
    const others = db.prepare('SELECT furniture FROM rooms WHERE owner_id = ? AND id != ?').all(userId, roomId);
    for (const o of others) for (const f of JSON.parse(o.furniture)) need[f.kind] = (need[f.kind] || 0) + 1;
    for (const [kind, n] of Object.entries(need)) {
      const have = q.invGet.get(userId, `furn:${kind}`)?.count ?? 0;
      if (n > have) throw bad('not_enough_furniture', `Не хватает: ${FURN[kind].name}`);
    }
    return placed;
  }

  function saveLayout(userId, roomId, items) {
    requireRoomOwner(userId, roomId);
    const owner = getRoom(roomId).owner_id;
    const placed = validateLayout(owner, roomId, items);
    db.prepare('UPDATE rooms SET furniture = ? WHERE id = ?').run(JSON.stringify(placed), roomId);
    return roomRow(getRoom(roomId), userId);
  }

  // ---------- Чат ----------

  function filterChat(text) {
    let t = String(text ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, 120);
    if (!t) return '';
    for (const w of badWords) t = t.replace(new RegExp(w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), '***');
    return t;
  }

  // ---------- Модерация ----------

  const staffOnly = (userId, roles) => {
    const u = q.userById.get(userId);
    if (!roles.includes(u.role)) throw new ApiError(403, 'forbidden', 'Недостаточно прав');
    return u;
  };
  const adminLog = (adminId, text) => db.prepare('INSERT INTO admin_log (admin_id, text) VALUES (?, ?)').run(adminId, text);

  function adminUsers(adminId) {
    staffOnly(adminId, ['admin']);
    return db.prepare('SELECT id, username, name, role, coins, gems, muted, banned FROM users ORDER BY id LIMIT 200').all();
  }
  function adminSet(adminId, targetId, patch) {
    const me = staffOnly(adminId, ['admin', 'moderator']);
    const t = q.userById.get(targetId);
    if (!t) throw new ApiError(404, 'no_user');
    if (t.role === 'admin' && t.id !== adminId) throw new ApiError(403, 'forbidden', 'Нельзя трогать админа');
    const admin = me.role === 'admin';
    if ('muted' in patch) {
      db.prepare('UPDATE users SET muted = ? WHERE id = ?').run(patch.muted ? 1 : 0, targetId);
      adminLog(adminId, `${patch.muted ? 'mute' : 'unmute'} ${t.username}`);
    }
    if ('banned' in patch) {
      if (!admin) throw new ApiError(403, 'forbidden', 'Баны — только админ');
      db.prepare('UPDATE users SET banned = ? WHERE id = ?').run(patch.banned ? 1 : 0, targetId);
      if (patch.banned) db.prepare('DELETE FROM sessions WHERE user_id = ?').run(targetId);
      adminLog(adminId, `${patch.banned ? 'ban' : 'unban'} ${t.username}`);
    }
    if ('role' in patch) {
      if (!admin) throw new ApiError(403, 'forbidden', 'Роли — только админ');
      if (!['player', 'moderator', 'admin'].includes(patch.role)) throw bad('bad_role');
      db.prepare('UPDATE users SET role = ? WHERE id = ?').run(patch.role, targetId);
      adminLog(adminId, `role ${t.username} -> ${patch.role}`);
    }
    return { ok: true };
  }
  function adminGrant(adminId, targetId, coins = 0, gems = 0) {
    staffOnly(adminId, ['admin']);
    if (!Number.isInteger(coins) || !Number.isInteger(gems) || Math.abs(coins) > 1e6 || Math.abs(gems) > 1e4) throw bad('bad_amount');
    const t = q.userById.get(targetId);
    if (!t) throw new ApiError(404, 'no_user');
    db.prepare('UPDATE users SET coins = MAX(0, coins + ?), gems = MAX(0, gems + ?) WHERE id = ?').run(coins, gems, targetId);
    adminLog(adminId, `grant ${t.username} ${coins}c ${gems}g`);
    return { ok: true };
  }
  function adminCloseRoom(adminId, roomId, closed) {
    staffOnly(adminId, ['admin']);
    getRoom(roomId);
    db.prepare('UPDATE rooms SET closed = ? WHERE id = ?').run(closed ? 1 : 0, roomId);
    adminLog(adminId, `${closed ? 'close' : 'open'} room ${roomId}`);
    return { ok: true };
  }

  // ---------- Студия одежды ----------

  const MAX_PNG_B64 = 125000;
  const PNG_SIG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

  /** Проверяет, что это PNG нужного для слота размера. Содержимое пикселей рисует сам админ. */
  function validatePng(slot, b64) {
    if (typeof b64 !== 'string' || b64.length < 40 || b64.length > MAX_PNG_B64 || !/^[A-Za-z0-9+/]+={0,2}$/.test(b64)) {
      throw bad('bad_png', 'Некорректная картинка');
    }
    const buf = Buffer.from(b64, 'base64');
    if (buf.length < 33 || !buf.subarray(0, 8).equals(PNG_SIG) || buf.toString('ascii', 12, 16) !== 'IHDR') {
      throw bad('bad_png', 'Нужен файл PNG');
    }
    const spec = CLOTH_SPEC[slot];
    const w = buf.readUInt32BE(16);
    const h = buf.readUInt32BE(20);
    if (!((w === spec.w && h === spec.h) || (w === spec.w * 2 && h === spec.h * 2))) {
      throw bad('bad_size', `Размер для этого слота: ${spec.w}×${spec.h} или ${spec.w * 2}×${spec.h * 2}`);
    }
  }

  const clothMeta = (r) => ({ id: `c${r.num}`, slot: r.slot, name: r.name, price: r.price, gems: !!r.gems, active: !!r.active });

  function cleanClothName(s) {
    const n = (typeof s === 'string' ? s : '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, 30);
    if (!n) throw bad('bad_name', 'Введите название вещи');
    return n;
  }
  function cleanPrice(v) {
    if (!Number.isInteger(v) || v < 0 || v > 100000) throw bad('bad_price', 'Цена: от 0 до 100000');
    return v;
  }

  /** Каталог одежды для магазина: только продаваемые вещи, без самих картинок. */
  function listClothes() {
    return db.prepare('SELECT num, slot, name, price, gems, active FROM custom_items WHERE active = 1 ORDER BY num').all().map(clothMeta);
  }

  /** PNG вещи (нужен и для снятых с продажи — их могут носить игроки). */
  function getCloth(id) {
    const n = clothNum(id);
    const r = n === null ? null : q.clothPng.get(n);
    if (!r) throw new ApiError(404, 'no_item', 'Нет такой вещи');
    return { id: `c${r.num}`, slot: r.slot, png: r.png };
  }

  function adminListClothes(adminId) {
    staffOnly(adminId, ['admin']);
    return db.prepare('SELECT num, slot, name, price, gems, active FROM custom_items ORDER BY num DESC LIMIT 500').all().map(clothMeta);
  }

  function adminCreateCloth(adminId, body) {
    staffOnly(adminId, ['admin']);
    const slot = body?.slot;
    if (typeof slot !== 'string' || !Object.hasOwn(CLOTH_SPEC, slot)) throw bad('bad_slot', 'Неизвестный слот');
    const name = cleanClothName(body.name);
    const price = cleanPrice(body.price ?? 0);
    validatePng(slot, body.png);
    return tx(db, () => {
      if (db.prepare('SELECT COUNT(*) AS c FROM custom_items').get().c >= 1000) throw bad('too_many', 'Слишком много вещей');
      const r = db.prepare('INSERT INTO custom_items (slot, name, price, gems, png, created_by) VALUES (?, ?, ?, ?, ?, ?)')
        .run(slot, name, price, body.gems ? 1 : 0, body.png, adminId);
      const id = `c${Number(r.lastInsertRowid)}`;
      q.invAdd.run(adminId, id, 1); // автор сразу получает вещь, чтобы примерить
      adminLog(adminId, `cloth create ${id} ${slot} "${name}"`);
      return { cloth: clothMeta(q.cloth.get(Number(r.lastInsertRowid))), profile: profile(adminId) };
    });
  }

  function adminUpdateCloth(adminId, id, patch) {
    staffOnly(adminId, ['admin']);
    const n = clothNum(id);
    const row = n === null ? null : q.cloth.get(n);
    if (!row) throw new ApiError(404, 'no_item', 'Нет такой вещи');
    const p = patch || {};
    if ('name' in p) db.prepare('UPDATE custom_items SET name = ? WHERE num = ?').run(cleanClothName(p.name), n);
    if ('price' in p) db.prepare('UPDATE custom_items SET price = ? WHERE num = ?').run(cleanPrice(p.price), n);
    if ('gems' in p) db.prepare('UPDATE custom_items SET gems = ? WHERE num = ?').run(p.gems ? 1 : 0, n);
    if ('active' in p) db.prepare('UPDATE custom_items SET active = ? WHERE num = ?').run(p.active ? 1 : 0, n);
    if ('png' in p) {
      validatePng(row.slot, p.png);
      db.prepare('UPDATE custom_items SET png = ? WHERE num = ?').run(p.png, n);
    }
    adminLog(adminId, `cloth update c${n} ${Object.keys(p).join(',')}`);
    return { cloth: clothMeta(q.cloth.get(n)) };
  }

  return {
    register, login, logout, authenticate, profile, publicUser, updateName,
    claimDaily, buy, equip, lotteryInfo, roll,
    listClothes, getCloth, adminListClothes, adminCreateCloth, adminUpdateCloth,
    listRooms, getRoom, roomRow, createRoom, setRoomTheme, deleteRoom, toggleLike, saveLayout,
    filterChat, adminUsers, adminSet, adminGrant, adminCloseRoom,
    userById: (id) => q.userById.get(id),
  };
}
