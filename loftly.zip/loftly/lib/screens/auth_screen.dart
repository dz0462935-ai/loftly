import 'package:flutter/material.dart';

import '../api.dart';
import '../ui.dart';

class AuthScreen extends StatefulWidget {
  final String initialUrl;
  final void Function(ApiClient api, Map<String, dynamic> profile) onLoggedIn;
  final VoidCallback onDemo;

  const AuthScreen({
    super.key,
    required this.initialUrl,
    required this.onLoggedIn,
    required this.onDemo,
  });

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  late final TextEditingController _url = TextEditingController(text: widget.initialUrl);
  final TextEditingController _user = TextEditingController();
  final TextEditingController _pass = TextEditingController();
  final TextEditingController _name = TextEditingController();
  bool _register = false;
  bool _busy = false;
  bool _showServer = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    // Если адрес сервера ещё не сохранён, показываем поле сразу.
    _showServer = widget.initialUrl.isEmpty;
  }

  @override
  void dispose() {
    _url.dispose();
    _user.dispose();
    _pass.dispose();
    _name.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final url = normalizeServerUrl(_url.text);
    if (url.isEmpty) {
      setState(() {
        _error = 'Укажите адрес сервера';
        _showServer = true;
      });
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final api = ApiClient(url);
      final r = _register
          ? await api.register(_user.text.trim(), _pass.text, _name.text.trim())
          : await api.login(_user.text.trim(), _pass.text);
      final token = r['token'] as String;
      api.token = token;
      await saveSession(url, token);
      if (!mounted) return;
      widget.onLoggedIn(api, r['profile'] as Map<String, dynamic>);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GameBackground(
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Container(
                        width: 92,
                        height: 92,
                        decoration: BoxDecoration(
                          gradient: Ui.brand,
                          borderRadius: BorderRadius.circular(28),
                          boxShadow: [
                            BoxShadow(
                              color: Ui.a(Ui.accent, .5),
                              blurRadius: 28,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        child: const Icon(Icons.home_rounded, size: 52),
                      ),
                    ),
                    const SizedBox(height: 18),
                    const Text(
                      'Loftly',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, letterSpacing: 1),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _register ? 'Создайте аккаунт' : 'Добро пожаловать обратно',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Ui.dim, fontSize: 15),
                    ),
                    const SizedBox(height: 24),
                    GlassCard(
                      padding: const EdgeInsets.all(18),
                      radius: 26,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          TextField(
                            controller: _user,
                            autocorrect: false,
                            decoration: Ui.input(
                              'Логин',
                              prefix: const Icon(Icons.person_outline_rounded),
                            ),
                          ),
                          const SizedBox(height: 12),
                          if (_register) ...[
                            TextField(
                              controller: _name,
                              decoration: Ui.input(
                                'Имя в игре',
                                prefix: const Icon(Icons.badge_outlined),
                              ),
                            ),
                            const SizedBox(height: 12),
                          ],
                          TextField(
                            controller: _pass,
                            obscureText: true,
                            decoration: Ui.input(
                              'Пароль',
                              helper: _register ? 'От 6 символов' : null,
                              prefix: const Icon(Icons.lock_outline_rounded),
                            ),
                            onSubmitted: (_) => _busy ? null : _submit(),
                          ),
                          if (_showServer) ...[
                            const SizedBox(height: 12),
                            TextField(
                              controller: _url,
                              keyboardType: TextInputType.url,
                              autocorrect: false,
                              decoration: Ui.input(
                                'Адрес сервера',
                                hint: 'https://loftly.onrender.com',
                                prefix: const Icon(Icons.dns_outlined),
                              ),
                            ),
                          ],
                          if (_error != null) ...[
                            const SizedBox(height: 12),
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: Ui.a(Colors.redAccent, .18),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: Ui.a(Colors.redAccent, .6)),
                              ),
                              child: Row(
                                children: [
                                  const Icon(Icons.error_outline_rounded, size: 18),
                                  const SizedBox(width: 8),
                                  Expanded(child: Text(_error!, style: const TextStyle(fontSize: 13))),
                                ],
                              ),
                            ),
                          ],
                          const SizedBox(height: 16),
                          _busy
                              ? const SizedBox(
                                  height: 50,
                                  child: Center(child: CircularProgressIndicator()),
                                )
                              : GradientButton(
                                  label: _register ? 'Зарегистрироваться' : 'Войти',
                                  icon: _register ? Icons.rocket_launch_rounded : Icons.login_rounded,
                                  onPressed: _submit,
                                ),
                          const SizedBox(height: 4),
                          TextButton(
                            onPressed: _busy ? null : () => setState(() => _register = !_register),
                            child: Text(
                              _register ? 'Уже есть аккаунт? Войти' : 'Нет аккаунта? Регистрация',
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        TextButton.icon(
                          onPressed: _busy ? null : () => setState(() => _showServer = !_showServer),
                          icon: const Icon(Icons.settings_ethernet_rounded, size: 18),
                          label: const Text('Сервер'),
                        ),
                        TextButton.icon(
                          onPressed: _busy ? null : widget.onDemo,
                          icon: const Icon(Icons.play_circle_outline_rounded, size: 18),
                          label: const Text('Демо без аккаунта'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
