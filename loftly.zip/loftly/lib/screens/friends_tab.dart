import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../widgets/avatar.dart';
import 'room_screen.dart';

class FriendsTab extends StatelessWidget {
  const FriendsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final friends = store.friendList;
    final requests = store.incomingRequests;
    return Scaffold(
      body: ListView(
        padding: const EdgeInsets.only(bottom: 88),
        children: [
          if (requests.isNotEmpty) ...[
            const _Header('Запросы в друзья'),
            for (final id in requests)
              ListTile(
                leading: AvatarBadge(user: store.users[id]!),
                title: Text(store.users[id]!.name),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      tooltip: 'Принять',
                      icon: const Icon(Icons.check_circle, color: Colors.green),
                      onPressed: () => store.acceptRequest(id),
                    ),
                    IconButton(
                      tooltip: 'Отклонить',
                      icon: const Icon(Icons.cancel_outlined),
                      onPressed: () => store.declineRequest(id),
                    ),
                  ],
                ),
              ),
          ],
          _Header('Друзья (${friends.length})'),
          if (friends.isEmpty)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Text('Пока никого. Нажмите «Найти друзей».'),
            ),
          for (final f in friends) _FriendTile(user: f),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showModalBottomSheet<void>(
          context: context,
          showDragHandle: true,
          builder: (_) => const _FindSheet(),
        ),
        icon: const Icon(Icons.person_search),
        label: const Text('Найти друзей'),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final String text;
  const _Header(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
        child: Text(text, style: Theme.of(context).textTheme.titleSmall),
      );
}

class _FriendTile extends StatelessWidget {
  final User user;
  const _FriendTile({required this.user});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final roomId = store.locationOf(user.id);
    final room = roomId == null ? null : store.roomById(roomId);
    return ListTile(
      leading: AvatarBadge(user: user),
      title: Text(user.name),
      subtitle: Text(room == null ? 'Не в сети' : 'В комнате «${room.name}»'),
      trailing: room == null
          ? null
          : FilledButton.tonal(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => RoomScreen(roomId: room.id),
                ),
              ),
              child: const Text('Зайти'),
            ),
      onLongPress: () => showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('Удалить ${user.name} из друзей?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Отмена'),
            ),
            FilledButton(
              onPressed: () {
                store.removeFriend(user.id);
                Navigator.pop(ctx);
              },
              child: const Text('Удалить'),
            ),
          ],
        ),
      ),
    );
  }
}

class _FindSheet extends StatelessWidget {
  const _FindSheet();

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final list = store.discoverable;
    return SafeArea(
      child: list.isEmpty
          ? const Padding(
              padding: EdgeInsets.all(24),
              child: Text('Новых людей пока нет.'),
            )
          : ListView(
              shrinkWrap: true,
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
                  child: Text('Люди рядом',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                ),
                for (final u in list)
                  ListTile(
                    leading: AvatarBadge(user: u),
                    title: Text(u.name),
                    trailing: FilledButton.tonal(
                      onPressed: () => store.sendRequest(u.id),
                      child: const Text('Добавить'),
                    ),
                  ),
              ],
            ),
    );
  }
}
