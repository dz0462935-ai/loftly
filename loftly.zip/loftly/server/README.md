# Loftly server

Node.js 22+, без внешних зависимостей (SQLite встроен в Node).

```bash
cd server
npm test        # проверка: регистрация, лотерея, комнаты, чат
npm start       # слушает порт 8080
```

Переменные окружения: `PORT`, `DB_PATH` (файл SQLite), `ADMIN_USERNAME` (логин, который при регистрации станет админом).

## API (JSON, заголовок `Authorization: Bearer <token>`)

| Метод | Путь | Что делает |
|---|---|---|
| POST | /api/register, /api/login | вход, возвращает `token` и `profile` |
| GET | /api/me | профиль, баланс, инвентарь |
| POST | /api/daily | бонус дня |
| POST | /api/shop/buy `{itemId}` | покупка |
| POST | /api/equip `{slot,itemId}` | надеть |
| GET | /api/lottery | капсулы, шансы, прогресс гарантий, что может выпасть |
| POST | /api/lottery/roll `{box,count}` | крутка ×1 или ×10 |
| GET/POST | /api/rooms | список, создание |
| PUT | /api/rooms/:id/layout | расстановка мебели |
| POST | /api/rooms/:id/like, /theme | лайк, тема |
| GET/POST | /api/rooms/:id/grab | текущий розыгрыш комнаты / запуск (только владелец) `{prize,ticket,minutes}` |
| POST | /api/grabs/:id/join | участие в розыгрыше |
| POST | /api/admin/users/:id/award `{itemId,note}` | награда ивента: выдать вещь игроку (только админ) |
| GET | /api/dm, /api/dm/:id?after= | переписки (с числом непрочитанных), история с игроком |
| POST | /api/dm/:id `{text}` | личное сообщение (фильтр слов, мут, лимит 5 за 10 с) |
| WS | /ws?token=… | `join`, `move`, `chat`, `emote`, `leave` |
| * | /api/admin/… | игроки, мут, бан, роли, выдача валюты, объявления |

Все проверки (баланс, владение предметами, роли, расстановка, чат) выполняются на сервере.
Результат лотереи определяется только на сервере (`crypto.randomInt`), шансы публикуются через `/api/lottery`.

## Система вещей

У каждой вещи есть **редкость** (`common`, `rare`, `epic`, `legendary`) и **способ получения** (`obtain`):
`shop` — продаётся, `lottery` — выпадает только из капсул, `event` — награда ивентов, выдаёт админ.
Вещи со способом `lottery` и `event` купить нельзя (`/api/shop/buy` вернёт `not_for_sale`).
Вещи из студии одежды задают редкость и способ получения при создании (`rarity`, `obtain`) и правятся через `/api/admin/clothes/:id`.
Активные вещи `lottery` автоматически попадают в пул капсул своей редкости; шансы и гарантии остаются прежними.
