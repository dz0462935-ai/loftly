import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../models.dart';
import '../store.dart';
import '../ui.dart';
import '../widgets/avatar.dart';
import '../widgets/iso.dart';
import '../widgets/user_sheet.dart';

class RoomScreen extends StatefulWidget {
  final String roomId;
  const RoomScreen({super.key, required this.roomId});

  @override
  State<RoomScreen> createState() => _RoomScreenState();
}

class _RoomScreenState extends State<RoomScreen> {
  AppStore? _store;
  bool _entered = false;
  final _text = TextEditingController();

  bool _editing = false;
  String? _placeKind;
  Offset? _previewTile;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _store = StoreScope.of(context);
    if (!_entered) {
      final room = _store!.roomById(widget.roomId);
      if (room != null && _store!.canEnter(room)) {
        _entered = true;
        _store!.enterRoom(widget.roomId);
      }
    }
  }

  @override
  void dispose() {
    if (_entered) _store?.leaveRoom();
    _text.dispose();
    super.dispose();
  }

  void _send() {
    _store?.sendMessage(_text.text);
    _text.clear();
  }

  void _onTile(Room room, int tx, int ty) {
    final store = StoreScope.of(context);
    if (!_editing) {
      store.moveMe(tx, ty);
      return;
    }
    if (_placeKind != null) {
      setState(() => _previewTile = Offset(tx.toDouble(), ty.toDouble()));
    } else {
      final f = furnAt(room, tx, ty);
      if (f != null) {
        store.removeFurniture(room, f);
        store.toast('${furnCatalog[f.kind]!.name} убран(а) на склад');
      }
    }
  }

  bool get _placeOk {
    final store = StoreScope.of(context);
    final room = store.roomById(widget.roomId);
    if (room == null || _placeKind == null || _previewTile == null) return false;
    return store.canPlace(room, _placeKind!, _previewTile!.dx.toInt(), _previewTile!.dy.toInt());
  }

  void _place(Room room) {
    final store = StoreScope.of(context);
    final t = _previewTile;
    final k = _placeKind;
    if (t == null || k == null) return;
    if (store.placeFurniture(room, k, t.dx.toInt(), t.dy.toInt())) {
      setState(() {
        _previewTile = null;
        if ((store.furnInv[k] ?? 0) <= 0) _placeKind = null;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final room = store.roomById(widget.roomId);
    if (room == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: Text('Комната удалена')));
    }
    if (!_entered) {
      return Scaffold(
        appBar: AppBar(title: Text(room.name)),
        body: const Center(child: Text('Комната закрыта модератором')),
      );
    }
    final liked = room.likedBy.contains('me');
    final online = store.onlineCount(room.id);
    return Scaffold(
      backgroundColor: Ui.bg0,
      body: GameBackground(
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 6, 10, 4),
                child: Row(
                  children: [
                    RoundIconButton(
                      icon: Icons.arrow_back_rounded,
                      tooltip: 'Выйти из комнаты',
                      onPressed: () => Navigator.of(context).maybePop(),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Container(
                        height: 44,
                        padding: const EdgeInsets.symmetric(horizontal: 14),
                        decoration: BoxDecoration(
                          color: Ui.a(Colors.black, .38),
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(color: Ui.a(Colors.white, .16)),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                room.name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15),
                              ),
                            ),
                            const Icon(Icons.circle, size: 9, color: Ui.green),
                            const SizedBox(width: 4),
                            Text('$online', style: const TextStyle(fontWeight: FontWeight.w800)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    RoundIconButton(
                      icon: liked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                      color: Ui.accent,
                      tooltip: 'Нравится',
                      onPressed: () => store.toggleLike(room.id),
                      badge: room.likes > 0
                          ? Container(
                              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                              decoration: BoxDecoration(
                                color: Ui.accent,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text('${room.likes}',
                                  style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800)),
                            )
                          : null,
                    ),
                    const SizedBox(width: 8),
                    RoundIconButton(
                      icon: Icons.person_add_alt_1_rounded,
                      tooltip: 'Пригласить друга',
                      onPressed: () => showModalBottomSheet<void>(
                        context: context,
                        showDragHandle: true,
                        builder: (_) => _InviteSheet(roomId: room.id),
                      ),
                    ),
                    if (store.canEdit(room)) ...[
                      const SizedBox(width: 8),
                      RoundIconButton(
                        icon: _editing ? Icons.check_rounded : Icons.chair_alt_rounded,
                        color: _editing ? Ui.green : null,
                        tooltip: 'Обустроить комнату',
                        onPressed: () => setState(() {
                          _editing = !_editing;
                          _placeKind = null;
                          _previewTile = null;
                        }),
                      ),
                    ],
                  ],
                ),
              ),
              Expanded(
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: _RoomView(
                        room: room,
                        placeKind: _editing ? _placeKind : null,
                        placeTile: _editing ? _previewTile : null,
                        placeOk: _placeOk,
                        onAvatar: (id) {
                          if (id != 'me') showUserSheet(context, id);
                        },
                        onTile: (x, y) => _onTile(room, x, y),
                      ),
                    ),
                    if (!_editing)
                      Positioned(
                        left: 10,
                        right: 70,
                        bottom: 6,
                        child: IgnorePointer(child: _ChatLog(roomId: room.id)),
                      ),
                  ],
                ),
              ),
              if (_editing)
                _EditPanel(
                  room: room,
                  placeKind: _placeKind,
                  canPlace: _placeOk,
                  onPick: (k) => setState(() {
                    _placeKind = k;
                    _previewTile = null;
                  }),
                  onPlace: () => _place(room),
                )
              else
                _ChatPanel(roomId: room.id, controller: _text, onSend: _send),
            ],
          ),
        ),
      ),
    );
  }
}

class _RoomView extends StatefulWidget {
  final Room room;
  final String? placeKind;
  final Offset? placeTile;
  final bool placeOk;
  final void Function(String id) onAvatar;
  final void Function(int x, int y) onTile;

  const _RoomView({
    required this.room,
    required this.placeKind,
    required this.placeTile,
    required this.placeOk,
    required this.onAvatar,
    required this.onTile,
  });

  @override
  State<_RoomView> createState() => _RoomViewState();
}

class _RoomViewState extends State<_RoomView> with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  AppStore? _store;
  Duration _last = Duration.zero;
  double _t = 0;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker((d) {
      final dt = (d - _last).inMicroseconds / 1e6;
      _last = d;
      _t = d.inMicroseconds / 1e6;
      _store?.step(math.min(dt, 0.05));
      if (mounted) setState(() {});
    })..start();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _store = StoreScope.of(context);
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final room = widget.room;
    return LayoutBuilder(builder: (context, c) {
      final size = Size(c.maxWidth, c.maxHeight);
      final g = IsoGeom(size);
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (d) {
          final occ = store.occupants(room.id);
          final ids = occ.keys.toList()
            ..sort((a, b) => (occ[b]!.dx + occ[b]!.dy).compareTo(occ[a]!.dx + occ[a]!.dy));
          for (final id in ids) {
            if (g.avatarRect(occ[id]!).contains(d.localPosition)) {
              widget.onAvatar(id);
              return;
            }
          }
          final gp = g.toGrid(d.localPosition);
          final tx = gp.dx.floor(), ty = gp.dy.floor();
          if (tx >= 0 && ty >= 0 && tx < roomGrid && ty < roomGrid) widget.onTile(tx, ty);
        },
        child: CustomPaint(
          size: size,
          painter: RoomPainter(
            room: room,
            pos: store.occupants(room.id),
            users: store.users,
            emotes: store.emotes,
            bubbles: store.bubbles,
            moving: store.movingIds,
            backFacing: store.backFacing,
            t: _t,
            placeKind: widget.placeKind,
            placeTile: widget.placeTile,
            placeOk: widget.placeOk,
          ),
        ),
      );
    });
  }
}

class _EditPanel extends StatelessWidget {
  final Room room;
  final String? placeKind;
  final bool canPlace;
  final void Function(String kind) onPick;
  final VoidCallback onPlace;

  const _EditPanel({
    required this.room,
    required this.placeKind,
    required this.canPlace,
    required this.onPick,
    required this.onPlace,
  });

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final stock = store.furnInv.entries.where((e) => e.value > 0).toList();
    final themes = [
      for (var i = 0; i < roomThemes.length; i++)
        if (store.owned.contains('theme$i')) i,
    ];
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xF2241C4D),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
        border: Border.all(color: Ui.a(Colors.white, .14)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Склад мебели', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
              const SizedBox(height: 8),
              if (stock.isEmpty)
                const Text('Склад пуст — купите мебель во вкладке «Магазин».',
                    style: TextStyle(color: Ui.dim))
              else
                SizedBox(
                  height: 86,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      for (final e in stock)
                        GestureDetector(
                          onTap: () => onPick(e.key),
                          child: Container(
                            width: 84,
                            margin: const EdgeInsets.only(right: 8),
                            decoration: BoxDecoration(
                              color: Ui.a(Colors.white, placeKind == e.key ? .16 : .07),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                width: 2,
                                color: placeKind == e.key ? Ui.accent : Ui.a(Colors.white, .12),
                              ),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(furnCatalog[e.key]!.emoji, style: const TextStyle(fontSize: 28)),
                                const SizedBox(height: 2),
                                Text(
                                  furnCatalog[e.key]!.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700),
                                ),
                                Text('×${e.value}',
                                    style: const TextStyle(fontSize: 11, color: Ui.gold)),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              const SizedBox(height: 10),
              const Text('Тема комнаты', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
              const SizedBox(height: 8),
              SizedBox(
                height: 38,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    for (final i in themes)
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                          label: Text(roomThemes[i].name),
                          selected: room.theme == i,
                          showCheckmark: false,
                          onSelected: (_) => store.setRoomTheme(room, i),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      placeKind == null
                          ? 'Выберите предмет и нажмите на клетку. Тап по мебели — убрать на склад.'
                          : 'Нажмите на клетку, затем «Поставить».',
                      style: const TextStyle(color: Ui.dim, fontSize: 12),
                    ),
                  ),
                  const SizedBox(width: 10),
                  SizedBox(
                    width: 140,
                    child: GradientButton(
                      height: 44,
                      label: 'Поставить',
                      icon: Icons.add_rounded,
                      onPressed: canPlace ? onPlace : null,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Последние сообщения поверх сцены комнаты.
class _ChatLog extends StatelessWidget {
  final String roomId;
  const _ChatLog({required this.roomId});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final all = store.chat(roomId);
    final last = all.length > 5 ? all.sublist(all.length - 5) : all;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 0; i < last.length; i++)
          Opacity(
            opacity: 0.45 + 0.55 * (i + 1) / last.length,
            child: Container(
              margin: const EdgeInsets.only(top: 3),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: Ui.a(Colors.black, .42),
                borderRadius: BorderRadius.circular(12),
              ),
              child: last[i].isSystem
                  ? Text(
                      last[i].text,
                      style: TextStyle(
                        fontSize: 12,
                        fontStyle: FontStyle.italic,
                        fontWeight: last[i].announce ? FontWeight.w800 : FontWeight.w500,
                        color: last[i].announce ? Ui.gold : Ui.a(Colors.white, .75),
                      ),
                    )
                  : Text.rich(
                      TextSpan(children: [
                        TextSpan(
                          text: '${store.users[last[i].userId]?.isStaff == true ? '★ ' : ''}'
                              '${store.users[last[i].userId]?.name ?? '?'}: ',
                          style: TextStyle(
                            fontWeight: FontWeight.w900,
                            color: _nameColor(store.users[last[i].userId]?.top),
                          ),
                        ),
                        TextSpan(text: last[i].text),
                      ]),
                      style: const TextStyle(fontSize: 13),
                    ),
            ),
          ),
      ],
    );
  }

  /// Подсветка цвета имени, чтобы оно читалось на тёмном фоне.
  Color _nameColor(Color? c) {
    if (c == null) return Colors.white;
    final h = HSLColor.fromColor(c);
    return h.withLightness(h.lightness.clamp(0.65, 0.85).toDouble()).toColor();
  }
}

class _ChatPanel extends StatefulWidget {
  final String roomId;
  final TextEditingController controller;
  final VoidCallback onSend;

  const _ChatPanel({
    required this.roomId,
    required this.controller,
    required this.onSend,
  });

  @override
  State<_ChatPanel> createState() => _ChatPanelState();
}

class _ChatPanelState extends State<_ChatPanel> {
  bool _emotes = false;

  static const _list = ['👋', '😀', '😂', '❤️', '🎉', '😎', '💃'];

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xF21D1640),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
        border: Border.all(color: Ui.a(Colors.white, .12)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedSize(
              duration: const Duration(milliseconds: 160),
              child: _emotes
                  ? SizedBox(
                      height: 56,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
                        children: [
                          for (final e in _list)
                            Padding(
                              padding: const EdgeInsets.only(right: 8),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(16),
                                onTap: () {
                                  store.sendEmote(e);
                                  setState(() => _emotes = false);
                                },
                                child: Container(
                                  width: 48,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    color: Ui.a(Colors.white, .09),
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  child: Text(e, style: const TextStyle(fontSize: 24)),
                                ),
                              ),
                            ),
                        ],
                      ),
                    )
                  : const SizedBox(width: double.infinity),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
              child: Row(
                children: [
                  Material(
                    color: _emotes ? Ui.violet : Ui.a(Colors.white, .1),
                    shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: () => setState(() => _emotes = !_emotes),
                      child: const SizedBox(
                        width: 46,
                        height: 46,
                        child: Icon(Icons.emoji_emotions_outlined),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: widget.controller,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => widget.onSend(),
                      decoration: Ui.input(null, hint: 'Написать в чат…').copyWith(isDense: true),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Material(
                    color: Colors.transparent,
                    shape: const CircleBorder(),
                    child: Ink(
                      width: 46,
                      height: 46,
                      decoration: const BoxDecoration(shape: BoxShape.circle, gradient: Ui.brand),
                      child: InkWell(
                        customBorder: const CircleBorder(),
                        onTap: widget.onSend,
                        child: const Icon(Icons.send_rounded, size: 22),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InviteSheet extends StatelessWidget {
  final String roomId;
  const _InviteSheet({required this.roomId});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final inRoom = store.occupants(roomId);
    final candidates = store.friendList.where((f) => !inRoom.containsKey(f.id)).toList();
    return SafeArea(
      child: candidates.isEmpty
          ? const Padding(
              padding: EdgeInsets.all(24),
              child: EmptyState(
                icon: Icons.group_outlined,
                title: 'Некого приглашать',
                text: 'Все ваши друзья уже здесь или у вас пока нет друзей.',
              ),
            )
          : ListView(
              shrinkWrap: true,
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(4, 0, 4, 10),
                  child: Text('Пригласить друга',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                ),
                for (final f in candidates)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: GlassCard(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      child: Row(
                        children: [
                          AvatarBadge(user: f, radius: 22),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(f.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                          ),
                          FilledButton.tonal(
                            onPressed: () {
                              store.inviteFriend(f.id);
                              Navigator.of(context).pop();
                            },
                            style: FilledButton.styleFrom(minimumSize: const Size(64, 38)),
                            child: const Text('Пригласить'),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
    );
  }
}
