import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../models.dart';
import '../store.dart';
import '../widgets/avatar.dart';
import '../widgets/iso.dart';
import '../widgets/user_sheet.dart';

class RoomScreen extends StatefulWidget {
  final String roomId;
  const RoomScreen({super.key, required this.roomId});

  @override
  State<RoomScreen> createState() => _RoomScreenState();
}

class _RoomScreenState extends State<RoomScreen> {
  AppStore? _store;
  bool _entered = false;
  final _text = TextEditingController();

  bool _editing = false;
  String? _placeKind;
  Offset? _previewTile;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _store = StoreScope.of(context);
    if (!_entered) {
      final room = _store!.roomById(widget.roomId);
      if (room != null && _store!.canEnter(room)) {
        _entered = true;
        _store!.enterRoom(widget.roomId);
      }
    }
  }

  @override
  void dispose() {
    if (_entered) _store?.leaveRoom();
    _text.dispose();
    super.dispose();
  }

  void _send() {
    _store?.sendMessage(_text.text);
    _text.clear();
  }

  void _onTile(Room room, int tx, int ty) {
    final store = StoreScope.of(context);
    if (!_editing) {
      store.moveMe(tx, ty);
      return;
    }
    if (_placeKind != null) {
      setState(() => _previewTile = Offset(tx.toDouble(), ty.toDouble()));
    } else {
      final f = furnAt(room, tx, ty);
      if (f != null) {
        store.removeFurniture(room, f);
        store.toast('${furnCatalog[f.kind]!.name} убран(а) на склад');
      }
    }
  }

  bool get _placeOk {
    final store = StoreScope.of(context);
    final room = store.roomById(widget.roomId);
    if (room == null || _placeKind == null || _previewTile == null) return false;
    return store.canPlace(room, _placeKind!, _previewTile!.dx.toInt(), _previewTile!.dy.toInt());
  }

  void _place(Room room) {
    final store = StoreScope.of(context);
    final t = _previewTile;
    final k = _placeKind;
    if (t == null || k == null) return;
    if (store.placeFurniture(room, k, t.dx.toInt(), t.dy.toInt())) {
      setState(() {
        _previewTile = null;
        if ((store.furnInv[k] ?? 0) <= 0) _placeKind = null;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final room = store.roomById(widget.roomId);
    if (room == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: Text('Комната удалена')));
    }
    if (!_entered) {
      return Scaffold(
        appBar: AppBar(title: Text(room.name)),
        body: const Center(child: Text('Комната закрыта модератором')),
      );
    }
    final liked = room.likedBy.contains('me');
    return Scaffold(
      backgroundColor: const Color(0xFF4F5159),
      appBar: AppBar(
        title: Text(room.name),
        actions: [
          TextButton.icon(
            onPressed: () => store.toggleLike(room.id),
            icon: Icon(liked ? Icons.favorite : Icons.favorite_border, color: Colors.pinkAccent),
            label: Text('${room.likes}'),
          ),
          if (store.canEdit(room))
            IconButton(
              tooltip: 'Обустроить комнату',
              icon: Icon(_editing ? Icons.check_circle : Icons.chair_alt),
              onPressed: () => setState(() {
                _editing = !_editing;
                _placeKind = null;
                _previewTile = null;
              }),
            ),
          IconButton(
            tooltip: 'Пригласить друга',
            icon: const Icon(Icons.person_add_alt_1),
            onPressed: () => showModalBottomSheet<void>(
              context: context,
              showDragHandle: true,
              builder: (_) => _InviteSheet(roomId: room.id),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _RoomView(
              room: room,
              placeKind: _editing ? _placeKind : null,
              placeTile: _editing ? _previewTile : null,
              placeOk: _placeOk,
              onAvatar: (id) {
                if (id != 'me') showUserSheet(context, id);
              },
              onTile: (x, y) => _onTile(room, x, y),
            ),
          ),
          if (_editing)
            _EditPanel(
              room: room,
              placeKind: _placeKind,
              canPlace: _placeOk,
              onPick: (k) => setState(() {
                _placeKind = k;
                _previewTile = null;
              }),
              onPlace: () => _place(room),
            )
          else
            _ChatPanel(roomId: room.id, controller: _text, onSend: _send),
        ],
      ),
    );
  }
}

class _RoomView extends StatefulWidget {
  final Room room;
  final String? placeKind;
  final Offset? placeTile;
  final bool placeOk;
  final void Function(String id) onAvatar;
  final void Function(int x, int y) onTile;

  const _RoomView({
    required this.room,
    required this.placeKind,
    required this.placeTile,
    required this.placeOk,
    required this.onAvatar,
    required this.onTile,
  });

  @override
  State<_RoomView> createState() => _RoomViewState();
}

class _RoomViewState extends State<_RoomView> with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  AppStore? _store;
  Duration _last = Duration.zero;
  double _t = 0;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker((d) {
      final dt = (d - _last).inMicroseconds / 1e6;
      _last = d;
      _t = d.inMicroseconds / 1e6;
      _store?.step(math.min(dt, 0.05));
      if (mounted) setState(() {});
    })..start();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _store = StoreScope.of(context);
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final room = widget.room;
    return LayoutBuilder(builder: (context, c) {
      final size = Size(c.maxWidth, c.maxHeight);
      final g = IsoGeom(size);
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (d) {
          final occ = store.occupants(room.id);
          final ids = occ.keys.toList()
            ..sort((a, b) => (occ[b]!.dx + occ[b]!.dy).compareTo(occ[a]!.dx + occ[a]!.dy));
          for (final id in ids) {
            if (g.avatarRect(occ[id]!).contains(d.localPosition)) {
              widget.onAvatar(id);
              return;
            }
          }
          final gp = g.toGrid(d.localPosition);
          final tx = gp.dx.floor(), ty = gp.dy.floor();
          if (tx >= 0 && ty >= 0 && tx < roomGrid && ty < roomGrid) widget.onTile(tx, ty);
        },
        child: CustomPaint(
          size: size,
          painter: RoomPainter(
            room: room,
            pos: store.occupants(room.id),
            users: store.users,
            emotes: store.emotes,
            bubbles: store.bubbles,
            moving: store.movingIds,
            backFacing: store.backFacing,
            t: _t,
            placeKind: widget.placeKind,
            placeTile: widget.placeTile,
            placeOk: widget.placeOk,
          ),
        ),
      );
    });
  }
}

class _EditPanel extends StatelessWidget {
  final Room room;
  final String? placeKind;
  final bool canPlace;
  final void Function(String kind) onPick;
  final VoidCallback onPlace;

  const _EditPanel({
    required this.room,
    required this.placeKind,
    required this.canPlace,
    required this.onPick,
    required this.onPlace,
  });

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final stock = store.furnInv.entries.where((e) => e.value > 0).toList();
    final themes = [
      for (var i = 0; i < roomThemes.length; i++)
        if (store.owned.contains('theme$i')) i,
    ];
    return Material(
      elevation: 8,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Склад мебели', style: Theme.of(context).textTheme.labelLarge),
              const SizedBox(height: 4),
              if (stock.isEmpty)
                const Text('Склад пуст — купите мебель во вкладке «Магазин».')
              else
                SizedBox(
                  height: 42,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      for (final e in stock)
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text('${furnCatalog[e.key]!.emoji} ${furnCatalog[e.key]!.name} ×${e.value}'),
                            selected: placeKind == e.key,
                            onSelected: (_) => onPick(e.key),
                          ),
                        ),
                    ],
                  ),
                ),
              const SizedBox(height: 4),
              Text('Тема комнаты', style: Theme.of(context).textTheme.labelLarge),
              const SizedBox(height: 4),
              Wrap(
                spacing: 8,
                children: [
                  for (final i in themes)
                    ChoiceChip(
                      label: Text(roomThemes[i].name),
                      selected: room.theme == i,
                      onSelected: (_) => store.setRoomTheme(room, i),
                    ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      placeKind == null
                          ? 'Выберите предмет и нажмите на клетку. Тап по мебели — убрать на склад.'
                          : 'Нажмите на клетку, затем «Поставить».',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: canPlace ? onPlace : null,
                    child: const Text('Поставить'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ChatPanel extends StatelessWidget {
  final String roomId;
  final TextEditingController controller;
  final VoidCallback onSend;

  const _ChatPanel({
    required this.roomId,
    required this.controller,
    required this.onSend,
  });

  static const _emotes = ['👋', '😀', '😂', '❤️', '🎉', '😎', '💃'];

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final all = store.chat(roomId);
    final last = all.length > 30 ? all.sublist(all.length - 30) : all;
    return Material(
      elevation: 8,
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 100,
              child: ListView.builder(
                reverse: true,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                itemCount: last.length,
                itemBuilder: (context, i) {
                  final m = last[last.length - 1 - i];
                  if (m.isSystem) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: Text(
                        m.text,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontStyle: FontStyle.italic,
                          fontWeight: m.announce ? FontWeight.bold : FontWeight.normal,
                          fontSize: 12,
                          color: m.announce ? Colors.orange : Theme.of(context).hintColor,
                        ),
                      ),
                    );
                  }
                  final u = store.users[m.userId]!;
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 2),
                    child: Text.rich(TextSpan(children: [
                      TextSpan(
                        text: '${u.isStaff ? '★ ' : ''}${u.name}: ',
                        style: TextStyle(fontWeight: FontWeight.bold, color: u.top),
                      ),
                      TextSpan(text: m.text),
                    ])),
                  );
                },
              ),
            ),
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                children: [
                  for (final e in _emotes)
                    TextButton(
                      onPressed: () => store.sendEmote(e),
                      child: Text(e, style: const TextStyle(fontSize: 22)),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 4, 8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => onSend(),
                      decoration: const InputDecoration(
                        hintText: 'Сообщение…',
                        isDense: true,
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  IconButton(onPressed: onSend, icon: const Icon(Icons.send)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InviteSheet extends StatelessWidget {
  final String roomId;
  const _InviteSheet({required this.roomId});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final inRoom = store.occupants(roomId);
    final candidates = store.friendList.where((f) => !inRoom.containsKey(f.id)).toList();
    return SafeArea(
      child: candidates.isEmpty
          ? const Padding(
              padding: EdgeInsets.all(24),
              child: Text('Все ваши друзья уже здесь или у вас пока нет друзей.'),
            )
          : ListView(
              shrinkWrap: true,
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
                  child: Text('Пригласить друга',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                ),
                for (final f in candidates)
                  ListTile(
                    leading: AvatarBadge(user: f),
                    title: Text(f.name),
                    trailing: FilledButton.tonal(
                      onPressed: () {
                        store.inviteFriend(f.id);
                        Navigator.of(context).pop();
                      },
                      child: const Text('Пригласить'),
                    ),
                  ),
              ],
            ),
    );
  }
}
