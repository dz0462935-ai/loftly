import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../ui.dart';
import '../widgets/avatar.dart';
import 'friends_tab.dart';
import 'invites_tab.dart';
import 'profile_tab.dart';
import 'rooms_tab.dart';
import 'shop_tab.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  static const _titles = ['Комнаты', 'Друзья', 'Магазин', 'Приглашения', 'Профиль'];
  static const _subtitles = [
    'Заходите в гости или создайте свою',
    'Ваши друзья и запросы',
    'Одежда, мебель и капсулы удачи',
    'Вас зовут в комнаты',
    'Ваш персонаж и склад',
  ];
  static const _tabs = <Widget>[
    RoomsTab(),
    FriendsTab(),
    ShopTab(),
    InvitesTab(),
    ProfileTab(),
  ];

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final me = store.me;
    return Scaffold(
      extendBody: true,
      body: GameBackground(
        child: SafeArea(
          bottom: false,
          child: Column(
            children: [
              _Header(
                name: me.name,
                role: me.role,
                coins: me.coins,
                gems: me.gems,
                user: me,
                onAvatar: () => setState(() => _index = 4),
                onLogout: store.onLogout,
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 6, 20, 6),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _titles[_index],
                        style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, height: 1.1),
                      ),
                      const SizedBox(height: 2),
                      Text(_subtitles[_index], style: const TextStyle(color: Ui.dim, fontSize: 13)),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 220),
                  switchInCurve: Curves.easeOut,
                  child: KeyedSubtree(key: ValueKey(_index), child: _tabs[_index]),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: _BottomBar(
        index: _index,
        onSelect: (i) => setState(() => _index = i),
        requests: store.incomingRequests.length,
        invites: store.invites.length,
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final String name;
  final Role role;
  final int coins;
  final int gems;
  final User user;
  final VoidCallback onAvatar;
  final VoidCallback? onLogout;

  const _Header({
    required this.name,
    required this.role,
    required this.coins,
    required this.gems,
    required this.user,
    required this.onAvatar,
    required this.onLogout,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 8, 0),
      child: Row(
        children: [
          GestureDetector(
            onTap: onAvatar,
            child: Container(
              padding: const EdgeInsets.all(2.5),
              decoration: const BoxDecoration(shape: BoxShape.circle, gradient: Ui.brand),
              child: AvatarBadge(user: user, radius: 20),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
                ),
                if (role != Role.player)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Tag(
                      roleName(role),
                      color: role == Role.admin ? Ui.accent : Ui.green,
                      icon: Icons.star_rounded,
                    ),
                  ),
              ],
            ),
          ),
          CurrencyPill(emoji: '🪙', value: coins),
          const SizedBox(width: 6),
          CurrencyPill(emoji: '💎', value: gems),
          PopupMenuButton<String>(
            tooltip: 'Меню',
            icon: const Icon(Icons.more_vert),
            color: Ui.surfaceHi,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            onSelected: (v) {
              if (v == 'logout') onLogout?.call();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(
                value: 'logout',
                child: Row(children: [
                  Icon(Icons.logout, size: 20),
                  SizedBox(width: 10),
                  Text('Выйти'),
                ]),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _BottomBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onSelect;
  final int requests;
  final int invites;

  const _BottomBar({
    required this.index,
    required this.onSelect,
    required this.requests,
    required this.invites,
  });

  Widget _icon(IconData icon, int badge) => Badge(
        label: Text('$badge'),
        isLabelVisible: badge > 0,
        backgroundColor: Ui.accent,
        textColor: Colors.white,
        child: Icon(icon),
      );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xEE1D1640),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Ui.a(Colors.white, .14)),
            boxShadow: [
              BoxShadow(color: Ui.a(Colors.black, .5), blurRadius: 20, offset: const Offset(0, 8)),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(28),
            child: NavigationBar(
              selectedIndex: index,
              onDestinationSelected: onSelect,
              destinations: [
                NavigationDestination(
                  icon: _icon(Icons.meeting_room_outlined, 0),
                  selectedIcon: _icon(Icons.meeting_room_rounded, 0),
                  label: 'Комнаты',
                ),
                NavigationDestination(
                  icon: _icon(Icons.group_outlined, requests),
                  selectedIcon: _icon(Icons.group_rounded, requests),
                  label: 'Друзья',
                ),
                NavigationDestination(
                  icon: _icon(Icons.storefront_outlined, 0),
                  selectedIcon: _icon(Icons.storefront_rounded, 0),
                  label: 'Магазин',
                ),
                NavigationDestination(
                  icon: _icon(Icons.mail_outline, invites),
                  selectedIcon: _icon(Icons.mail_rounded, invites),
                  label: 'Приглашения',
                ),
                NavigationDestination(
                  icon: _icon(Icons.person_outline, 0),
                  selectedIcon: _icon(Icons.person_rounded, 0),
                  label: 'Профиль',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
