import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';
import { BOXES, POOLS, ITEMS } from '../src/catalog.js';

const { server, db } = createApp({ dbPath: ':memory:', adminUsername: 'boss' });
await new Promise((r) => server.listen(0, r));
const base = `http://127.0.0.1:${server.address().port}`;

async function call(method, path, body, token) {
  const res = await fetch(base + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return { status: res.status, json: await res.json() };
}
const ok = (r) => { assert.equal(r.status, 200, JSON.stringify(r.json)); return r.json; };

// --- регистрация / вход ---
let r = await call('POST', '/api/register', { username: 'a!', password: '123456' });
assert.equal(r.status, 400);
r = await call('POST', '/api/register', { username: 'alice', password: '123' });
assert.equal(r.status, 400);
const alice = ok(await call('POST', '/api/register', { username: 'alice', password: 'secret1', name: 'Алиса' }));
assert.equal(alice.profile.coins, 500);
assert.equal(alice.profile.role, 'player');
assert.equal((await call('POST', '/api/register', { username: 'ALICE', password: 'secret1' })).status, 409);
assert.equal((await call('POST', '/api/login', { username: 'alice', password: 'wrong' })).status, 401);
const alice2 = ok(await call('POST', '/api/login', { username: 'alice', password: 'secret1' }));
assert.equal((await call('GET', '/api/me')).status, 401);
assert.equal(ok(await call('GET', '/api/me', undefined, alice2.token)).name, 'Алиса');
const boss = ok(await call('POST', '/api/register', { username: 'boss', password: 'secret1' }));
assert.equal(boss.profile.role, 'admin');
const T = alice.token;

// --- бонус дня ---
let d = ok(await call('POST', '/api/daily', {}, T));
assert.equal(d.gained.coins, 100);
assert.equal((await call('POST', '/api/daily', {}, T)).status, 400);

// --- магазин / одежда ---
assert.equal((await call('POST', '/api/shop/buy', { itemId: 'nope' }, T)).status, 400);
let p = ok(await call('POST', '/api/shop/buy', { itemId: 'hat1' }, T));
assert.equal(p.coins, 600 - 100);
assert.equal((await call('POST', '/api/shop/buy', { itemId: 'hat1' }, T)).status, 400);
assert.equal((await call('POST', '/api/shop/buy', { itemId: 'hat2' }, T)).json.error, 'no_gems');
assert.equal((await call('POST', '/api/equip', { slot: 'hat', itemId: 'hat4' }, T)).json.error, 'not_owned');
assert.equal(ok(await call('POST', '/api/equip', { slot: 'hat', itemId: 'hat1' }, T)).equip.hat, 'hat1');
assert.equal(ok(await call('POST', '/api/equip', { slot: 'hat', itemId: null }, T)).equip.hat, null);
assert.equal((await call('POST', '/api/equip', { slot: 'top', itemId: 'hat1' }, T)).status, 400);

// --- лотерея ---
const info = ok(await call('GET', '/api/lottery', undefined, T));
assert.equal(info.boxes.basic.cost.coins, 100);
assert.equal(info.boxes.basic.odds.legendary, 0.5);
assert.equal((await call('POST', '/api/lottery/roll', { box: 'nope', count: 1 }, T)).status, 400);
assert.equal((await call('POST', '/api/lottery/roll', { box: 'basic', count: 5 }, T)).status, 400);
const before = ok(await call('GET', '/api/me', undefined, T));
const one = ok(await call('POST', '/api/lottery/roll', { box: 'basic', count: 1 }, T));
assert.equal(one.results.length, 1);
const res0 = one.results[0];
assert.ok(ITEMS[res0.itemId]);
assert.ok(POOLS[res0.rarity].includes(res0.itemId));
assert.equal(one.profile.coins, before.coins - 100 + res0.refund.coins);
db.prepare('UPDATE users SET coins = 5000 WHERE username = ?').run('alice');
const ten = ok(await call('POST', '/api/lottery/roll', { box: 'basic', count: 10 }, T));
assert.equal(ten.results.length, 10);
assert.ok(ten.results.some((x) => x.rarity !== 'common'), 'гарантия редкого раз в 10 круток');
// награда попала в инвентарь
for (const x of ten.results) {
  if (x.slot === 'furn') assert.ok((ten.profile.furniture[x.itemId.slice(5)] ?? 0) >= 1);
  else assert.ok(ten.profile.owned.includes(x.itemId));
}
// нельзя уйти в минус
const poor = ok(await call('POST', '/api/register', { username: 'poor', password: 'secret1' }));
db.prepare('UPDATE users SET coins = 99 WHERE username = ?').run('poor');
assert.equal((await call('POST', '/api/lottery/roll', { box: 'basic', count: 1 }, poor.token)).json.error, 'no_coins');
assert.equal(ok(await call('GET', '/api/me', undefined, poor.token)).coins, 99);
assert.equal((await call('POST', '/api/lottery/roll', { box: 'premium', count: 10 }, poor.token)).json.error, 'no_gems');

// статистика: 3000 круток обычной капсулы близки к заявленным шансам (с учётом гарантий)
{
  const { createGame } = await import('../src/game.js');
  const { openDb } = await import('../src/db.js');
  const sdb = openDb(':memory:');
  const g = createGame(sdb);
  const u = g.register({ username: 'stat', password: 'secret1' }).profile;
  const counts = { common: 0, rare: 0, epic: 0, legendary: 0 };
  for (let i = 0; i < 300; i++) {
    sdb.prepare('UPDATE users SET coins = 100000, gems = 1000 WHERE id = ?').run(u.id);
    for (const x of g.roll(u.id, 'basic', 10).results) counts[x.rarity]++;
  }
  console.log('распределение за 3000 круток:', counts);
  assert.ok(counts.common > 1800 && counts.common < 2500, 'common');
  assert.ok(counts.legendary > 0 && counts.legendary < 120, 'legendary');
  // премиум: обычных нет вообще
  let pc = 0;
  for (let i = 0; i < 20; i++) for (const x of g.roll(u.id, 'premium', 10).results) if (x.rarity === 'common') pc++;
  assert.equal(pc, 0);
}

// --- комнаты ---
const rm = ok(await call('POST', '/api/rooms', { name: 'Моя комната' }, T));
assert.equal(rm.profile.coins, ok(await call('GET', '/api/me', undefined, T)).coins); // первая бесплатна
const roomId = rm.room.id;
let lay = await call('PUT', `/api/rooms/${roomId}/layout`, { items: [{ kind: 'sofa', x: 0, y: 0 }, { kind: 'lamp', x: 3, y: 3 }] }, T);
assert.equal(lay.status, 200, JSON.stringify(lay.json));
assert.equal((await call('PUT', `/api/rooms/${roomId}/layout`, { items: [{ kind: 'sofa', x: 7, y: 0 }] }, T)).json.error, 'out_of_room');
assert.equal((await call('PUT', `/api/rooms/${roomId}/layout`, { items: [{ kind: 'sofa', x: 0, y: 0 }, { kind: 'lamp', x: 1, y: 0 }] }, T)).json.error, 'overlap');
assert.equal((await call('PUT', `/api/rooms/${roomId}/layout`, { items: [{ kind: 'bed', x: 0, y: 0 }, { kind: 'bed', x: 4, y: 4 }, { kind: 'bed', x: 6, y: 0 }] }, T)).status, 400);
assert.equal((await call('PUT', `/api/rooms/${roomId}/layout`, { items: [] }, poor.token)).status, 403);
assert.equal(ok(await call('POST', `/api/rooms/${roomId}/like`, {}, poor.token)).likes, 1);
assert.equal(ok(await call('POST', `/api/rooms/${roomId}/like`, {}, poor.token)).likes, 0);
assert.equal((await call('POST', `/api/rooms/${roomId}/theme`, { theme: 4 }, T)).json.error, 'theme_locked');
assert.equal(ok(await call('GET', '/api/rooms', undefined, T)).rooms.length, 1);

// --- WebSocket ---
function openWs(token) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(`ws://127.0.0.1:${server.address().port}/ws?token=${token}`);
    const inbox = [];
    const waiters = [];
    ws.onmessage = (e) => {
      const m = JSON.parse(e.data);
      const i = waiters.findIndex((w) => w.pred(m));
      if (i >= 0) waiters.splice(i, 1)[0].res(m); else inbox.push(m);
    };
    ws.onerror = reject;
    ws.onopen = () => resolve({
      send: (o) => ws.send(JSON.stringify(o)),
      close: () => ws.close(),
      next: (pred) => new Promise((res, rej) => {
        const i = inbox.findIndex(pred);
        if (i >= 0) return res(inbox.splice(i, 1)[0]);
        const t = setTimeout(() => rej(new Error('ws timeout')), 3000);
        waiters.push({ pred, res: (m) => { clearTimeout(t); res(m); } });
      }),
    });
  });
}
await assert.rejects(openWs('bad-token-xxxxxxxxxxxxxxxxxxxxxx'));
const wa = await openWs(T);
const wp = await openWs(poor.token);
await wa.next((m) => m.t === 'hello');
await wp.next((m) => m.t === 'hello');
wa.send({ t: 'join', room: roomId });
const joined = await wa.next((m) => m.t === 'joined');
assert.equal(joined.players.length, 1);
wp.send({ t: 'join', room: roomId });
await wp.next((m) => m.t === 'joined');
const pj = await wa.next((m) => m.t === 'player_join');
assert.equal(pj.player.name, 'poor');
wa.send({ t: 'move', x: 5, y: 5 });
const mv = await wp.next((m) => m.t === 'move');
assert.deepEqual(mv.path.at(-1), [5, 5]);
wa.send({ t: 'chat', text: 'привет, дурак' });
const ch = await wp.next((m) => m.t === 'chat');
assert.equal(ch.text, 'привет, ***');
// мут
const poorId = poor.profile.id;
assert.equal((await call('POST', `/api/admin/users/${poorId}`, { muted: true }, T)).status, 403); // игрок не модератор
ok(await call('POST', `/api/admin/users/${poorId}`, { muted: true }, boss.token));
wp.send({ t: 'chat', text: 'я замучен' });
assert.equal((await wp.next((m) => m.t === 'error')).code, 'muted');
// бан отключает и закрывает сессию
ok(await call('POST', `/api/admin/users/${poorId}`, { banned: true }, boss.token));
assert.equal((await call('GET', '/api/me', undefined, poor.token)).status, 401);
assert.equal((await call('POST', '/api/login', { username: 'poor', password: 'secret1' })).status, 403);
wa.close();
wp.close();

console.log('ALL OK');
server.close();
process.exit(0);
