import 'package:flutter/material.dart';

import '../api.dart';
import '../store.dart';

const _rarityOrder = ['common', 'rare', 'epic', 'legendary'];
const _rarityColors = <String, Color>{
  'common': Color(0xFF78909C),
  'rare': Color(0xFF42A5F5),
  'epic': Color(0xFFAB47BC),
  'legendary': Color(0xFFFFB300),
};
const _rarityNames = <String, String>{
  'common': 'Обычный',
  'rare': 'Редкий',
  'epic': 'Эпический',
  'legendary': 'Легендарный',
};

class LotteryScreen extends StatefulWidget {
  final AppStore store;
  final ApiClient api;

  const LotteryScreen({super.key, required this.store, required this.api});

  @override
  State<LotteryScreen> createState() => _LotteryScreenState();
}

class _LotteryScreenState extends State<LotteryScreen> {
  Map<String, dynamic>? _info;
  String? _error;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await widget.api.lottery();
      if (mounted) {
        setState(() {
          _info = r;
          _error = null;
        });
      }
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    }
  }

  Future<void> _roll(String box, int count) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final r = await widget.api.roll(box, count);
      widget.store.applyProfile(r['profile'] as Map<String, dynamic>);
      final results = (r['results'] as List<dynamic>).map((e) => e as Map<String, dynamic>).toList();
      await _load();
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (_) => _ResultDialog(results: results),
      );
    } on ApiException catch (e) {
      widget.store.toast(e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _boxCard(Map<String, dynamic> b) {
    final cost = b['cost'] as Map<String, dynamic>;
    final coins = cost['coins'] as int;
    final gems = cost['gems'] as int;
    final price = coins > 0 ? coins : gems;
    final cur = coins > 0 ? '🪙' : '💎';
    final odds = b['odds'] as Map<String, dynamic>;
    final progress = b['progress'] as Map<String, dynamic>;
    final pity = (b['pity'] as List<dynamic>).map((e) => e as Map<String, dynamic>).toList();
    final key = b['key'] as String;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(b['name'] as String, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            for (final r in _rarityOrder)
              if ((odds[r] as num) > 0)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(
                    children: [
                      Icon(Icons.circle, size: 12, color: _rarityColors[r]),
                      const SizedBox(width: 8),
                      Text(_rarityNames[r]!),
                      const Spacer(),
                      Text('${odds[r]}%'),
                    ],
                  ),
                ),
            const SizedBox(height: 8),
            for (final rule in pity)
              Builder(builder: (_) {
                final every = rule['every'] as int;
                final at = rule['atLeast'] as String;
                final left = every - ((progress[at] as int?) ?? 0);
                return Text(
                  'Гарантия: ${_rarityNames[at]!.toLowerCase()} или лучше — не позже чем через $left кр.',
                  style: Theme.of(context).textTheme.bodySmall,
                );
              }),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: FilledButton(
                    onPressed: _busy ? null : () => _roll(key, 1),
                    child: Text('×1 · $price $cur'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton.tonal(
                    onPressed: _busy ? null : () => _roll(key, 10),
                    child: Text('×10 · ${price * 10} $cur'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _pools() {
    final pools = _info!['pools'] as Map<String, dynamic>;
    return Card(
      child: ExpansionTile(
        title: const Text('Что может выпасть'),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (final r in _rarityOrder)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_rarityNames[r]!,
                      style: TextStyle(fontWeight: FontWeight.w600, color: _rarityColors[r])),
                  Text(((pools[r] as Map<String, dynamic>)['items'] as List<dynamic>)
                      .map((e) => (e as Map<String, dynamic>)['name'] as String)
                      .join(', ')),
                ],
              ),
            ),
          const Text('Повторный предмет (кроме мебели) превращается в монеты или кристаллы.'),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final info = _info;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Капсулы удачи'),
        actions: [
          AnimatedBuilder(
            animation: widget.store,
            builder: (_, __) => Center(
              child: Padding(
                padding: const EdgeInsets.only(right: 12),
                child: Text(
                  '${widget.store.me.coins} 🪙  ${widget.store.me.gems} 💎',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ),
        ],
      ),
      body: info == null
          ? Center(
              child: _error == null
                  ? const CircularProgressIndicator()
                  : Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(_error!),
                        const SizedBox(height: 12),
                        FilledButton(onPressed: _load, child: const Text('Повторить')),
                      ],
                    ),
            )
          : ListView(
              padding: const EdgeInsets.all(12),
              children: [
                for (final b in (info['boxes'] as Map<String, dynamic>).values)
                  _boxCard(b as Map<String, dynamic>),
                _pools(),
              ],
            ),
    );
  }
}

class _ResultDialog extends StatelessWidget {
  final List<Map<String, dynamic>> results;
  const _ResultDialog({required this.results});

  String _note(Map<String, dynamic> r) {
    if (r['slot'] == 'furn') return 'на склад';
    if (r['duplicate'] == true) {
      final rf = r['refund'] as Map<String, dynamic>;
      final coins = rf['coins'] as int;
      final gems = rf['gems'] as int;
      final parts = <String>[
        if (coins > 0) '+$coins 🪙',
        if (gems > 0) '+$gems 💎',
      ];
      return 'повтор → ${parts.join(' ')}';
    }
    return 'новый предмет!';
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Выпало'),
      content: SizedBox(
        width: double.maxFinite,
        child: ListView(
          shrinkWrap: true,
          children: [
            for (final r in results)
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.circle, color: _rarityColors[r['rarity'] as String]),
                title: Text(r['name'] as String),
                subtitle: Text('${r['rarityName']} · ${_note(r)}'),
              ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Круто')),
      ],
    );
  }
}
