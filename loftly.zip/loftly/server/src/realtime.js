import { FURN, ROOM_GRID } from './catalog.js';

const MAX_PER_ROOM = 30;
const EMOJIS = new Set(['👋', '😀', '😂', '❤️', '🎉', '😎', '💃', '😮', '😢', '👍']);
// Парные эмоции: нужен второй игрок рядом, он должен принять.
const PAIR_KINDS = { hug: '🤗', dance: '💃' };
const PAIR_TTL = 30000;
const PAIR_RANGE = 3; // манхэттенское расстояние между игроками
const SIT_DIR = 1; // посадка лицом «вперёд» (к зрителю)

/** Клетки мебели, на которую можно сесть: 'x,y' -> uid мебели. */
function seatMap(furniture) {
  const s = new Map();
  furniture.forEach((f, i) => {
    const spec = FURN[f.kind];
    if (!spec || !spec.seat) return;
    for (let dx = 0; dx < spec.w; dx++) for (let dy = 0; dy < spec.d; dy++) s.set(`${f.x + dx},${f.y + dy}`, `${i}:${f.kind}`);
  });
  return s;
}

function blockedSet(furniture) {
  const s = new Set();
  for (const f of furniture) {
    const spec = FURN[f.kind];
    if (!spec || spec.walkable) continue;
    for (let dx = 0; dx < spec.w; dx++) for (let dy = 0; dy < spec.d; dy++) s.add(`${f.x + dx},${f.y + dy}`);
  }
  return s;
}

/** Кратчайший путь по сетке (BFS, 4 направления). Возвращает клетки без стартовой. */
export function findPath(blocked, from, to) {
  const key = (x, y) => `${x},${y}`;
  if (blocked.has(key(to.x, to.y))) return null;
  const prev = new Map([[key(from.x, from.y), null]]);
  const queue = [[from.x, from.y]];
  for (let i = 0; i < queue.length; i++) {
    const [x, y] = queue[i];
    if (x === to.x && y === to.y) break;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + dx;
      const ny = y + dy;
      const k = key(nx, ny);
      if (nx < 0 || ny < 0 || nx >= ROOM_GRID || ny >= ROOM_GRID || prev.has(k) || blocked.has(k)) continue;
      prev.set(k, key(x, y));
      queue.push([nx, ny]);
    }
  }
  if (!prev.has(key(to.x, to.y))) return null;
  const path = [];
  for (let k = key(to.x, to.y); k && k !== key(from.x, from.y); k = prev.get(k)) {
    const [x, y] = k.split(',').map(Number);
    path.push([x, y]);
  }
  return path.reverse();
}

export function createHub(game) {
  const rooms = new Map(); // roomId -> { members: Map<userId, member>, blocked:Set }
  const byUser = new Map(); // userId -> member

  const send = (m, obj) => m.conn.send(JSON.stringify(obj));
  const broadcast = (room, obj, exceptId) => {
    const s = JSON.stringify(obj);
    for (const m of room.members.values()) if (m.user.id !== exceptId) m.conn.send(s);
  };
  const snapshot = (m) => ({
    ...game.publicUser(game.userById(m.user.id)), x: m.x, y: m.y, sit: !!m.sit,
  });
  const sitters = (room) => new Set([...room.members.values()].filter((o) => o.sit).map((o) => `${o.x},${o.y}`));

  function leave(m) {
    if (!m.roomId) return;
    const roomId = m.roomId;
    const room = rooms.get(roomId);
    m.roomId = null;
    if (!room) return;
    m.sit = false;
    room.members.delete(m.user.id);
    broadcast(room, { t: 'player_leave', id: m.user.id });
    if (room.members.size === 0) rooms.delete(roomId);
  }

  function join(m, roomId) {
    const row = game.getRoom(roomId);
    const u = game.userById(m.user.id);
    if (row.closed && u.role !== 'admin') return send(m, { t: 'error', code: 'room_closed', message: 'Комната закрыта' });
    if (!row.is_public && row.owner_id !== u.id && u.role !== 'admin') {
      return send(m, { t: 'error', code: 'private_room', message: 'Комната приватная' });
    }
    leave(m);
    let room = rooms.get(roomId);
    if (!room) {
      room = { id: roomId, members: new Map(), blocked: new Set(), seats: new Map(), pairs: new Map() };
      rooms.set(roomId, room);
    }
    if (room.members.size >= MAX_PER_ROOM) return send(m, { t: 'error', code: 'room_full', message: 'Комната заполнена' });
    room.blocked = blockedSet(JSON.parse(row.furniture));
    room.seats = seatMap(JSON.parse(row.furniture));
    // Стартовая клетка: ближайшая свободная к центру нижнего края.
    const taken = new Set([...room.members.values()].map((o) => `${o.x},${o.y}`));
    let spawn = null;
    for (let r = 0; r < ROOM_GRID * 2 && !spawn; r++) {
      for (let x = 0; x < ROOM_GRID && !spawn; x++) {
        const y = ROOM_GRID - 1 - (r % ROOM_GRID);
        const k = `${x},${y}`;
        if (!room.blocked.has(k) && !taken.has(k)) spawn = { x, y };
      }
    }
    m.roomId = roomId;
    m.x = spawn ? spawn.x : 0;
    m.y = spawn ? spawn.y : 0;
    m.lastMove = 0;
    m.sit = false;
    room.members.set(u.id, m);
    send(m, {
      t: 'joined', you: u.id, room: game.roomRow(row, u.id, room.members.size),
      players: [...room.members.values()].map(snapshot),
    });
    broadcast(room, { t: 'player_join', player: snapshot(m) }, u.id);
  }

  function handle(m, raw) {
    let msg;
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }
    if (!msg || typeof msg.t !== 'string') return;
    const nowMs = Date.now();
    // Общий лимит: не больше 20 сообщений в секунду.
    m.bucket = (m.bucket ?? 0) * Math.max(0, 1 - (nowMs - (m.bucketAt ?? nowMs)) / 1000) + 1;
    m.bucketAt = nowMs;
    if (m.bucket > 20) return;
    try {
      if (msg.t === 'join') return join(m, Number(msg.room));
      if (msg.t === 'leave') return leave(m);
      const room = m.roomId && rooms.get(m.roomId);
      if (!room) return;
      if (msg.t === 'move') {
        const x = Number(msg.x);
        const y = Number(msg.y);
        if (!Number.isInteger(x) || !Number.isInteger(y) || x < 0 || y < 0 || x >= ROOM_GRID || y >= ROOM_GRID) return;
        if (nowMs - m.lastMove < 150) return;
        m.lastMove = nowMs;
        const path = findPath(room.blocked, { x: m.x, y: m.y }, { x, y });
        if (!path || path.length === 0) return;
        const end = path[path.length - 1];
        m.x = end[0];
        m.y = end[1];
        m.sit = false;
        broadcast(room, { t: 'move', id: m.user.id, path, sit: false });
      } else if (msg.t === 'sit') {
        const x = Number(msg.x);
        const y = Number(msg.y);
        if (!Number.isInteger(x) || !Number.isInteger(y)) return;
        if (nowMs - m.lastMove < 150) return;
        const k = `${x},${y}`;
        if (!room.seats.has(k)) return send(m, { t: 'error', code: 'not_seat', message: 'Сюда нельзя сесть' });
        if (sitters(room).has(k) && !(m.sit && m.x === x && m.y === y)) {
          return send(m, { t: 'error', code: 'seat_taken', message: 'Место занято' });
        }
        m.lastMove = nowMs;
        if (m.x === x && m.y === y) {
          m.sit = true;
          return broadcast(room, { t: 'move', id: m.user.id, path: [], sit: true, dir: SIT_DIR });
        }
        const free = new Set(room.blocked);
        free.delete(k);
        const path = findPath(free, { x: m.x, y: m.y }, { x, y });
        if (!path || path.length === 0) return send(m, { t: 'error', code: 'no_path', message: 'Туда не пройти' });
        m.x = x;
        m.y = y;
        m.sit = true;
        broadcast(room, { t: 'move', id: m.user.id, path, sit: true, dir: SIT_DIR });
      } else if (msg.t === 'pair') {
        const kind = PAIR_KINDS[msg.kind] ? msg.kind : null;
        const other = [...room.members.values()].find((o) => o.user.id === Number(msg.target));
        if (!kind || !other || other === m) return;
        if (Math.abs(other.x - m.x) + Math.abs(other.y - m.y) > PAIR_RANGE) {
          return send(m, { t: 'error', code: 'too_far', message: 'Подойдите ближе' });
        }
        if (nowMs - (m.lastPair ?? 0) < 2000) return;
        m.lastPair = nowMs;
        room.pairs.set(`${other.user.id}:${m.user.id}`, { kind, at: nowMs });
        const u = game.userById(m.user.id);
        send(other, { t: 'pair_invite', from: m.user.id, name: u.name, kind });
        send(m, { t: 'pair_sent', to: other.user.id });
      } else if (msg.t === 'pair_accept') {
        const key = `${m.user.id}:${Number(msg.from)}`;
        const p = room.pairs.get(key);
        room.pairs.delete(key);
        const other = [...room.members.values()].find((o) => o.user.id === Number(msg.from));
        if (!p || !other || nowMs - p.at > PAIR_TTL) return send(m, { t: 'error', code: 'pair_expired', message: 'Приглашение устарело' });
        if (Math.abs(other.x - m.x) + Math.abs(other.y - m.y) > PAIR_RANGE) {
          return send(m, { t: 'error', code: 'too_far', message: 'Подойдите ближе' });
        }
        broadcast(room, { t: 'pair', a: other.user.id, b: m.user.id, kind: p.kind, emoji: PAIR_KINDS[p.kind] });
      } else if (msg.t === 'pair_decline') {
        const key = `${m.user.id}:${Number(msg.from)}`;
        const p = room.pairs.get(key);
        room.pairs.delete(key);
        const other = p && [...room.members.values()].find((o) => o.user.id === Number(msg.from));
        if (other) send(other, { t: 'error', code: 'pair_declined', message: 'Игрок отказался' });
      } else if (msg.t === 'chat') {
        const u = game.userById(m.user.id);
        if (u.muted) return send(m, { t: 'error', code: 'muted', message: 'Вам запрещено писать в чат' });
        if (nowMs - (m.lastChat ?? 0) < 700) return send(m, { t: 'error', code: 'slow_down', message: 'Не так быстро' });
        const text = game.filterChat(msg.text);
        if (!text) return;
        m.lastChat = nowMs;
        broadcast(room, { t: 'chat', id: u.id, name: u.name, text });
      } else if (msg.t === 'emote') {
        if (!EMOJIS.has(msg.emoji)) return;
        broadcast(room, { t: 'emote', id: m.user.id, emoji: msg.emoji });
      }
    } catch (e) {
      if (e.status) send(m, { t: 'error', code: e.code, message: e.message });
      else console.error('ws handler error', e);
    }
  }

  function attach(conn, user) {
    const old = byUser.get(user.id);
    if (old) {
      send(old, { t: 'error', code: 'other_device', message: 'Вход с другого устройства' });
      old.conn.close(1000);
    }
    const m = { conn, user: { id: user.id }, roomId: null, x: 0, y: 0 };
    byUser.set(user.id, m);
    conn.onmessage = (raw) => handle(m, raw);
    conn.onclose = () => {
      leave(m);
      if (byUser.get(user.id) === m) byUser.delete(user.id);
    };
    send(m, { t: 'hello', id: user.id });
  }

  return {
    attach,
    online: (roomId) => rooms.get(roomId)?.members.size ?? 0,
    isOnline: (userId) => byUser.has(userId),
    whereIs: (userId) => byUser.get(userId)?.roomId ?? null,
    /** Отправить сообщение конкретному игроку, если он онлайн. */
    sendTo(userId, obj) {
      const m = byUser.get(userId);
      if (!m) return false;
      send(m, obj);
      return true;
    },
    onlineTotal: () => byUser.size,
    /** Расстановка изменилась — обновить комнату у всех, кто внутри. */
    roomChanged(roomId) {
      const room = rooms.get(roomId);
      if (!room) return;
      const row = game.getRoom(roomId);
      const furn = JSON.parse(row.furniture);
      room.blocked = blockedSet(furn);
      room.seats = seatMap(furn);
      for (const m of room.members.values()) {
        if (m.sit && !room.seats.has(`${m.x},${m.y}`)) {
          m.sit = false;
          broadcast(room, { t: 'move', id: m.user.id, path: [], sit: false });
        }
      }
      broadcast(room, { t: 'room_update', room: game.roomRow(row, null, room.members.size) });
    },
    kick(userId) {
      const m = byUser.get(userId);
      if (!m) return false;
      send(m, { t: 'error', code: 'kicked', message: 'Вас выгнали' });
      leave(m);
      return true;
    },
    disconnect(userId) {
      byUser.get(userId)?.conn.close(1000);
    },
    announceRoom(roomId, text) {
      const room = rooms.get(roomId);
      if (room) broadcast(room, { t: 'system', text, announce: true });
    },
    announce(text) {
      for (const room of rooms.values()) broadcast(room, { t: 'system', text, announce: true });
    },
    heartbeat() {
      for (const m of byUser.values()) m.conn.ping();
    },
  };
}
