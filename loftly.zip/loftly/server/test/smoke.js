import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';
import { BOXES, POOLS, ITEMS } from '../src/catalog.js';

const { server, db } = createApp({ dbPath: ':memory:', adminUsername: 'boss' });
await new Promise((r) => server.listen(0, r));
const base = `http://127.0.0.1:${server.address().port}`;

async function call(method, path, body, token) {
  const res = await fetch(base + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return { status: res.status, json: await res.json() };
}
const ok = (r) => { assert.equal(r.status, 200, JSON.stringify(r.json)); return r.json; };

// --- регистрация / вход ---
let r = await call('POST', '/api/register', { username: 'a!', password: '123456' });
assert.equal(r.status, 400);
r = await call('POST', '/api/register', { username: 'alice', password: '123' });
assert.equal(r.status, 400);
const alice = ok(await call('POST', '/api/register', { username: 'alice', password: 'secret1', name: 'Алиса' }));
assert.equal(alice.profile.coins, 500);
assert.equal(alice.profile.role, 'player');
assert.equal((await call('POST', '/api/register', { username: 'ALICE', password: 'secret1' })).status, 409);
assert.equal((await call('POST', '/api/login', { username: 'alice', password: 'wrong' })).status, 401);
const alice2 = ok(await call('POST', '/api/login', { username: 'alice', password: 'secret1' }));
assert.equal((await call('GET', '/api/me')).status, 401);
assert.equal(ok(await call('GET', '/api/me', undefined, alice2.token)).name, 'Алиса');
const boss = ok(await call('POST', '/api/register', { username: 'boss', password: 'secret1' }));
assert.equal(boss.profile.role, 'admin');
const T = alice.token;

// --- бонус дня ---
let d = ok(await call('POST', '/api/daily', {}, T));
assert.equal(d.gained.coins, 100);
assert.equal((await call('POST', '/api/daily', {}, T)).status, 400);

// --- магазин / одежда ---
assert.equal((await call('POST', '/api/shop/buy', { itemId: 'nope' }, T)).status, 400);
let p = ok(await call('POST', '/api/shop/buy', { itemId: 'hat1' }, T));
assert.equal(p.coins, 600 - 100);
assert.equal((await call('POST', '/api/shop/buy', { itemId: 'hat1' }, T)).status, 400);
assert.equal((await call('POST', '/api/shop/buy', { itemId: 'hat2' }, T)).json.error, 'no_gems');
assert.equal((await call('POST', '/api/equip', { slot: 'hat', itemId: 'hat4' }, T)).json.error, 'not_owned');
assert.equal(ok(await call('POST', '/api/equip', { slot: 'hat', itemId: 'hat1' }, T)).equip.hat, 'hat1');
assert.equal(ok(await call('POST', '/api/equip', { slot: 'hat', itemId: null }, T)).equip.hat, null);
assert.equal((await call('POST', '/api/equip', { slot: 'top', itemId: 'hat1' }, T)).status, 400);

// --- лотерея ---
const info = ok(await call('GET', '/api/lottery', undefined, T));
assert.equal(info.boxes.basic.cost.coins, 100);
assert.equal(info.boxes.basic.odds.legendary, 0.5);
assert.equal((await call('POST', '/api/lottery/roll', { box: 'nope', count: 1 }, T)).status, 400);
assert.equal((await call('POST', '/api/lottery/roll', { box: 'basic', count: 5 }, T)).status, 400);
const before = ok(await call('GET', '/api/me', undefined, T));
const one = ok(await call('POST', '/api/lottery/roll', { box: 'basic', count: 1 }, T));
assert.equal(one.results.length, 1);
const res0 = one.results[0];
assert.ok(ITEMS[res0.itemId]);
assert.ok(POOLS[res0.rarity].includes(res0.itemId));
assert.equal(one.profile.coins, before.coins - 100 + res0.refund.coins);
db.prepare('UPDATE users SET coins = 5000 WHERE username = ?').run('alice');
const ten = ok(await call('POST', '/api/lottery/roll', { box: 'basic', count: 10 }, T));
assert.equal(ten.results.length, 10);
assert.ok(ten.results.some((x) => x.rarity !== 'common'), 'гарантия редкого раз в 10 круток');
// награда попала в инвентарь
for (const x of ten.results) {
  if (x.slot === 'furn') assert.ok((ten.profile.furniture[x.itemId.slice(5)] ?? 0) >= 1);
  else assert.ok(ten.profile.owned.includes(x.itemId));
}
// нельзя уйти в минус
const poor = ok(await call('POST', '/api/register', { username: 'poor', password: 'secret1' }));
db.prepare('UPDATE users SET coins = 99 WHERE username = ?').run('poor');
assert.equal((await call('POST', '/api/lottery/roll', { box: 'basic', count: 1 }, poor.token)).json.error, 'no_coins');
assert.equal(ok(await call('GET', '/api/me', undefined, poor.token)).coins, 99);
assert.equal((await call('POST', '/api/lottery/roll', { box: 'premium', count: 10 }, poor.token)).json.error, 'no_gems');

// статистика: 3000 круток обычной капсулы близки к заявленным шансам (с учётом гарантий)
{
  const { createGame } = await import('../src/game.js');
  const { openDb } = await import('../src/db.js');
  const sdb = openDb(':memory:');
  const g = createGame(sdb);
  const u = g.register({ username: 'stat', password: 'secret1' }).profile;
  const counts = { common: 0, rare: 0, epic: 0, legendary: 0 };
  for (let i = 0; i < 300; i++) {
    sdb.prepare('UPDATE users SET coins = 100000, gems = 1000 WHERE id = ?').run(u.id);
    for (const x of g.roll(u.id, 'basic', 10).results) counts[x.rarity]++;
  }
  console.log('распределение за 3000 круток:', counts);
  assert.ok(counts.common > 1800 && counts.common < 2500, 'common');
  assert.ok(counts.legendary > 0 && counts.legendary < 120, 'legendary');
  // премиум: обычных нет вообще
  let pc = 0;
  for (let i = 0; i < 20; i++) for (const x of g.roll(u.id, 'premium', 10).results) if (x.rarity === 'common') pc++;
  assert.equal(pc, 0);
}

// --- комнаты ---
const rm = ok(await call('POST', '/api/rooms', { name: 'Моя комната' }, T));
assert.equal(rm.profile.coins, ok(await call('GET', '/api/me', undefined, T)).coins); // первая бесплатна
const roomId = rm.room.id;
let lay = await call('PUT', `/api/rooms/${roomId}/layout`, { items: [{ kind: 'sofa', x: 0, y: 0 }, { kind: 'lamp', x: 3, y: 3 }] }, T);
assert.equal(lay.status, 200, JSON.stringify(lay.json));
assert.equal((await call('PUT', `/api/rooms/${roomId}/layout`, { items: [{ kind: 'sofa', x: 7, y: 0 }] }, T)).json.error, 'out_of_room');
assert.equal((await call('PUT', `/api/rooms/${roomId}/layout`, { items: [{ kind: 'sofa', x: 0, y: 0 }, { kind: 'lamp', x: 1, y: 0 }] }, T)).json.error, 'overlap');
assert.equal((await call('PUT', `/api/rooms/${roomId}/layout`, { items: [{ kind: 'bed', x: 0, y: 0 }, { kind: 'bed', x: 4, y: 4 }, { kind: 'bed', x: 6, y: 0 }] }, T)).status, 400);
assert.equal((await call('PUT', `/api/rooms/${roomId}/layout`, { items: [] }, poor.token)).status, 403);
assert.equal(ok(await call('POST', `/api/rooms/${roomId}/like`, {}, poor.token)).likes, 1);
assert.equal(ok(await call('POST', `/api/rooms/${roomId}/like`, {}, poor.token)).likes, 0);
assert.equal((await call('POST', `/api/rooms/${roomId}/theme`, { theme: 4 }, T)).json.error, 'theme_locked');
assert.equal(ok(await call('GET', '/api/rooms', undefined, T)).rooms.length, 1);

// --- студия одежды ---
{
  const { deflateSync, crc32 } = await import('node:zlib');
  const chunk = (type, data) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const td = Buffer.concat([Buffer.from(type, 'ascii'), data]);
    const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
    return Buffer.concat([len, td, crc]);
  };
  const makePng = (w, h) => {
    const ihdr = Buffer.alloc(13);
    ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 6;
    const raw = Buffer.alloc((w * 4 + 1) * h, 0);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const o = y * (w * 4 + 1) + 1 + x * 4; raw[o] = 200; raw[o + 3] = 255; }
    return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]).toString('base64');
  };
  const good = makePng(60, 64);

  // только админ создаёт вещи
  assert.equal((await call('POST', '/api/admin/clothes', { slot: 'top', name: 'X', price: 10, png: good }, T)).status, 403);
  // проверки слота, размера, формата, цены
  assert.equal((await call('POST', '/api/admin/clothes', { slot: 'cape', name: 'X', price: 10, png: good }, boss.token)).json.error, 'bad_slot');
  assert.equal((await call('POST', '/api/admin/clothes', { slot: 'bottom', name: 'X', price: 10, png: good }, boss.token)).json.error, 'bad_size');
  assert.equal((await call('POST', '/api/admin/clothes', { slot: 'top', name: 'X', price: 10, png: Buffer.from('hello world, not a png at all, really not').toString('base64') }, boss.token)).json.error, 'bad_png');
  assert.equal((await call('POST', '/api/admin/clothes', { slot: 'top', name: 'X', price: -5, png: good }, boss.token)).json.error, 'bad_price');
  assert.equal((await call('POST', '/api/admin/clothes', { slot: 'top', name: '  ', price: 5, png: good }, boss.token)).json.error, 'bad_name');

  const made = ok(await call('POST', '/api/admin/clothes', { slot: 'top', name: 'Моя футболка', price: 120, png: good }, boss.token));
  const cid = made.cloth.id;
  assert.match(cid, /^c\d+$/);
  assert.ok(made.profile.owned.includes(cid), 'автор получает вещь');

  // игрок видит каталог без картинок и скачивает PNG отдельно
  const list = ok(await call('GET', '/api/clothes', undefined, T));
  assert.equal(list.clothes.length, 1);
  assert.equal(list.clothes[0].png, undefined);
  assert.equal(list.spec.hat.w, 120);
  assert.equal(ok(await call('GET', `/api/clothes/${cid}`, undefined, T)).png, good);
  assert.equal((await call('GET', '/api/clothes/c99999', undefined, T)).status, 404);
  assert.equal((await call('GET', '/api/clothes/top0', undefined, T)).status, 404);

  // покупка: списывает монеты, нельзя дважды, надевание только купленного и в свой слот
  assert.equal((await call('POST', '/api/equip', { slot: 'top', itemId: cid }, T)).json.error, 'not_owned');
  const coinsBefore = ok(await call('GET', '/api/me', undefined, T)).coins;
  const bought = ok(await call('POST', '/api/shop/buy', { itemId: cid }, T));
  assert.equal(bought.coins, coinsBefore - 120);
  assert.equal((await call('POST', '/api/shop/buy', { itemId: cid }, T)).json.error, 'already_owned');
  assert.equal((await call('POST', '/api/equip', { slot: 'bottom', itemId: cid }, T)).status, 400);
  assert.equal(ok(await call('POST', '/api/equip', { slot: 'top', itemId: cid }, T)).equip.top, cid);

  // снятая с продажи вещь не покупается, но у владельцев остаётся и скачивается
  ok(await call('POST', `/api/admin/clothes/${cid}`, { active: false, name: 'Старая футболка' }, boss.token));
  assert.equal(ok(await call('GET', '/api/clothes', undefined, T)).clothes.length, 0);
  assert.equal((await call('POST', '/api/shop/buy', { itemId: cid }, boss.token)).json.error, 'not_for_sale');
  assert.equal(ok(await call('GET', `/api/clothes/${cid}`, undefined, T)).png, good);
  assert.equal(ok(await call('GET', '/api/me', undefined, T)).equip.top, cid);
  assert.equal(ok(await call('GET', '/api/admin/clothes', undefined, boss.token)).clothes.length, 1);
  assert.equal((await call('GET', '/api/admin/clothes', undefined, T)).status, 403);
  // встроенная одежда по-прежнему заменяет вещь из студии
  assert.equal(ok(await call('POST', '/api/equip', { slot: 'top', itemId: 'top0' }, T)).equip.top, 'top0');
}

// --- WebSocket ---
function openWs(token) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(`ws://127.0.0.1:${server.address().port}/ws?token=${token}`);
    const inbox = [];
    const waiters = [];
    ws.onmessage = (e) => {
      const m = JSON.parse(e.data);
      const i = waiters.findIndex((w) => w.pred(m));
      if (i >= 0) waiters.splice(i, 1)[0].res(m); else inbox.push(m);
    };
    ws.onerror = reject;
    ws.onopen = () => resolve({
      send: (o) => ws.send(JSON.stringify(o)),
      close: () => ws.close(),
      next: (pred) => new Promise((res, rej) => {
        const i = inbox.findIndex(pred);
        if (i >= 0) return res(inbox.splice(i, 1)[0]);
        const t = setTimeout(() => rej(new Error('ws timeout')), 3000);
        waiters.push({ pred, res: (m) => { clearTimeout(t); res(m); } });
      }),
    });
  });
}
await assert.rejects(openWs('bad-token-xxxxxxxxxxxxxxxxxxxxxx'));
const wa = await openWs(T);
const wp = await openWs(poor.token);
await wa.next((m) => m.t === 'hello');
await wp.next((m) => m.t === 'hello');
wa.send({ t: 'join', room: roomId });
const joined = await wa.next((m) => m.t === 'joined');
assert.equal(joined.players.length, 1);
wp.send({ t: 'join', room: roomId });
await wp.next((m) => m.t === 'joined');
const pj = await wa.next((m) => m.t === 'player_join');
assert.equal(pj.player.name, 'poor');
wa.send({ t: 'move', x: 5, y: 5 });
const mv = await wp.next((m) => m.t === 'move');
assert.deepEqual(mv.path.at(-1), [5, 5]);
wa.send({ t: 'chat', text: 'привет, дурак' });
const ch = await wp.next((m) => m.t === 'chat');
assert.equal(ch.text, 'привет, ***');
// мут
const poorId = poor.profile.id;
assert.equal((await call('POST', `/api/admin/users/${poorId}`, { muted: true }, T)).status, 403); // игрок не модератор
ok(await call('POST', `/api/admin/users/${poorId}`, { muted: true }, boss.token));
wp.send({ t: 'chat', text: 'я замучен' });
assert.equal((await wp.next((m) => m.t === 'error')).code, 'muted');
// бан отключает и закрывает сессию
ok(await call('POST', `/api/admin/users/${poorId}`, { banned: true }, boss.token));
assert.equal((await call('GET', '/api/me', undefined, poor.token)).status, 401);
assert.equal((await call('POST', '/api/login', { username: 'poor', password: 'secret1' })).status, 403);
wa.close();
wp.close();

// --- личные сообщения ---
const bossId = boss.profile.id;
const aliceId = alice.profile.id;
assert.equal((await call('POST', `/api/dm/${aliceId}`, { text: 'сам себе' }, T)).status, 400);
assert.equal((await call('POST', '/api/dm/99999', { text: 'привет' }, T)).status, 404);
assert.equal((await call('POST', `/api/dm/${bossId}`, { text: '   ' }, T)).status, 400);
const dm1 = ok(await call('POST', `/api/dm/${bossId}`, { text: 'привет, дурак' }, T));
assert.equal(dm1.message.text, 'привет, ***');
ok(await call('POST', `/api/dm/${aliceId}`, { text: 'здравствуй' }, boss.token));
let th = ok(await call('GET', '/api/dm', undefined, T));
assert.equal(th.unread, 1);
assert.equal(th.threads[0].user.id, bossId);
assert.equal(th.threads[0].last.text, 'здравствуй');
const chat = ok(await call('GET', `/api/dm/${bossId}`, undefined, T));
assert.deepEqual(chat.messages.map((m) => m.text), ['привет, ***', 'здравствуй']);
assert.equal(ok(await call('GET', '/api/dm', undefined, T)).unread, 0);
assert.equal(ok(await call('GET', `/api/dm/${bossId}?after=${chat.messages[0].id}`, undefined, T)).messages.length, 1);

// --- розыгрыши (гребы) владельца комнаты ---
const gr = ok(await call('POST', '/api/rooms', { name: 'Грабы', theme: 0, isPublic: true }, boss.token));
const grabRoom = gr.room?.id ?? gr.id;
const coinsOf = async (tok) => ok(await call('GET', '/api/me', undefined, tok)).coins;
const bossBefore = await coinsOf(boss.token);
assert.equal((await call('POST', `/api/rooms/${grabRoom}/grab`, { prize: 100 }, T)).status, 403);
assert.equal((await call('POST', `/api/rooms/${grabRoom}/grab`, { prize: 5 }, boss.token)).json.error, 'bad_prize');
assert.equal((await call('POST', `/api/rooms/${grabRoom}/grab`, { prize: 10000 }, boss.token)).json.error, 'no_coins');
const g1 = ok(await call('POST', `/api/rooms/${grabRoom}/grab`, { prize: 100, ticket: 20, minutes: 2 }, boss.token)).grab;
assert.equal(await coinsOf(boss.token), bossBefore - 100);
assert.equal((await call('POST', `/api/rooms/${grabRoom}/grab`, { prize: 100 }, boss.token)).json.error, 'grab_active');
assert.equal((await call('POST', `/api/grabs/${g1.id}/join`, {}, boss.token)).json.error, 'own_grab');
const aBefore = await coinsOf(T);
ok(await call('POST', `/api/grabs/${g1.id}/join`, {}, T));
assert.equal((await call('POST', `/api/grabs/${g1.id}/join`, {}, T)).json.error, 'already_in');
assert.equal(await coinsOf(T), aBefore - 20);
assert.equal(await coinsOf(boss.token), bossBefore - 100 + 20);
assert.equal(ok(await call('GET', `/api/rooms/${grabRoom}/grab`, undefined, T)).grab.entries, 1);
db.prepare('UPDATE grabs SET ends_ms = 0').run();
assert.equal(ok(await call('GET', `/api/rooms/${grabRoom}/grab`, undefined, T)).grab, null);
assert.equal(await coinsOf(T), aBefore - 20 + 100);
assert.equal((await call('POST', `/api/grabs/${g1.id}/join`, {}, T)).json.error, 'grab_over');
// без участников приз возвращается владельцу
const bossMid = await coinsOf(boss.token);
ok(await call('POST', `/api/rooms/${grabRoom}/grab`, { prize: 50 }, boss.token));
db.prepare('UPDATE grabs SET ends_ms = 0').run();
ok(await call('GET', `/api/rooms/${grabRoom}/grab`, undefined, T));
assert.equal(await coinsOf(boss.token), bossMid);

// --- система вещей: редкость, «нельзя купить», ивенты ---
{
  const hdr = Buffer.alloc(33);
  Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]).copy(hdr, 0);
  hdr.writeUInt32BE(13, 8); hdr.write('IHDR', 12, 'ascii'); hdr.writeUInt32BE(60, 16); hdr.writeUInt32BE(64, 20);
  const png = hdr.toString('base64').padEnd(60, 'A');
  const mk = async (body) => call('POST', '/api/admin/clothes', { slot: 'top', price: 0, png, ...body }, boss.token);
  assert.equal((await mk({ name: 'X', rarity: 'mythic' })).json.error, 'bad_rarity');
  assert.equal((await mk({ name: 'X', obtain: 'gift' })).json.error, 'bad_obtain');
  const lot = ok(await mk({ name: 'Капсульная куртка', rarity: 'epic', obtain: 'lottery' })).cloth;
  const evt = ok(await mk({ name: 'Приз ивента', rarity: 'legendary', obtain: 'event' })).cloth;
  assert.equal(lot.rarity, 'epic');
  assert.equal(evt.obtainName, 'Ивенты');
  // купить нельзя
  assert.equal((await call('POST', '/api/shop/buy', { itemId: lot.id }, T)).json.error, 'not_for_sale');
  assert.equal((await call('POST', '/api/shop/buy', { itemId: evt.id }, T)).json.error, 'not_for_sale');
  // вещь появилась в пуле капсул (ивентовой там нет)
  const info = ok(await call('GET', '/api/lottery', undefined, T));
  assert.ok(info.pools.epic.items.some((i) => i.id === lot.id && i.exclusive));
  assert.ok(!Object.values(info.pools).some((p2) => p2.items.some((i) => i.id === evt.id)));
  // выкрутить можно
  ok(await call('POST', `/api/admin/users/${alice.profile.id}/grant`, { gems: 9000 }, boss.token));
  let got = false;
  for (let i = 0; i < 60 && !got; i++) {
    const r2 = ok(await call('POST', '/api/lottery/roll', { box: 'premium', count: 10 }, T));
    got = r2.results.some((x) => x.itemId === lot.id);
  }
  assert.ok(got, 'вещь из капсул не выпала');
  assert.ok(ok(await call('GET', '/api/me', undefined, T)).owned.includes(lot.id));
  // ивент: выдаёт только админ, повторно нельзя
  assert.equal((await call('POST', `/api/admin/users/${alice.profile.id}/award`, { itemId: evt.id }, T)).status, 403);
  assert.equal((await call('POST', `/api/admin/users/${alice.profile.id}/award`, { itemId: 'nope' }, boss.token)).json.error, 'no_item');
  const aw = ok(await call('POST', `/api/admin/users/${alice.profile.id}/award`, { itemId: evt.id, note: 'победа в ивенте' }, boss.token));
  assert.equal(aw.item.name, 'Приз ивента');
  assert.ok(ok(await call('GET', '/api/me', undefined, T)).owned.includes(evt.id));
  assert.equal((await call('POST', `/api/admin/users/${alice.profile.id}/award`, { itemId: evt.id }, boss.token)).json.error, 'already_owned');
  // встроенные вещи получили редкость
  assert.ok(info.pools.legendary.items.length >= 3);
}

console.log('ALL OK');
server.close();
process.exit(0);
