import 'package:flutter/material.dart';

/// Общая тема и готовые элементы интерфейса.
class Ui {
  static const Color bg0 = Color(0xFF120E28);
  static const Color bg1 = Color(0xFF231A4A);
  static const Color surface = Color(0xFF2B2255);
  static const Color surfaceHi = Color(0xFF3A2F6E);
  static const Color accent = Color(0xFFFF5FA2);
  static const Color violet = Color(0xFF8E6BFF);
  static const Color cyan = Color(0xFF3DD9EB);
  static const Color gold = Color(0xFFFFC93C);
  static const Color green = Color(0xFF45D68B);
  static const Color dim = Color(0xFFB9B0E0);

  static const LinearGradient brand = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [violet, accent],
  );

  static const LinearGradient goldGrad = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Color(0xFFFFD95E), Color(0xFFFFA726)],
  );

  static const LinearGradient background = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [bg1, bg0],
  );

  static Color a(Color c, double alpha) => c.withAlpha((255 * alpha).round());

  static ThemeData theme() {
    final base = ColorScheme.fromSeed(
      seedColor: violet,
      brightness: Brightness.dark,
    );
    final scheme = base.copyWith(
      primary: violet,
      onPrimary: Colors.white,
      secondary: accent,
      tertiary: cyan,
      surface: bg0,
      onSurface: Colors.white,
      surfaceContainerLowest: bg0,
      surfaceContainerLow: surface,
      surfaceContainer: surface,
      surfaceContainerHigh: surfaceHi,
      surfaceContainerHighest: surfaceHi,
      primaryContainer: const Color(0xFF4A3A9A),
      onPrimaryContainer: Colors.white,
      secondaryContainer: const Color(0xFF5A2D55),
      onSecondaryContainer: Colors.white,
      tertiaryContainer: const Color(0xFF16505A),
      onTertiaryContainer: Colors.white,
      outline: const Color(0xFF6C60A8),
      outlineVariant: const Color(0xFF42387A),
    );
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: scheme,
      scaffoldBackgroundColor: bg0,
      canvasColor: bg0,
      visualDensity: VisualDensity.standard,
      splashFactory: InkRipple.splashFactory,
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: violet,
          foregroundColor: Colors.white,
          minimumSize: const Size(64, 46),
          padding: const EdgeInsets.symmetric(horizontal: 20),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: const Color(0xFFD7CCFF),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: const TextStyle(fontWeight: FontWeight.w600),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: Colors.white,
          side: const BorderSide(color: Color(0xFF6C60A8)),
          minimumSize: const Size(64, 46),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: a(Colors.white, .08),
        selectedColor: violet,
        disabledColor: a(Colors.white, .05),
        side: BorderSide(color: a(Colors.white, .14)),
        labelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        secondaryLabelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        checkmarkColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(horizontal: 6),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: Colors.transparent,
        indicatorColor: Colors.transparent,
        elevation: 0,
        height: 66,
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        labelTextStyle: WidgetStateProperty.resolveWith((s) => TextStyle(
              fontSize: 11,
              fontWeight: s.contains(WidgetState.selected) ? FontWeight.w800 : FontWeight.w500,
              color: s.contains(WidgetState.selected) ? Colors.white : dim,
            )),
        iconTheme: WidgetStateProperty.resolveWith((s) => IconThemeData(
              size: 26,
              color: s.contains(WidgetState.selected) ? accent : dim,
            )),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: surfaceHi,
        contentTextStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: Color(0xFF241C4D),
        modalBackgroundColor: Color(0xFF241C4D),
        showDragHandle: true,
        dragHandleColor: Color(0xFF6C60A8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
      ),
      dividerTheme: DividerThemeData(color: a(Colors.white, .1), space: 1),
      listTileTheme: const ListTileThemeData(iconColor: dim),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith(
            (s) => s.contains(WidgetState.selected) ? Colors.white : dim),
        trackColor: WidgetStateProperty.resolveWith(
            (s) => s.contains(WidgetState.selected) ? accent : a(Colors.white, .12)),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(color: accent),
    );
  }

  /// Поле ввода в общем стиле.
  static InputDecoration input(String? label, {String? hint, String? helper, Widget? prefix}) {
    OutlineInputBorder border(Color c, [double w = 1]) => OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: c, width: w),
        );
    return InputDecoration(
      labelText: label,
      hintText: hint,
      helperText: helper,
      prefixIcon: prefix,
      filled: true,
      fillColor: a(Colors.white, .07),
      labelStyle: const TextStyle(color: dim),
      hintStyle: TextStyle(color: a(Colors.white, .4)),
      helperStyle: TextStyle(color: a(Colors.white, .5)),
      enabledBorder: border(a(Colors.white, .14)),
      focusedBorder: border(accent, 1.6),
      border: border(a(Colors.white, .14)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    );
  }
}

/// Фон с градиентом и мягкими пятнами света.
class GameBackground extends StatelessWidget {
  final Widget child;
  const GameBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(gradient: Ui.background),
      child: Stack(
        children: [
          Positioned(
            top: -120,
            right: -90,
            child: _Glow(size: 320, color: Ui.a(Ui.violet, .30)),
          ),
          Positioned(
            bottom: 120,
            left: -140,
            child: _Glow(size: 320, color: Ui.a(Ui.accent, .16)),
          ),
          Positioned.fill(child: child),
        ],
      ),
    );
  }
}

class _Glow extends StatelessWidget {
  final double size;
  final Color color;
  const _Glow({required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [color, color.withAlpha(0)]),
        ),
      ),
    );
  }
}

/// Полупрозрачная «стеклянная» карточка.
class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final double radius;
  final Gradient? gradient;
  final Color? borderColor;

  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.onTap,
    this.radius = 22,
    this.gradient,
    this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    final shape = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(radius),
      side: BorderSide(color: borderColor ?? Ui.a(Colors.white, .12)),
    );
    return Material(
      color: gradient == null ? Ui.a(Colors.white, .07) : Colors.transparent,
      shape: shape,
      clipBehavior: Clip.antiAlias,
      child: Ink(
        decoration: gradient == null ? null : BoxDecoration(gradient: gradient),
        child: InkWell(
          onTap: onTap,
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}

/// Кнопка с градиентом (основное действие).
class GradientButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final Gradient gradient;
  final double height;
  final bool expand;

  const GradientButton({
    super.key,
    required this.label,
    this.icon,
    this.onPressed,
    this.gradient = Ui.brand,
    this.height = 50,
    this.expand = true,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null;
    final fg = gradient == Ui.goldGrad ? const Color(0xFF3A2500) : Colors.white;
    return Opacity(
      opacity: enabled ? 1 : .45,
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(height / 2.6),
        child: Ink(
          height: height,
          decoration: BoxDecoration(
            gradient: gradient,
            borderRadius: BorderRadius.circular(height / 2.6),
            boxShadow: enabled
                ? [BoxShadow(color: Ui.a(Ui.accent, .35), blurRadius: 14, offset: const Offset(0, 5))]
                : null,
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(height / 2.6),
            onTap: onPressed,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Row(
                mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (icon != null) ...[
                    Icon(icon, color: fg, size: 20),
                    const SizedBox(width: 8),
                  ],
                  Flexible(
                    child: Text(
                      label,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: fg, fontWeight: FontWeight.w800, fontSize: 15),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Плашка с валютой.
class CurrencyPill extends StatelessWidget {
  final String emoji;
  final int value;
  final VoidCallback? onTap;
  const CurrencyPill({super.key, required this.emoji, required this.value, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Ui.a(Colors.black, .28),
      shape: StadiumBorder(side: BorderSide(color: Ui.a(Colors.white, .14))),
      child: InkWell(
        customBorder: const StadiumBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 5, 12, 5),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(emoji, style: const TextStyle(fontSize: 16)),
              const SizedBox(width: 5),
              Text(
                '$value',
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Заголовок раздела.
class SectionTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const SectionTitle(this.text, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 18, 4, 8),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 16,
            decoration: BoxDecoration(
              gradient: Ui.brand,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

/// Пустое состояние списка.
class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? text;
  const EmptyState({super.key, required this.icon, required this.title, this.text});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 84,
              height: 84,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Ui.a(Colors.white, .07),
                border: Border.all(color: Ui.a(Colors.white, .12)),
              ),
              child: Icon(icon, size: 38, color: Ui.dim),
            ),
            const SizedBox(height: 16),
            Text(title,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            if (text != null) ...[
              const SizedBox(height: 6),
              Text(text!, textAlign: TextAlign.center, style: const TextStyle(color: Ui.dim)),
            ],
          ],
        ),
      ),
    );
  }
}

/// Маленькая цветная метка («Админ», «Закрыта» и т.п.).
class Tag extends StatelessWidget {
  final String text;
  final Color color;
  final IconData? icon;
  const Tag(this.text, {super.key, this.color = Ui.violet, this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Ui.a(color, .22),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Ui.a(color, .6)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[Icon(icon, size: 12, color: Colors.white), const SizedBox(width: 3)],
          Text(text, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

/// Круглая кнопка поверх сцены комнаты.
class RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onPressed;
  final String? tooltip;
  final Color? color;
  final Widget? badge;

  const RoundIconButton({
    super.key,
    required this.icon,
    this.onPressed,
    this.tooltip,
    this.color,
    this.badge,
  });

  @override
  Widget build(BuildContext context) {
    final btn = Material(
      color: Ui.a(Colors.black, .38),
      shape: CircleBorder(side: BorderSide(color: Ui.a(Colors.white, .16))),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onPressed,
        child: SizedBox(
          width: 44,
          height: 44,
          child: Icon(icon, size: 22, color: color ?? Colors.white),
        ),
      ),
    );
    final w = badge == null
        ? btn
        : Stack(clipBehavior: Clip.none, children: [btn, Positioned(right: -2, top: -2, child: badge!)]);
    return tooltip == null ? w : Tooltip(message: tooltip!, child: w);
  }
}
