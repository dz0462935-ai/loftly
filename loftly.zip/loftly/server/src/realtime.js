import { FURN, ROOM_GRID } from './catalog.js';

const MAX_PER_ROOM = 30;
const EMOJIS = new Set(['👋', '😀', '😂', '❤️', '🎉', '😎', '💃', '😮', '😢', '👍']);

function blockedSet(furniture) {
  const s = new Set();
  for (const f of furniture) {
    const spec = FURN[f.kind];
    if (!spec || spec.walkable) continue;
    for (let dx = 0; dx < spec.w; dx++) for (let dy = 0; dy < spec.d; dy++) s.add(`${f.x + dx},${f.y + dy}`);
  }
  return s;
}

/** Кратчайший путь по сетке (BFS, 4 направления). Возвращает клетки без стартовой. */
export function findPath(blocked, from, to) {
  const key = (x, y) => `${x},${y}`;
  if (blocked.has(key(to.x, to.y))) return null;
  const prev = new Map([[key(from.x, from.y), null]]);
  const queue = [[from.x, from.y]];
  for (let i = 0; i < queue.length; i++) {
    const [x, y] = queue[i];
    if (x === to.x && y === to.y) break;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + dx;
      const ny = y + dy;
      const k = key(nx, ny);
      if (nx < 0 || ny < 0 || nx >= ROOM_GRID || ny >= ROOM_GRID || prev.has(k) || blocked.has(k)) continue;
      prev.set(k, key(x, y));
      queue.push([nx, ny]);
    }
  }
  if (!prev.has(key(to.x, to.y))) return null;
  const path = [];
  for (let k = key(to.x, to.y); k && k !== key(from.x, from.y); k = prev.get(k)) {
    const [x, y] = k.split(',').map(Number);
    path.push([x, y]);
  }
  return path.reverse();
}

export function createHub(game) {
  const rooms = new Map(); // roomId -> { members: Map<userId, member>, blocked:Set }
  const byUser = new Map(); // userId -> member

  const send = (m, obj) => m.conn.send(JSON.stringify(obj));
  const broadcast = (room, obj, exceptId) => {
    const s = JSON.stringify(obj);
    for (const m of room.members.values()) if (m.user.id !== exceptId) m.conn.send(s);
  };
  const snapshot = (m) => ({ ...game.publicUser(game.userById(m.user.id)), x: m.x, y: m.y });

  function leave(m) {
    if (!m.roomId) return;
    const roomId = m.roomId;
    const room = rooms.get(roomId);
    m.roomId = null;
    if (!room) return;
    room.members.delete(m.user.id);
    broadcast(room, { t: 'player_leave', id: m.user.id });
    if (room.members.size === 0) rooms.delete(roomId);
  }

  function join(m, roomId) {
    const row = game.getRoom(roomId);
    const u = game.userById(m.user.id);
    if (row.closed && u.role !== 'admin') return send(m, { t: 'error', code: 'room_closed', message: 'Комната закрыта' });
    if (!row.is_public && row.owner_id !== u.id && u.role !== 'admin') {
      return send(m, { t: 'error', code: 'private_room', message: 'Комната приватная' });
    }
    leave(m);
    let room = rooms.get(roomId);
    if (!room) {
      room = { id: roomId, members: new Map(), blocked: new Set() };
      rooms.set(roomId, room);
    }
    if (room.members.size >= MAX_PER_ROOM) return send(m, { t: 'error', code: 'room_full', message: 'Комната заполнена' });
    room.blocked = blockedSet(JSON.parse(row.furniture));
    // Стартовая клетка: ближайшая свободная к центру нижнего края.
    const taken = new Set([...room.members.values()].map((o) => `${o.x},${o.y}`));
    let spawn = null;
    for (let r = 0; r < ROOM_GRID * 2 && !spawn; r++) {
      for (let x = 0; x < ROOM_GRID && !spawn; x++) {
        const y = ROOM_GRID - 1 - (r % ROOM_GRID);
        const k = `${x},${y}`;
        if (!room.blocked.has(k) && !taken.has(k)) spawn = { x, y };
      }
    }
    m.roomId = roomId;
    m.x = spawn ? spawn.x : 0;
    m.y = spawn ? spawn.y : 0;
    m.lastMove = 0;
    room.members.set(u.id, m);
    send(m, {
      t: 'joined', you: u.id, room: game.roomRow(row, u.id, room.members.size),
      players: [...room.members.values()].map(snapshot),
    });
    broadcast(room, { t: 'player_join', player: snapshot(m) }, u.id);
  }

  function handle(m, raw) {
    let msg;
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }
    if (!msg || typeof msg.t !== 'string') return;
    const nowMs = Date.now();
    // Общий лимит: не больше 20 сообщений в секунду.
    m.bucket = (m.bucket ?? 0) * Math.max(0, 1 - (nowMs - (m.bucketAt ?? nowMs)) / 1000) + 1;
    m.bucketAt = nowMs;
    if (m.bucket > 20) return;
    try {
      if (msg.t === 'join') return join(m, Number(msg.room));
      if (msg.t === 'leave') return leave(m);
      const room = m.roomId && rooms.get(m.roomId);
      if (!room) return;
      if (msg.t === 'move') {
        const x = Number(msg.x);
        const y = Number(msg.y);
        if (!Number.isInteger(x) || !Number.isInteger(y) || x < 0 || y < 0 || x >= ROOM_GRID || y >= ROOM_GRID) return;
        if (nowMs - m.lastMove < 150) return;
        m.lastMove = nowMs;
        const path = findPath(room.blocked, { x: m.x, y: m.y }, { x, y });
        if (!path || path.length === 0) return;
        const end = path[path.length - 1];
        m.x = end[0];
        m.y = end[1];
        broadcast(room, { t: 'move', id: m.user.id, path });
      } else if (msg.t === 'chat') {
        const u = game.userById(m.user.id);
        if (u.muted) return send(m, { t: 'error', code: 'muted', message: 'Вам запрещено писать в чат' });
        if (nowMs - (m.lastChat ?? 0) < 700) return send(m, { t: 'error', code: 'slow_down', message: 'Не так быстро' });
        const text = game.filterChat(msg.text);
        if (!text) return;
        m.lastChat = nowMs;
        broadcast(room, { t: 'chat', id: u.id, name: u.name, text });
      } else if (msg.t === 'emote') {
        if (!EMOJIS.has(msg.emoji)) return;
        broadcast(room, { t: 'emote', id: m.user.id, emoji: msg.emoji });
      }
    } catch (e) {
      if (e.status) send(m, { t: 'error', code: e.code, message: e.message });
      else console.error('ws handler error', e);
    }
  }

  function attach(conn, user) {
    const old = byUser.get(user.id);
    if (old) {
      send(old, { t: 'error', code: 'other_device', message: 'Вход с другого устройства' });
      old.conn.close(1000);
    }
    const m = { conn, user: { id: user.id }, roomId: null, x: 0, y: 0 };
    byUser.set(user.id, m);
    conn.onmessage = (raw) => handle(m, raw);
    conn.onclose = () => {
      leave(m);
      if (byUser.get(user.id) === m) byUser.delete(user.id);
    };
    send(m, { t: 'hello', id: user.id });
  }

  return {
    attach,
    online: (roomId) => rooms.get(roomId)?.members.size ?? 0,
    onlineTotal: () => byUser.size,
    /** Расстановка изменилась — обновить комнату у всех, кто внутри. */
    roomChanged(roomId) {
      const room = rooms.get(roomId);
      if (!room) return;
      const row = game.getRoom(roomId);
      room.blocked = blockedSet(JSON.parse(row.furniture));
      broadcast(room, { t: 'room_update', room: game.roomRow(row, null, room.members.size) });
    },
    /** Отправить сообщение одному игроку, если он на связи. */
    notify(userId, obj) {
      const m = byUser.get(userId);
      if (m) send(m, obj);
    },
    /** Системное сообщение всем в комнате. */
    roomMessage(roomId, text) {
      const room = rooms.get(roomId);
      if (room) broadcast(room, { t: 'system', text });
    },
    kick(userId) {
      const m = byUser.get(userId);
      if (!m) return false;
      send(m, { t: 'error', code: 'kicked', message: 'Вас выгнали' });
      leave(m);
      return true;
    },
    disconnect(userId) {
      byUser.get(userId)?.conn.close(1000);
    },
    announce(text) {
      for (const room of rooms.values()) broadcast(room, { t: 'system', text, announce: true });
    },
    heartbeat() {
      for (const m of byUser.values()) m.conn.ping();
    },
  };
}
