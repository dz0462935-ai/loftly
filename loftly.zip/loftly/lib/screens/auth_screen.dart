import 'package:flutter/material.dart';

import '../api.dart';

class AuthScreen extends StatefulWidget {
  final String initialUrl;
  final void Function(ApiClient api, Map<String, dynamic> profile) onLoggedIn;
  final VoidCallback onDemo;

  const AuthScreen({
    super.key,
    required this.initialUrl,
    required this.onLoggedIn,
    required this.onDemo,
  });

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  late final TextEditingController _url = TextEditingController(text: widget.initialUrl);
  final TextEditingController _user = TextEditingController();
  final TextEditingController _pass = TextEditingController();
  final TextEditingController _name = TextEditingController();
  bool _register = false;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _url.dispose();
    _user.dispose();
    _pass.dispose();
    _name.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final url = normalizeServerUrl(_url.text);
    if (url.isEmpty) {
      setState(() => _error = 'Укажите адрес сервера');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final api = ApiClient(url);
      final r = _register
          ? await api.register(_user.text.trim(), _pass.text, _name.text.trim())
          : await api.login(_user.text.trim(), _pass.text);
      final token = r['token'] as String;
      api.token = token;
      await saveSession(url, token);
      if (!mounted) return;
      widget.onLoggedIn(api, r['profile'] as Map<String, dynamic>);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text('Loftly',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.displaySmall),
                  const SizedBox(height: 4),
                  Text(_register ? 'Создайте аккаунт' : 'Войдите в аккаунт',
                      textAlign: TextAlign.center),
                  const SizedBox(height: 24),
                  TextField(
                    controller: _url,
                    keyboardType: TextInputType.url,
                    autocorrect: false,
                    decoration: const InputDecoration(
                      labelText: 'Адрес сервера',
                      hintText: 'https://loftly.onrender.com',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _user,
                    autocorrect: false,
                    decoration: const InputDecoration(
                      labelText: 'Логин',
                      helperText: 'Латиница, цифры и _, 3–20 символов',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (_register) ...[
                    TextField(
                      controller: _name,
                      decoration: const InputDecoration(
                        labelText: 'Имя в игре',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],
                  TextField(
                    controller: _pass,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Пароль',
                      helperText: 'От 6 символов',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (_) => _busy ? null : _submit(),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                  ],
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: _busy ? null : _submit,
                    child: _busy
                        ? const SizedBox(
                            width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                        : Text(_register ? 'Зарегистрироваться' : 'Войти'),
                  ),
                  TextButton(
                    onPressed: _busy ? null : () => setState(() => _register = !_register),
                    child: Text(_register ? 'Уже есть аккаунт? Войти' : 'Нет аккаунта? Регистрация'),
                  ),
                  const Divider(),
                  TextButton(
                    onPressed: _busy ? null : widget.onDemo,
                    child: const Text('Демо без аккаунта (офлайн)'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
