import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import 'room_screen.dart';

class RoomsTab extends StatelessWidget {
  const RoomsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final rooms = [...store.rooms]
      ..sort((a, b) => store.onlineCount(b.id).compareTo(store.onlineCount(a.id)));
    return Scaffold(
      body: rooms.isEmpty
          ? const Center(child: Text('Пока нет комнат. Создайте первую!'))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 88),
              itemCount: rooms.length,
              itemBuilder: (context, i) => _RoomCard(room: rooms[i]),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showCreateSheet(context),
        icon: const Icon(Icons.add),
        label: const Text('Создать комнату'),
      ),
    );
  }

  void _showCreateSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => const _CreateRoomSheet(),
    );
  }
}

class _RoomCard extends StatelessWidget {
  final Room room;
  const _RoomCard({required this.room});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final owner = store.users[room.ownerId]!;
    final online = store.onlineCount(room.id);
    final mine = room.ownerId == 'me';
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => RoomScreen(roomId: room.id)),
        ),
        child: Row(
          children: [
            Container(
              width: 84,
              height: 84,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [room.t.wall, room.t.wall, room.t.floorA, room.t.floorA],
                  stops: const [0, .5, .5, 1],
                ),
              ),
              child: Icon(
                room.closed ? Icons.block : (room.isPublic ? Icons.weekend : Icons.lock),
                color: Colors.white,
                size: 36,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(room.name,
                        style: Theme.of(context).textTheme.titleMedium,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 4),
                    Text(mine ? 'Ваша комната' : 'Хозяин: ${owner.name}',
                        style: Theme.of(context).textTheme.bodySmall),
                    const SizedBox(height: 4),
                    Wrap(crossAxisAlignment: WrapCrossAlignment.center, children: [
                      const Icon(Icons.circle, size: 10, color: Colors.green),
                      const SizedBox(width: 4),
                      Text('$online в комнате'),
                      const SizedBox(width: 10),
                      const Icon(Icons.favorite, size: 14, color: Colors.pinkAccent),
                      const SizedBox(width: 2),
                      Text('${room.likes}'),
                      if (room.closed) ...[
                        const SizedBox(width: 8),
                        const Text('· закрыта'),
                      ] else if (!room.isPublic) ...[
                        const SizedBox(width: 8),
                        const Text('· по приглашению'),
                      ],
                    ]),
                  ],
                ),
              ),
            ),
            if (mine || store.me.role == Role.admin)
              IconButton(
                tooltip: 'Удалить комнату',
                icon: const Icon(Icons.delete_outline),
                onPressed: () => store.deleteRoom(room.id),
              ),
          ],
        ),
      ),
    );
  }
}

class _CreateRoomSheet extends StatefulWidget {
  const _CreateRoomSheet();

  @override
  State<_CreateRoomSheet> createState() => _CreateRoomSheetState();
}

class _CreateRoomSheetState extends State<_CreateRoomSheet> {
  final _name = TextEditingController();
  int _theme = 0;
  bool _public = true;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    return Padding(
      padding: EdgeInsets.fromLTRB(
        16, 0, 16, MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Новая комната', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          TextField(
            controller: _name,
            maxLength: 30,
            decoration: const InputDecoration(
              labelText: 'Название',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          const Text('Тема комнаты'),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              for (var i = 0; i < roomThemes.length; i++)
                if (store.owned.contains('theme$i'))
                  ChoiceChip(
                    label: Text(roomThemes[i].name),
                    selected: _theme == i,
                    onSelected: (_) => setState(() => _theme = i),
                  ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            store.rooms.any((r) => r.ownerId == 'me')
                ? 'Стоимость: ${store.settings.roomCost} 🪙'
                : 'Первая комната бесплатно',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Открытая комната'),
            subtitle: const Text('Закрытая — только по приглашению'),
            value: _public,
            onChanged: (v) => setState(() => _public = v),
          ),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () async {
                final name = _name.text.trim();
                if (name.isEmpty) return;
                final room = store.api != null
                    ? await store.createRoomRemote(name: name, theme: _theme, isPublic: _public)
                    : store.createRoom(name: name, theme: _theme, isPublic: _public);
                if (room == null || !context.mounted) return;
                final nav = Navigator.of(context);
                nav.pop();
                nav.push(MaterialPageRoute<void>(
                  builder: (_) => RoomScreen(roomId: room.id),
                ));
              },
              child: const Text('Создать и войти'),
            ),
          ),
        ],
      ),
    );
  }
}
