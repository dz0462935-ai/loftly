import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../clothes.dart';
import '../models.dart';

Color shade(Color c, double f) => Color.lerp(c, Colors.black, f)!;
Color tint(Color c, double f) => Color.lerp(c, Colors.white, f)!;

RRect _rr(double l, double t, double r, double b, double rad) =>
    RRect.fromLTRBR(l, t, r, b, Radius.circular(rad));

const Offset _headC = Offset(0, -78);

/// Контур причёски сверху головы. [fringe]: 0 — чёлка набок, 1 — пробор,
/// 2 — прямая чёлка, 3 — высокая линия волос.
Path _hairCap(int fringe) {
  final top = Rect.fromCenter(center: const Offset(0, -80), width: 58, height: 58);
  final path = Path()
    ..moveTo(-29, -80)
    ..arcTo(top, math.pi, math.pi, false);
  switch (fringe) {
    case 0:
      path
        ..cubicTo(27, -88, 16, -96, 3, -94)
        ..cubicTo(-8, -93, -24, -90, -29, -80);
    case 1:
      path
        ..cubicTo(28, -86, 14, -94, 0, -97)
        ..cubicTo(-14, -94, -28, -86, -29, -80);
    case 2:
      path
        ..lineTo(29, -88)
        ..quadraticBezierTo(0, -83, -29, -88);
    default:
      path
        ..cubicTo(26, -92, 14, -100, 0, -100)
        ..cubicTo(-14, -100, -26, -92, -29, -80);
  }
  return path..close();
}

/// Волосы позади головы (длинные, хвост, афро, каре).
void _hairBack(Canvas canvas, Paint p, int style, Color c) {
  p.color = c;
  switch (style) {
    case 2:
      canvas.drawRRect(_rr(-30, -100, 30, -42, 16), p);
      p.color = shade(c, 0.14);
      canvas.drawRRect(_rr(-30, -60, 30, -42, 12), p);
    case 4:
      canvas.save();
      canvas.translate(25, -88);
      canvas.rotate(-0.28);
      canvas.drawRRect(_rr(-6.5, -3, 6.5, 34, 6.5), p);
      p.color = shade(c, 0.16);
      canvas.drawRRect(_rr(-6.5, 22, 6.5, 34, 6.5), p);
      canvas.restore();
    case 5:
      for (var i = 0; i <= 8; i++) {
        final a = math.pi + i * math.pi / 8;
        canvas.drawCircle(
          Offset(math.cos(a) * 28, -80 + math.sin(a) * 27),
          i == 0 || i == 8 ? 12 : 14,
          p,
        );
      }
      canvas.drawCircle(const Offset(0, -86), 26, p);
    case 7:
      canvas.drawRRect(_rr(-30.5, -98, 30.5, -58, 15), p);
  }
}

/// Волосы перед лицом (чёлка и макушка).
void _hairFront(Canvas canvas, Paint p, int style, Color c) {
  p.color = c;
  switch (style) {
    case 1:
      canvas.drawPath(_hairCap(0), p);
      canvas.drawRRect(_rr(-29.5, -84, -24, -68, 2.5), p);
      canvas.drawRRect(_rr(24, -84, 29.5, -68, 2.5), p);
    case 2:
      canvas.drawPath(_hairCap(1), p);
    case 3:
      canvas.drawPath(_hairCap(3), p);
      canvas.drawCircle(const Offset(0, -111), 10, p);
      p.color = shade(c, 0.14);
      canvas.drawCircle(const Offset(0, -111), 4.5, p);
      p.color = c;
    case 4:
      canvas.drawPath(_hairCap(0), p);
      p.color = const Color(0xFFEC407A);
      canvas.drawCircle(const Offset(24, -86), 3.6, p);
      p.color = c;
    case 5:
      canvas.drawPath(_hairCap(3), p);
    case 6:
      canvas.drawPath(_hairCap(3), p);
      final spikes = Path()
        ..moveTo(-24, -98)
        ..lineTo(-22, -116)
        ..lineTo(-11, -102)
        ..lineTo(-4, -121)
        ..lineTo(5, -103)
        ..lineTo(14, -118)
        ..lineTo(18, -101)
        ..lineTo(26, -110)
        ..lineTo(26, -92)
        ..close();
      canvas.drawPath(spikes, p);
    case 7:
      canvas.drawPath(_hairCap(2), p);
      canvas.drawRRect(_rr(-30.5, -88, -25, -62, 3), p);
      canvas.drawRRect(_rr(25, -88, 30.5, -62, 3), p);
  }
  if (style != 0) {
    // блик на волосах
    final g = Paint()
      ..isAntiAlias = true
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..color = const Color(0x2EFFFFFF);
    canvas.drawArc(
      Rect.fromCenter(center: const Offset(0, -82), width: 40, height: 40),
      math.pi * 1.12,
      math.pi * 0.34,
      false,
      g,
    );
  }
}

/// Рисует персонажа-«чиби» в стиле Highrise: большая голова, большие глаза,
/// маленькое тело. Ноги в точке [feet], рост ≈ 110 условных единиц * [k].
/// [back] — вид со спины. [emote] — эмоция/поза (эмодзи), [dancing] = 💃.
void paintAvatar(
  Canvas canvas,
  User u,
  Offset feet,
  double k, {
  double t = 0,
  bool moving = false,
  bool dancing = false,
  bool back = false,
  String? emote,
  bool legacy = false,
}) {
  canvas.save();
  canvas.translate(feet.dx, feet.dy);
  canvas.scale(k);
  final p = Paint()..isAntiAlias = true;
  final em = dancing ? '💃' : emote;

  // вещи из студии одежды: картинка поверх тела, а их средний цвет красит рукава и штанины
  final cTop = u.custom['top'];
  final cBottom = u.custom['bottom'];
  final cShoes = u.custom['shoes'];
  final cHat = u.custom['hat'];
  final topImg = cTop == null ? null : clothesCache.image(cTop);
  final bottomImg = cBottom == null ? null : clothesCache.image(cBottom);
  final shoesImg = cShoes == null ? null : clothesCache.image(cShoes);
  final hatImg = cHat == null ? null : clothesCache.image(cHat);
  final topColor = (cTop == null ? null : clothesCache.average(cTop)) ?? u.top;
  final bottomColor = (cBottom == null ? null : clothesCache.average(cBottom)) ?? u.bottom;
  final shoesColor = (cShoes == null ? null : clothesCache.average(cShoes)) ?? u.shoes;

  // тень
  p.color = const Color(0x33000000);
  canvas.drawOval(Rect.fromCenter(center: const Offset(0, -1), width: 38, height: 11), p);

  // ---- поза ----
  final swing = moving ? math.sin(t * 11) : 0.0;
  var lArm = 0.12 + swing * 0.5;
  var rArm = -0.12 + swing * 0.5;
  var bob = moving ? -math.sin(t * 11).abs() * 2.5 : 0.0;
  var tilt = 0.0;
  var shake = 0.0;
  var mouth = 0; // 0 улыбка, 1 открытый рот, 2 «о», 3 грусть, 4 ухмылка
  var shades = false;
  var tear = false;
  var thumb = false;
  var happyEyes = false;
  if (!moving) {
    switch (em) {
      case '💃':
        final up = 2.4 + math.sin(t * 10) * 0.3;
        lArm = 0.12 + up;
        rArm = -0.12 - up;
        bob = -math.sin(t * 8).abs() * 4;
        tilt = math.sin(t * 8) * 0.1;
        mouth = 1;
      case '👋':
        rArm = -(2.5 + math.sin(t * 12) * 0.4);
        mouth = 1;
      case '🎉':
        lArm = 2.7 + math.sin(t * 14) * 0.25;
        rArm = -(2.7 + math.sin(t * 14 + 1) * 0.25);
        bob = -math.sin(t * 9).abs() * 6;
        mouth = 1;
      case '😀':
        bob = -math.sin(t * 6).abs() * 2;
        mouth = 1;
      case '😂':
        shake = math.sin(t * 32) * 1.3;
        bob = -math.sin(t * 16).abs() * 1.5;
        lArm = -0.9;
        rArm = 0.9;
        mouth = 1;
        happyEyes = true;
      case '❤️':
        lArm = -0.95;
        rArm = 0.95;
        tilt = math.sin(t * 4) * 0.05;
        happyEyes = true;
      case '😎':
        lArm = 0.75;
        rArm = -0.75;
        shades = true;
        mouth = 4;
        tilt = -0.03;
      case '😮':
        lArm = 0.6;
        rArm = -0.6;
        mouth = 2;
      case '😢':
        lArm = 0.05;
        rArm = -0.05;
        tilt = 0.06;
        mouth = 3;
        tear = true;
      case '👍':
        rArm = -1.95;
        thumb = true;
    }
  }
  final breath = (!moving && em == null) ? math.sin(t * 2.2) * 0.8 : 0.0;
  canvas.translate(shake, bob);
  if (tilt != 0) canvas.rotate(tilt);

  // основное тело — спрайт; старая «кукла» остаётся только для студии одежды (legacy)
  if (!legacy && BodySprites.ready) {
    if (moving) canvas.rotate(math.sin(t * 11) * 0.05);
    canvas.scale(_spriteK);
    canvas.translate(-52, -320);
    paintDoll(canvas, u, back: back, t: t, mouth: mouth, shades: shades, tear: tear, happy: happyEyes);
    canvas.restore();
    return;
  }

  // ---- волосы сзади ----
  if (u.hair != 0) _hairBack(canvas, p, u.hair, u.hairColor);

  // ---- ноги и обувь ----
  final lf = -math.max(0.0, swing) * 4;
  final rf = -math.max(0.0, -swing) * 4;
  p.color = bottomColor;
  canvas.drawRRect(_rr(-11, -30, -0.5, -8 + lf, 3.5), p);
  canvas.drawRRect(_rr(0.5, -30, 11, -8 + rf, 3.5), p);
  p.color = Color(0x22000000);
  canvas.drawRRect(_rr(-11, -30, -7.5, -8 + lf, 3), p);
  canvas.drawRRect(_rr(0.5, -30, 4, -8 + rf, 3), p);
  if (bottomImg != null) paintClothLayer(canvas, 'bottom', bottomImg);
  for (final side in [-1, 1]) {
    final d = side < 0 ? lf : rf;
    final l = side < 0 ? -12.5 : -0.5;
    final r = side < 0 ? 0.5 : 12.5;
    p.color = shoesColor;
    canvas.drawRRect(_rr(l, -9 + d, r, 0 + d, 4), p);
    p.color = const Color(0xCCFFFFFF);
    canvas.drawRRect(_rr(l + 0.5, -2.6 + d, r - 0.5, 0 + d, 1.4), p);
    p.color = const Color(0x22FFFFFF);
    canvas.drawRRect(_rr(l + 2, -8 + d, l + 5, -5 + d, 1.5), p);
  }
  if (shoesImg != null) {
    paintClothLayer(canvas, 'shoes', shoesImg, dy: lf, part: 1);
    paintClothLayer(canvas, 'shoes', shoesImg, dy: rf, part: 2);
  }

  // ---- туловище ----
  p.color = topColor;
  canvas.drawRRect(_rr(-14.5, -54, 14.5, -26, 8), p);
  p.color = shade(topColor, 0.14);
  canvas.drawRRect(_rr(-14.5, -34, 14.5, -26, 6), p);
  p.color = const Color(0x1FFFFFFF);
  canvas.drawRRect(_rr(-14.5, -53, -8, -36, 5), p);
  if (!back) {
    // вырез горловины
    p.color = u.skin;
    canvas.drawPath(
      Path()
        ..moveTo(-5.5, -54)
        ..lineTo(5.5, -54)
        ..lineTo(0, -46.5)
        ..close(),
      p,
    );
  }
  if (topImg != null && !back) paintClothLayer(canvas, 'top', topImg);

  // ---- руки ----
  void arm(double side, double ang) {
    canvas.save();
    canvas.translate(side * 14.5, -50);
    canvas.rotate(ang);
    p.color = u.skin;
    canvas.drawRRect(_rr(-3.6, 0, 3.6, 22, 3.6), p);
    p.color = topColor;
    canvas.drawRRect(_rr(-4.4, -1, 4.4, 10, 3.6), p);
    p.color = u.skin;
    canvas.drawCircle(const Offset(0, 22.5), 4.4, p);
    if (thumb && side > 0) {
      canvas.drawRRect(_rr(-1.8, 22, 1.8, 30, 1.8), p);
    }
    canvas.restore();
  }

  arm(-1, lArm);
  arm(1, rArm);

  // ---- шея и голова ----
  canvas.save();
  canvas.translate(0, breath);
  p.color = shade(u.skin, 0.1);
  canvas.drawRRect(_rr(-5, -58, 5, -49, 2), p);

  // уши
  p.color = shade(u.skin, 0.06);
  canvas.drawCircle(const Offset(-26.5, -76), 5.2, p);
  canvas.drawCircle(const Offset(26.5, -76), 5.2, p);

  final headRect = Rect.fromCenter(center: _headC, width: 54, height: 52);
  p.color = u.skin;
  canvas.drawRRect(
    RRect.fromRectAndRadius(headRect, const Radius.circular(24)),
    p,
  );
  // мягкая тень на подбородке
  p.color = const Color(0x14000000);
  canvas.drawRRect(_rr(-22, -58, 22, -52, 6), p);

  if (!back) {
    _face(canvas, p, u, mouth: mouth, shades: shades, tear: tear, happy: happyEyes, t: t);
  }

  _hairTop(canvas, p, u, back);
  _hat(canvas, p, u.hat, back);
  if (hatImg != null) paintClothLayer(canvas, 'hat', hatImg);
  canvas.restore();
  canvas.restore();
}

/// Причёска поверх головы (вид спереди или сзади).
void _hairTop(Canvas canvas, Paint p, User u, bool back) {
  if (u.hair != 0) {
    if (back) {
      p.color = u.hairColor;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: const Offset(0, -79), width: 58, height: 56),
          const Radius.circular(26),
        ),
        p,
      );
    } else {
      _hairFront(canvas, p, u.hair, u.hairColor);
    }
  }

}

/// Головной убор.
void _hat(Canvas canvas, Paint p, int hat, bool back) {
  switch (hat) {
    case 1: // кепка
      p.color = const Color(0xFFD32F2F);
      canvas.drawPath(
        Path()
          ..moveTo(-30, -84)
          ..arcTo(Rect.fromCenter(center: const Offset(0, -84), width: 60, height: 56), math.pi, math.pi, false)
          ..close(),
        p,
      );
      p.color = const Color(0xFFB71C1C);
      canvas.drawRRect(_rr(-30, -88, 30, -83, 2.5), p);
      if (!back) {
        p.color = const Color(0xFFD32F2F);
        canvas.drawRRect(_rr(-6, -90, 36, -82, 4), p);
      }
    case 2: // корона
      p.color = const Color(0xFFFFC107);
      canvas.drawPath(
        Path()
          ..moveTo(-15, -101)
          ..lineTo(-15, -115)
          ..lineTo(-7.5, -107)
          ..lineTo(0, -119)
          ..lineTo(7.5, -107)
          ..lineTo(15, -115)
          ..lineTo(15, -101)
          ..close(),
        p,
      );
      p.color = const Color(0xFFFFE082);
      canvas.drawRRect(_rr(-15, -105, 15, -101, 1.5), p);
      p.color = const Color(0xFFE53935);
      canvas.drawCircle(const Offset(0, -110), 2.2, p);
    case 3: // шапка
      p.color = const Color(0xFF7E57C2);
      canvas.drawPath(
        Path()
          ..moveTo(-30, -86)
          ..arcTo(Rect.fromCenter(center: const Offset(0, -86), width: 60, height: 60), math.pi, math.pi, false)
          ..close(),
        p,
      );
      p.color = const Color(0xFFB39DDB);
      canvas.drawRRect(_rr(-31, -91, 31, -82, 4), p);
      canvas.drawCircle(const Offset(0, -118), 6.5, p);
    case 4: // бант
      p.color = const Color(0xFFEC407A);
      canvas.drawPath(
        Path()
          ..moveTo(14, -104)
          ..lineTo(29, -112)
          ..lineTo(29, -96)
          ..close()
          ..moveTo(14, -104)
          ..lineTo(0, -112)
          ..lineTo(0, -96)
          ..close(),
        p,
      );
      p.color = const Color(0xFFC2185B);
      canvas.drawCircle(const Offset(14, -104), 4, p);
  }
}

/// Волосы позади тела — для редактора, который рисует голову поверх готового тела.
void paintHairBack(Canvas canvas, User u) {
  if (u.hair != 0) _hairBack(canvas, Paint()..isAntiAlias = true, u.hair, u.hairColor);
}

/// Лицо, чёлка и шляпа без тела (координаты как у [paintAvatar]).
void paintHeadFront(
  Canvas canvas,
  User u, {
  bool back = false,
  double t = 0,
  int mouth = 0,
  bool shades = false,
  bool tear = false,
  bool happy = false,
}) {
  final p = Paint()..isAntiAlias = true;
  if (!back) _face(canvas, p, u, mouth: mouth, shades: shades, tear: tear, happy: happy, t: t);
  _hairTop(canvas, p, u, back);
  _hat(canvas, p, u.hat, back);
}

/// Базовое тело персонажа (спрайты из assets), основа всех аватаров.
class BodySprites {
  static ui.Image? front;
  static ui.Image? back;
  /// Маски областей одежды и карты теней: top_front, shade_back и т.д.
  static final Map<String, ui.Image> parts = {};
  static bool get ready => front != null && back != null;

  static Future<void> load() async {
    Future<ui.Image> one(String path) async {
      final data = await rootBundle.load(path);
      final codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
      return (await codec.getNextFrame()).image;
    }

    try {
      front = await one('assets/body_front.png');
      back = await one('assets/body_back.png');
      for (final v in ['front', 'back']) {
        parts['shade_$v'] = await one('assets/shade_$v.png');
        for (final slot in ['top', 'bottom', 'shoes']) {
          parts['${slot}_$v'] = await one('assets/mask_${slot}_$v.png');
        }
      }
    } catch (_) {}
  }
}

/// Размер спрайта тела (условные пиксели) и его масштаб в единицах аватара.
const double _spriteK = 0.37;
const _skinMul = [Color(0xFFFFFFFF), Color(0xFFFCE8A6), Color(0xFFCFA15A), Color(0xFF936632)];

/// Рисует персонажа целиком на базовом теле. Система координат — пиксели
/// спрайта (104 x 320), ноги внизу. Используется и в комнатах, и в редакторе.
void paintDoll(
  Canvas c,
  User u, {
  bool back = false,
  bool clothes = true,
  double t = 0,
  int mouth = 0,
  bool shades = false,
  bool tear = false,
  bool happy = false,
}) {
  final p = Paint()..isAntiAlias = true;
  void head(void Function() draw) {
    c.save();
    // голова-яйцо: координаты аватара (центр головы 0,-78) -> центр головы тела (55,58)
    c.translate(55, 58);
    c.scale(1.65, 2.15);
    c.translate(0, 78);
    draw();
    c.restore();
  }

  final cTop = u.custom['top'], cBottom = u.custom['bottom'];
  final cShoes = u.custom['shoes'], cHat = u.custom['hat'], cFace = u.custom['face'];
  final faceImg = cFace == null ? null : clothesCache.image(cFace);
  final topImg = cTop == null ? null : clothesCache.image(cTop);
  final bottomImg = cBottom == null ? null : clothesCache.image(cBottom);
  final shoesImg = cShoes == null ? null : clothesCache.image(cShoes);
  final hatImg = cHat == null ? null : clothesCache.image(cHat);
  final topC = (cTop == null ? null : clothesCache.average(cTop)) ?? u.top;
  final bottomC = (cBottom == null ? null : clothesCache.average(cBottom)) ?? u.bottom;
  final shoesC = (cShoes == null ? null : clothesCache.average(cShoes)) ?? u.shoes;
  final skirt = u.bottom == const Color(0xFFC62828) && cBottom == null;

  head(() => paintHairBack(c, u));

  final img = back ? BodySprites.back : BodySprites.front;
  if (img != null) {
    final i = math.max(0, skinTones.indexOf(u.skin));
    c.drawImageRect(
      img,
      Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble()),
      const Rect.fromLTWH(0, 0, 104, 320),
      Paint()
        ..filterQuality = FilterQuality.medium
        ..colorFilter = ColorFilter.mode(_skinMul[i % _skinMul.length], BlendMode.modulate),
    );
  }

  void layer(String slot, ui.Image im, double ox, double oy, double sx, double sy, double cy) {
    c.save();
    c.translate(ox, oy);
    c.scale(sx, sy);
    c.translate(0, -cy);
    paintClothLayer(c, slot, im);
    c.restore();
  }

  final view = back ? 'back' : 'front';
  const dst = Rect.fromLTWH(0, 0, 104, 320);
  // Одежда — цветная заливка с тенями тела, обрезанная по форме тела (маска региона).
  void fill(String slot, Color col) {
    final mask = BodySprites.parts['${slot}_$view'];
    if (mask == null) return;
    Rect whole(ui.Image i) => Rect.fromLTWH(0, 0, i.width.toDouble(), i.height.toDouble());
    c.saveLayer(dst, Paint());
    c.drawRect(dst, Paint()..color = col);
    final sh = BodySprites.parts['shade_$view'];
    if (sh != null) c.drawImageRect(sh, whole(sh), dst, Paint());
    c.drawImageRect(mask, whole(mask), dst, Paint()..blendMode = BlendMode.dstIn);
    c.restore();
  }

  if (clothes) {
    if (skirt) {
      p.color = bottomC;
      c.drawPath(
        Path()
          ..moveTo(26, 198)
          ..lineTo(78, 198)
          ..lineTo(88, 252)
          ..quadraticBezierTo(57, 258, 18, 252)
          ..close(),
        p,
      );
      p.color = const Color(0x22000000);
      c.drawRect(const Rect.fromLTRB(26, 198, 78, 204), p);
    } else {
      fill('bottom', bottomC);
    }
    if (bottomImg != null) layer('bottom', bottomImg, 52, 245, 1.95, 4.3, -19);
    fill('shoes', shoesC);
    if (shoesImg != null) layer('shoes', shoesImg, 56, 305, 2.5, 2.8, -4.5);
    fill('top', topC);
    if (topImg != null && !back) layer('top', topImg, 52, 165, 1.9, 2.9, -40);
  }
  if (!back) {
    if (faceImg != null) {
      // подменённое лицо: картинка целиком заменяет нарисованное
      c.drawImageRect(
        faceImg,
        Rect.fromLTWH(0, 0, faceImg.width.toDouble(), faceImg.height.toDouble()),
        const Rect.fromLTWH(18, 34, 80, 80),
        Paint()..filterQuality = FilterQuality.high,
      );
    } else {
      _spriteFace(c, u, mouth: mouth, shades: shades, tear: tear, happy: happy, t: t);
    }
  }
  head(() {
    _hairTop(c, p, u, back);
    _hat(c, p, u.hat, back);
    if (hatImg != null) paintClothLayer(c, 'hat', hatImg);
  });
}

double _rad(double deg) => deg * math.pi / 180;

/// Лицо на готовой голове-яйце (координаты спрайта 104x320): крупные глаза с
/// бликами, брови, нос, рот и румянец. Не растягивается вместе с причёской.
void _spriteFace(
  Canvas c,
  User u, {
  required int mouth,
  required bool shades,
  required bool tear,
  required bool happy,
  required double t,
}) {
  final p = Paint()..isAntiAlias = true;
  final line = Paint()
    ..isAntiAlias = true
    ..style = PaintingStyle.stroke
    ..strokeCap = StrokeCap.round;
  final blink = (t % 3.7) > 3.58;
  const ink = Color(0xFF28181A);

  p.color = const Color(0x46FF6F91);
  for (final cx in [31.0, 85.0]) {
    c.drawOval(Rect.fromCenter(center: Offset(cx, 88), width: 14, height: 8), p);
  }
  for (final s in [-1.0, 1.0]) {
    final cx = 58 + s * 17;
    line
      ..color = shade(u.hairColor, 0.12)
      ..strokeWidth = 2.4;
    c.drawArc(Rect.fromCenter(center: Offset(cx, 56), width: 18, height: 12), _rad(200), _rad(140), false, line);
    if (happy || blink) {
      line
        ..color = ink
        ..strokeWidth = 2.8;
      c.drawArc(Rect.fromCenter(center: Offset(cx, 74), width: 15, height: happy ? 12 : 6), _rad(200), _rad(140), false, line);
      continue;
    }
    p.color = Colors.white;
    c.drawOval(Rect.fromCenter(center: Offset(cx, 72), width: 16, height: 21), p);
    p.color = const Color(0xFF244682);
    c.drawOval(Rect.fromCenter(center: Offset(cx, 73), width: 12.8, height: 16.4), p);
    p.color = const Color(0xFF3C6EB9);
    c.drawOval(Rect.fromCenter(center: Offset(cx, 73), width: 12, height: 15.4), p);
    p.color = const Color(0xFF5C96D7);
    c.drawOval(Rect.fromCenter(center: Offset(cx, 74.6), width: 9.6, height: 8.6), p);
    p.color = const Color(0xFF0E121E);
    c.drawOval(Rect.fromCenter(center: Offset(cx, 72), width: 6.4, height: 8.4), p);
    p.color = Colors.white;
    c.drawCircle(Offset(cx - 2.4, 68.5), 2.2, p);
    c.drawCircle(Offset(cx + 2, 76.5), 1.1, p);
    line
      ..color = ink
      ..strokeWidth = 2.8;
    c.drawArc(Rect.fromCenter(center: Offset(cx, 71.4), width: 16.8, height: 21.2), _rad(200), _rad(140), false, line);
    c.drawLine(Offset(cx + s * 8, 63.5), Offset(cx + s * 11.5, 61), line..strokeWidth = 2.2);
  }

  if (shades) {
    p.color = const Color(0xFF1B1B1F);
    c.drawRRect(_rr(27, 62, 56, 82, 8), p);
    c.drawRRect(_rr(60, 62, 89, 82, 8), p);
    c.drawRect(const Rect.fromLTRB(55, 66, 61, 68.5), p);
    p.color = const Color(0x55FFFFFF);
    c.drawRRect(_rr(31, 65, 40, 69, 2), p);
    c.drawRRect(_rr(64, 65, 73, 69, 2), p);
  }
  if (tear) {
    p.color = const Color(0xFF64B5F6);
    c.drawOval(Rect.fromCenter(center: const Offset(34, 92), width: 5, height: 9), p);
  }

  p.color = shade(u.skin, 0.15).withAlpha(200);
  c.drawOval(Rect.fromCenter(center: const Offset(58, 86), width: 5.2, height: 3.6), p);

  const lip = Color(0xFFBE505C);
  const inside = Color(0xFF6E1F2C);
  line
    ..color = lip
    ..strokeWidth = 2.2;
  switch (mouth) {
    case 1:
      p.color = inside;
      c.drawPath(
        Path()
          ..moveTo(50, 95)
          ..quadraticBezierTo(58, 113, 66, 95)
          ..close(),
        p,
      );
      p.color = Colors.white;
      c.drawRRect(_rr(52.5, 95, 63.5, 98, 1.2), p);
      p.color = const Color(0xFFEC7C86);
      c.drawOval(Rect.fromCenter(center: const Offset(58, 104), width: 8, height: 4), p);
    case 2:
      p.color = inside;
      c.drawOval(Rect.fromCenter(center: const Offset(58, 99), width: 7, height: 9), p);
    case 3:
      c.drawPath(
        Path()
          ..moveTo(52, 102)
          ..quadraticBezierTo(58, 96, 64, 102),
        line,
      );
    case 4:
      c.drawPath(
        Path()
          ..moveTo(52, 98)
          ..quadraticBezierTo(60, 102, 67, 94),
        line,
      );
    default:
      c.drawPath(
        Path()
          ..moveTo(51, 96)
          ..quadraticBezierTo(58, 103, 65, 96),
        line,
      );
  }
}

/// Лицо: большие глаза с ресницами и бликами, брови, нос, рот, румянец.
void _face(
  Canvas canvas,
  Paint p,
  User u, {
  required int mouth,
  required bool shades,
  required bool tear,
  required bool happy,
  required double t,
}) {
  final line = Paint()
    ..isAntiAlias = true
    ..style = PaintingStyle.stroke
    ..strokeCap = StrokeCap.round;
  final blink = (t % 3.7) > 3.58;
  const ey = -76.0;

  // румянец
  p.color = const Color(0x44FF6F91);
  canvas.drawOval(Rect.fromCenter(center: const Offset(-17, -65), width: 10, height: 6.5), p);
  canvas.drawOval(Rect.fromCenter(center: const Offset(17, -65), width: 10, height: 6.5), p);

  // брови
  line
    ..color = shade(u.hairColor, 0.1)
    ..strokeWidth = 2.2;
  for (final s in [-1.0, 1.0]) {
    canvas.drawPath(
      Path()
        ..moveTo(s * 5.5, -88.2)
        ..quadraticBezierTo(s * 11.5, -91.6, s * 17, -88.4),
      line,
    );
  }

  // глаза
  for (final s in [-1.0, 1.0]) {
    final cx = s * 10.8;
    if (happy || blink) {
      line
        ..color = const Color(0xFF2A1A14)
        ..strokeWidth = 2.4;
      canvas.drawArc(
        Rect.fromCenter(center: Offset(cx, ey + 1.5), width: 10, height: happy ? 9 : 5),
        math.pi * 1.08,
        math.pi * 0.84,
        false,
        line,
      );
      continue;
    }
    p.color = Colors.white;
    canvas.drawOval(Rect.fromCenter(center: Offset(cx, ey), width: 12, height: 14), p);
    p.color = const Color(0xFF6B4A33);
    canvas.drawOval(Rect.fromCenter(center: Offset(cx, ey + 0.6), width: 9, height: 11.5), p);
    p.color = const Color(0xFF8E6542);
    canvas.drawOval(Rect.fromCenter(center: Offset(cx, ey + 3.2), width: 7, height: 5), p);
    p.color = const Color(0xFF1B1210);
    canvas.drawOval(Rect.fromCenter(center: Offset(cx, ey + 0.4), width: 5, height: 6.6), p);
    p.color = Colors.white;
    canvas.drawCircle(Offset(cx - 1.8, ey - 2.6), 1.9, p);
    canvas.drawCircle(Offset(cx + 1.6, ey + 2.4), 0.9, p);
    // верхнее веко и ресницы
    line
      ..color = const Color(0xFF241713)
      ..strokeWidth = 1.9;
    canvas.drawArc(
      Rect.fromCenter(center: Offset(cx, ey + 0.4), width: 12.4, height: 14.4),
      math.pi * 1.04,
      math.pi * 0.92,
      false,
      line,
    );
    canvas.drawLine(Offset(cx + s * 6, ey - 3.2), Offset(cx + s * 8.6, ey - 5), line..strokeWidth = 1.5);
  }

  // тёмные очки
  if (shades) {
    p.color = const Color(0xFF1B1B1F);
    canvas.drawRRect(_rr(-18.5, -82, -3, -71, 4.5), p);
    canvas.drawRRect(_rr(3, -82, 18.5, -71, 4.5), p);
    canvas.drawRect(const Rect.fromLTRB(-4, -80, 4, -78.2), p);
    p.color = const Color(0x55FFFFFF);
    canvas.drawRRect(_rr(-16.5, -80.5, -11, -77.5, 1.5), p);
    canvas.drawRRect(_rr(5, -80.5, 10.5, -77.5, 1.5), p);
  }

  // слеза
  if (tear) {
    p.color = const Color(0xFF64B5F6);
    canvas.drawOval(Rect.fromCenter(center: const Offset(-13, -66), width: 4, height: 7), p);
  }

  // нос
  p.color = shade(u.skin, 0.13);
  canvas.drawOval(Rect.fromCenter(center: const Offset(0, -68.5), width: 3.6, height: 2.6), p);

  // рот
  const lip = Color(0xFFC4575F);
  const inside = Color(0xFF7B2430);
  switch (mouth) {
    case 1:
      p.color = inside;
      canvas.drawPath(
        Path()
          ..moveTo(-6, -63.5)
          ..quadraticBezierTo(0, -51.5, 6, -63.5)
          ..close(),
        p,
      );
      p.color = const Color(0xFFEC7C86);
      canvas.drawOval(Rect.fromCenter(center: const Offset(0, -57.6), width: 5.5, height: 2.6), p);
      p.color = Colors.white;
      canvas.drawRRect(_rr(-4.6, -63.5, 4.6, -61.6, 0.8), p);
    case 2:
      p.color = inside;
      canvas.drawOval(Rect.fromCenter(center: const Offset(0, -60), width: 5.5, height: 7), p);
    case 3:
      line
        ..color = lip
        ..strokeWidth = 1.9;
      canvas.drawPath(
        Path()
          ..moveTo(-4.5, -58.5)
          ..quadraticBezierTo(0, -62.8, 4.5, -58.5),
        line,
      );
    case 4:
      line
        ..color = lip
        ..strokeWidth = 1.9;
      canvas.drawPath(
        Path()
          ..moveTo(-4.5, -61)
          ..quadraticBezierTo(1.5, -58.2, 6, -63),
        line,
      );
    default:
      line
        ..color = lip
        ..strokeWidth = 1.9;
      canvas.drawPath(
        Path()
          ..moveTo(-4.5, -62)
          ..quadraticBezierTo(0, -58, 4.5, -62),
        line,
      );
  }
}

/// Статичная фигурка для профиля, магазина и карточек.
class AvatarFigure extends StatelessWidget {
  final User user;
  final double size;
  const AvatarFigure({super.key, required this.user, this.size = 40});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size * 0.8,
      height: size * 1.25,
      child: CustomPaint(painter: _FigurePainter(user)),
    );
  }
}

class _FigurePainter extends CustomPainter {
  final User user;
  _FigurePainter(this.user);

  @override
  void paint(Canvas canvas, Size size) {
    final k = size.height / 126;
    paintAvatar(canvas, user, Offset(size.width / 2, size.height - 3 * k), k);
  }

  @override
  bool shouldRepaint(_FigurePainter old) => true;
}

/// Круглый портрет (голова персонажа) для списков.
class AvatarBadge extends StatelessWidget {
  final User user;
  final double radius;

  const AvatarBadge({super.key, required this.user, this.radius = 20});

  @override
  Widget build(BuildContext context) {
    final d = radius * 2;
    return Container(
      width: d,
      height: d,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [tint(user.top, 0.35), shade(user.top, 0.12)],
        ),
        border: Border.all(color: Colors.white.withAlpha(128), width: 1.5),
      ),
      child: ClipOval(child: CustomPaint(painter: _PortraitPainter(user))),
    );
  }
}

class _PortraitPainter extends CustomPainter {
  final User user;
  _PortraitPainter(this.user);

  @override
  void paint(Canvas canvas, Size size) {
    final sprite = BodySprites.ready;
    final k = size.width / (sprite ? 46 : 64);
    // центр головы ставим чуть выше середины круга
    paintAvatar(canvas, user, Offset(size.width / 2, size.height * 0.56 + (sprite ? 97 : 78) * k), k);
  }

  @override
  bool shouldRepaint(_PortraitPainter old) => true;
}
