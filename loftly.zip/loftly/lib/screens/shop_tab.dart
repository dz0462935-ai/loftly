import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../widgets/avatar.dart';
import '../widgets/iso.dart';

const _cats = <String, List<String>>{
  'Одежда': ['top', 'bottom', 'shoes'],
  'Волосы': ['hair', 'hairc'],
  'Шляпы': ['hat'],
  'Мебель': ['furn'],
  'Темы': ['theme'],
};

class ShopTab extends StatefulWidget {
  const ShopTab({super.key});

  @override
  State<ShopTab> createState() => _ShopTabState();
}

class _ShopTabState extends State<ShopTab> {
  String _cat = _cats.keys.first;

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final items = store.shop.where((i) => _cats[_cat]!.contains(i.cat)).toList();
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                AvatarFigure(user: store.me, size: 72),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${store.me.coins} 🪙   ${store.me.gems} 💎',
                          style: Theme.of(context).textTheme.titleLarge),
                      const SizedBox(height: 8),
                      FilledButton.icon(
                        onPressed: store.dailyReady ? store.claimDaily : null,
                        icon: const Icon(Icons.card_giftcard),
                        label: Text(store.dailyReady
                            ? 'Забрать бонус дня'
                            : 'Бонус получен (серия ${store.streak})'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 44,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              for (final c in _cats.keys)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(c),
                    selected: _cat == c,
                    onSelected: (_) => setState(() => _cat = c),
                  ),
                ),
            ],
          ),
        ),
        if (_cat == 'Шляпы')
          ListTile(
            leading: const Icon(Icons.not_interested),
            title: const Text('Без головного убора'),
            trailing: store.me.hat == 0
                ? const Chip(label: Text('Надето'))
                : FilledButton.tonal(onPressed: store.removeHat, child: const Text('Снять')),
          ),
        for (final it in items) _ItemTile(item: it),
      ],
    );
  }
}

class _ItemTile extends StatelessWidget {
  final ShopItem item;
  const _ItemTile({required this.item});

  Widget _leading() {
    switch (item.cat) {
      case 'furn':
        return Text(furnCatalog[item.id.substring(5)]!.emoji, style: const TextStyle(fontSize: 28));
      case 'theme':
        final t = roomThemes[item.index];
        return Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [t.wall, t.wall, t.floorA, t.floorA],
              stops: const [0, .5, .5, 1],
            ),
          ),
        );
      case 'hair':
        return const Icon(Icons.face_retouching_natural, size: 30);
      case 'hat':
        return const Icon(Icons.checkroom, size: 30);
      default:
        return CircleAvatar(radius: 16, backgroundColor: item.color);
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final cur = item.gems ? '💎' : '🪙';
    Widget trailing;
    String? subtitle;
    if (item.cat == 'furn') {
      final n = store.furnInv[item.id.substring(5)] ?? 0;
      subtitle = 'На складе: $n';
      trailing = FilledButton(onPressed: () => store.buy(item), child: Text('${item.price} $cur'));
    } else if (store.owns(item)) {
      if (item.cat == 'theme') {
        trailing = const Chip(label: Text('Куплено'));
      } else if (store.isEquipped(item)) {
        trailing = const Chip(label: Text('Надето'));
      } else {
        trailing = FilledButton.tonal(onPressed: () => store.equip(item), child: const Text('Надеть'));
      }
    } else {
      trailing = FilledButton(onPressed: () => store.buy(item), child: Text('${item.price} $cur'));
    }
    return ListTile(
      leading: SizedBox(width: 40, child: Center(child: _leading())),
      title: Text(item.name),
      subtitle: subtitle == null ? null : Text(subtitle),
      trailing: trailing,
    );
  }
}
