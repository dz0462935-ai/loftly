import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../ui.dart';
import '../screens/dm_screen.dart';
import 'avatar.dart';

/// Карточка пользователя: профиль, друзья, чаевые, жалоба и действия модератора.
void showUserSheet(BuildContext context, String userId) {
  final st = StoreScope.of(context);
  if (st.api != null) st.refreshFollowing();
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (_) => _UserSheet(userId: userId),
  );
}

class _UserSheet extends StatelessWidget {
  final String userId;
  const _UserSheet({required this.userId});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final user = store.users[userId]!;
    final isFriend = store.friends.contains(userId);
    final pending = store.outgoingRequests.contains(userId);
    final staff = store.me.isStaff;
    final inRoom = store.locationOf(userId) != null;
    final sid = store.serverIdOf(userId);
    final here = store.occupants(store.currentRoomId ?? '').containsKey(userId);
    final isFollowing = store.following.contains(userId);
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 128,
              height: 150,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(26),
                border: Border.all(color: Ui.a(Colors.white, .16)),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Ui.a(Ui.violet, .5), Ui.a(Ui.accent, .2)],
                ),
              ),
              child: AvatarFigure(user: user, size: 96),
            ),
            const SizedBox(height: 10),
            Text(
              (user.isStaff ? '★ ' : '') + user.name,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
            ),
            if (user.isStaff)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Tag(
                  roleName(user.role),
                  color: user.role == Role.admin ? Ui.accent : Ui.green,
                  icon: Icons.star_rounded,
                ),
              ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: isFriend
                  ? const FilledButton.tonal(onPressed: null, child: Text('Уже в друзьях'))
                  : FilledButton(
                      onPressed: pending
                          ? null
                          : () {
                              store.sendRequest(userId);
                              Navigator.of(context).pop();
                            },
                      child: Text(pending ? 'Запрос отправлен' : 'Добавить в друзья'),
                    ),
            ),
            if (sid != null) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        final nav = Navigator.of(context);
                        nav.pop();
                        nav.push(MaterialPageRoute<void>(
                          builder: (_) => DmScreen(otherId: sid, name: user.name),
                        ));
                      },
                      icon: const Icon(Icons.chat_bubble_outline_rounded, size: 18),
                      label: const Text('Написать'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => store.toggleFollow(userId),
                      icon: Icon(
                        isFollowing ? Icons.notifications_off_outlined : Icons.notifications_active_outlined,
                        size: 18,
                      ),
                      label: Text(isFollowing ? 'Отписаться' : 'Подписаться'),
                    ),
                  ),
                ],
              ),
            ],
            if (sid != null && here) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () {
                        store.requestPair(userId, 'hug');
                        Navigator.of(context).pop();
                      },
                      child: const Text('Обнять 🤗'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () {
                        store.requestPair(userId, 'dance');
                        Navigator.of(context).pop();
                      },
                      child: const Text('Танцевать 💃'),
                    ),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 8),
            Row(
              children: [
                const Text('Чаевые: '),
                for (final a in const [10, 50, 100])
                  Padding(
                    padding: const EdgeInsets.only(left: 6),
                    child: OutlinedButton(
                      onPressed: () {
                        if (store.tip(userId, a)) Navigator.of(context).pop();
                      },
                      child: Text('$a 🪙'),
                    ),
                  ),
              ],
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: () {
                  store.report(userId, 'Нарушение правил чата');
                  Navigator.of(context).pop();
                },
                icon: const Icon(Icons.flag_outlined),
                label: const Text('Пожаловаться'),
              ),
            ),
            if (staff) ...[
              const Divider(),
              Align(
                alignment: Alignment.centerLeft,
                child: Text('Модерация', style: Theme.of(context).textTheme.labelLarge),
              ),
              Wrap(
                spacing: 8,
                children: [
                  if (inRoom)
                    ActionChip(
                      avatar: const Icon(Icons.logout, size: 18),
                      label: const Text('Выгнать'),
                      onPressed: () {
                        store.kick(userId);
                        Navigator.of(context).pop();
                      },
                    ),
                  ActionChip(
                    avatar: Icon(user.muted ? Icons.volume_up : Icons.volume_off, size: 18),
                    label: Text(user.muted ? 'Снять мут' : 'Мут'),
                    onPressed: () => store.setMuted(userId, !user.muted),
                  ),
                  if (store.me.role == Role.admin)
                    ActionChip(
                      avatar: const Icon(Icons.block, size: 18),
                      label: Text(user.banned ? 'Разбанить' : 'Забанить'),
                      onPressed: () => store.setBanned(userId, !user.banned),
                    ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}
