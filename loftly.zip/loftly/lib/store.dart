import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import 'models.dart';
import 'widgets/iso.dart';

final GlobalKey<ScaffoldMessengerState> messengerKey = GlobalKey<ScaffoldMessengerState>();

const _phrases = [
  'Привет всем! 👋',
  'Классная комната',
  'Кто на вечеринку?',
  'Ха-ха, это жиза',
  'Как дела?',
  'Добавляйтесь в друзья!',
  'Музыка огонь 🎶',
  'Я ненадолго',
  'Заходите ещё!',
];

class Report {
  final String id;
  final String fromId;
  final String targetId;
  final String reason;
  final DateTime time = DateTime.now();
  bool resolved = false;
  Report(this.id, this.fromId, this.targetId, this.reason);
}

/// Экономика — настраивается в админ-панели.
class EconomySettings {
  int dailyBonus = 100;
  int presenceReward = 2;
  int roomCost = 200;
}

/// Локальное «псевдо-серверное» состояние приложения.
/// Позже его можно заменить реальным бэкендом (Firebase / Supabase / свой сервер),
/// сохранив публичный интерфейс. Права (роли, баны, монеты) в настоящем приложении
/// обязаны проверяться на сервере, а не в клиенте.
class AppStore extends ChangeNotifier {
  AppStore() {
    _initShop();
    _seed();
    _scheduleIncomingInvite(1);
  }

  final _rng = Random();
  late User me;
  final Map<String, User> users = {};
  final Set<String> friends = {};
  final List<String> incomingRequests = [];
  final Set<String> outgoingRequests = {};
  final List<Room> rooms = [];
  final List<Invite> invites = [];
  final Map<String, String> emotes = {};
  final Map<String, String> bubbles = {};
  final Set<String> backFacing = {};

  // экономика
  final EconomySettings settings = EconomySettings();
  final List<ShopItem> shop = [];
  final Set<String> owned = {};
  final Map<String, int> furnInv = {'sofa': 1, 'lamp': 1};
  DateTime? lastDaily;
  int streak = 0;

  // модерация
  final List<Report> reports = [];
  final List<LogEntry> log = [];
  final Set<String> badWords = {'дурак', 'идиот'};
  int messagesSent = 0;

  final Map<String, Map<String, Offset>> _occupants = {};
  final Map<String, List<Offset>> _paths = {};
  final Map<String, List<ChatMessage>> _chat = {};
  final List<Timer> _timers = [];
  Timer? _tick;
  int _tickCount = 0;
  String? currentRoomId;
  bool _disposed = false;
  int _idSeq = 0;

  String _newId(String prefix) => '$prefix${_idSeq++}';

  void toast(String m) {
    messengerKey.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m), duration: const Duration(seconds: 2)));
  }

  void _log(String t) {
    log.insert(0, LogEntry(t));
    if (log.length > 100) log.removeLast();
  }

  // ---------- Начальные данные ----------

  void _initShop() {
    const topN = ['Фиолетовая кофта', 'Красная кофта', 'Бирюзовая кофта', 'Оранжевая кофта', 'Синяя кофта', 'Розовая кофта'];
    for (var i = 0; i < topN.length; i++) {
      shop.add(ShopItem('top$i', 'top', topN[i], i == 0 ? 0 : 60 + i * 15, color: outfitColors[i]));
    }
    const botN = ['Тёмные джинсы', 'Голубые джинсы', 'Бежевые брюки', 'Красная юбка'];
    const botC = [Color(0xFF37474F), Color(0xFF5C7FA8), Color(0xFFC8B08A), Color(0xFFC62828)];
    for (var i = 0; i < botN.length; i++) {
      shop.add(ShopItem('bottom$i', 'bottom', botN[i], i == 0 ? 0 : 70, color: botC[i]));
    }
    const shoeN = ['Белые кеды', 'Чёрные кеды', 'Красные кеды'];
    const shoeC = [Color(0xFFFAFAFA), Color(0xFF212121), Color(0xFFE53935)];
    for (var i = 0; i < shoeN.length; i++) {
      shop.add(ShopItem('shoes$i', 'shoes', shoeN[i], i == 0 ? 0 : 50, color: shoeC[i]));
    }
    shop.add(ShopItem('hair1', 'hair', 'Короткие волосы', 0, index: 1));
    shop.add(ShopItem('hair2', 'hair', 'Длинные волосы', 100, index: 2));
    shop.add(ShopItem('hair3', 'hair', 'Пучок', 120, index: 3));
    shop.add(ShopItem('hair0', 'hair', 'Без волос', 30, index: 0));
    const hcN = ['Тёмно-каштановые', 'Каштановые', 'Блонд', 'Рыжие', 'Синие', 'Белые'];
    for (var i = 0; i < hcN.length; i++) {
      shop.add(ShopItem('hc$i', 'hairc', hcN[i], i == 0 ? 0 : 40, color: hairColors[i]));
    }
    shop.add(ShopItem('hat1', 'hat', 'Кепка', 100, index: 1));
    shop.add(ShopItem('hat3', 'hat', 'Шапка с помпоном', 130, index: 3));
    shop.add(ShopItem('hat4', 'hat', 'Бант', 90, index: 4));
    shop.add(ShopItem('hat2', 'hat', 'Золотая корона', 8, index: 2, gems: true));
    for (final e in furnCatalog.entries) {
      shop.add(ShopItem('furn:${e.key}', 'furn', e.value.name, e.value.price));
    }
    for (var i = 1; i < roomThemes.length; i++) {
      shop.add(ShopItem('theme$i', 'theme', 'Тема «${roomThemes[i].name}»', 150 + i * 30, index: i));
    }
    owned.addAll(['top0', 'bottom0', 'shoes0', 'hair1', 'hc0', 'theme0']);
  }

  void _decorate(Room r, List<(String, int, int)> list) {
    for (final e in list) {
      r.furniture.add(Furniture(uid: _newId('f'), kind: e.$1, x: e.$2, y: e.$3));
    }
  }

  void _seed() {
    me = User(
      id: 'me',
      name: 'Вы',
      skin: skinTones[0],
      top: outfitColors[0],
      role: Role.admin,
      coins: 500,
      gems: 5,
    );
    users['me'] = me;
    const names = ['Алиса', 'Макс', 'Соня', 'Тимур', 'Лера', 'Данил', 'Ника', 'Артём'];
    for (var i = 0; i < names.length; i++) {
      users['u$i'] = User(
        id: 'u$i',
        name: names[i],
        skin: skinTones[i % skinTones.length],
        top: outfitColors[(i + 1) % outfitColors.length],
        bottom: i.isEven ? const Color(0xFF37474F) : const Color(0xFF5C7FA8),
        hairColor: hairColors[i % hairColors.length],
        hair: i % hairNames.length,
        hat: i % 3 == 0 ? i % hatNames.length : 0,
        coins: 100 + _rng.nextInt(900),
        role: i == 1 ? Role.moderator : Role.player,
      );
    }
    friends.addAll(['u0', 'u1', 'u2']);
    incomingRequests.add('u3');

    final r0 = Room(id: 'r0', name: 'Лофт на закате', ownerId: 'u0', theme: 0)..likes = 24;
    _decorate(r0, [
      ('bed', 0, 1), ('shelf', 2, 0), ('desk', 5, 0), ('chair', 5, 1), ('lamp', 7, 0),
      ('fridge', 0, 4), ('plant', 0, 6), ('sofa', 3, 3), ('rug', 3, 4), ('table', 3, 4), ('tv', 6, 2),
    ]);
    final r1 = Room(id: 'r1', name: 'Кофейня', ownerId: 'u1', theme: 3)..likes = 11;
    _decorate(r1, [
      ('table', 3, 3), ('chair', 3, 2), ('chair', 4, 4), ('plant', 0, 0), ('fridge', 7, 0), ('lamp', 0, 7),
    ]);
    final r2 = Room(id: 'r2', name: 'Танцпол', ownerId: 'u4', theme: 4)..likes = 37;
    _decorate(r2, [('arcade', 1, 0), ('arcade', 2, 0), ('lamp', 7, 0), ('rug', 3, 3), ('plant', 0, 7)]);
    final r3 = Room(id: 'r3', name: 'Моя комната', ownerId: 'me', theme: 0, isPublic: false);
    _decorate(r3, [('rug', 3, 3), ('plant', 0, 0)]);
    rooms.addAll([r0, r1, r2, r3]);

    for (final r in rooms) {
      final occ = <String, Offset>{};
      final candidates = users.keys.where((k) => k != 'me').toList()..shuffle(_rng);
      final n = r.ownerId == 'me' ? 0 : 1 + _rng.nextInt(3);
      for (final id in candidates.take(n)) {
        occ[id] = _randomFree(r);
      }
      _occupants[r.id] = occ;
      _chat[r.id] = [ChatMessage.system('Добро пожаловать в «${r.name}»')];
    }
    invites.add(Invite(id: _newId('i'), roomId: 'r0', fromId: 'u0'));
    _log('Сервер запущен');
  }

  // ---------- Сетка и поиск пути ----------

  List<List<bool>> _blocked(Room room) {
    final b = List.generate(roomGrid, (_) => List.filled(roomGrid, false));
    for (final f in room.furniture) {
      final s = furnCatalog[f.kind]!;
      if (s.walkable) continue;
      for (var dx = 0; dx < s.w; dx++) {
        for (var dy = 0; dy < s.d; dy++) {
          b[f.x + dx][f.y + dy] = true;
        }
      }
    }
    return b;
  }

  Offset _randomFree(Room room) {
    final b = _blocked(room);
    final free = <Offset>[];
    for (var x = 0; x < roomGrid; x++) {
      for (var y = 0; y < roomGrid; y++) {
        if (!b[x][y]) free.add(Offset(x + .5, y + .5));
      }
    }
    return free.isEmpty ? const Offset(4.5, 4.5) : free[_rng.nextInt(free.length)];
  }

  List<Offset> _findPath(Room room, Offset from, int gx, int gy) {
    const n = roomGrid;
    final blocked = _blocked(room);
    if (gx < 0 || gy < 0 || gx >= n || gy >= n || blocked[gx][gy]) return [];
    final sx = from.dx.floor().clamp(0, n - 1).toInt();
    final sy = from.dy.floor().clamp(0, n - 1).toInt();
    final start = sx * n + sy;
    final goal = gx * n + gy;
    final prev = List.filled(n * n, -1);
    final seen = List.filled(n * n, false);
    final q = <int>[start];
    seen[start] = true;
    var qi = 0;
    while (qi < q.length) {
      final cur = q[qi++];
      if (cur == goal) break;
      final cx = cur ~/ n, cy = cur % n;
      for (var dx = -1; dx <= 1; dx++) {
        for (var dy = -1; dy <= 1; dy++) {
          if (dx == 0 && dy == 0) continue;
          final nx = cx + dx, ny = cy + dy;
          if (nx < 0 || ny < 0 || nx >= n || ny >= n) continue;
          if (blocked[nx][ny] || seen[nx * n + ny]) continue;
          if (dx != 0 && dy != 0 && (blocked[cx + dx][cy] || blocked[cx][cy + dy])) continue;
          seen[nx * n + ny] = true;
          prev[nx * n + ny] = cur;
          q.add(nx * n + ny);
        }
      }
    }
    if (!seen[goal]) return [];
    final path = <Offset>[];
    var c = goal;
    while (c != start) {
      path.add(Offset(c ~/ n + .5, c % n + .5));
      c = prev[c];
    }
    if (path.isEmpty) path.add(Offset(gx + .5, gy + .5));
    return path.reversed.toList();
  }

  void walkTo(String uid, int tx, int ty) {
    final id = currentRoomId;
    final room = id == null ? null : roomById(id);
    final pos = id == null ? null : _occupants[id]?[uid];
    if (room == null || pos == null) return;
    _paths[uid] = _findPath(room, pos, tx, ty);
  }

  /// Двигает персонажей. Вызывается из тикера комнаты (без notifyListeners).
  void step(double dt) {
    final id = currentRoomId;
    final occ = id == null ? null : _occupants[id];
    if (occ == null) return;
    for (final uid in occ.keys.toList()) {
      final path = _paths[uid];
      if (path == null || path.isEmpty) continue;
      var pos = occ[uid]!;
      var budget = 2.6 * dt;
      while (budget > 0 && path.isNotEmpty) {
        final d = path.first - pos;
        final dist = d.distance;
        if (dist < 1e-6) {
          path.removeAt(0);
          continue;
        }
        if (d.dx + d.dy < -0.001) {
          backFacing.add(uid);
        } else if (d.dx + d.dy > 0.001) {
          backFacing.remove(uid);
        }
        if (dist <= budget) {
          pos = path.first;
          budget -= dist;
          path.removeAt(0);
        } else {
          pos = pos + d / dist * budget;
          budget = 0;
        }
      }
      occ[uid] = pos;
    }
  }

  Set<String> get movingIds => {
        for (final e in _paths.entries)
          if (e.value.isNotEmpty) e.key,
      };

  // ---------- Запросы ----------

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  void _later(Duration d, void Function() f) {
    _timers.add(Timer(d, () {
      if (!_disposed) f();
    }));
  }

  Map<String, Offset> occupants(String roomId) => _occupants[roomId] ?? {};
  List<ChatMessage> chat(String roomId) => _chat[roomId] ?? [];
  int onlineCount(String roomId) => occupants(roomId).length;
  int get onlineTotal => _occupants.values.fold(0, (a, m) => a + m.length);

  Room? roomById(String id) {
    for (final r in rooms) {
      if (r.id == id) return r;
    }
    return null;
  }

  String? locationOf(String userId) {
    for (final e in _occupants.entries) {
      if (e.value.containsKey(userId)) return e.key;
    }
    return null;
  }

  List<User> get friendList =>
      friends.map((id) => users[id]!).toList()..sort((a, b) => a.name.compareTo(b.name));

  List<User> get discoverable => users.values
      .where((u) => u.id != 'me' && !friends.contains(u.id) && !outgoingRequests.contains(u.id))
      .toList();

  bool canEdit(Room r) => r.ownerId == 'me';
  bool canEnter(Room r) => !r.closed || me.role == Role.admin;

  // ---------- Комнаты ----------

  Room? createRoom({required String name, required int theme, required bool isPublic}) {
    final mineCount = rooms.where((r) => r.ownerId == 'me').length;
    final cost = mineCount == 0 ? 0 : settings.roomCost;
    if (me.coins < cost) {
      toast('Не хватает монет: нужно $cost 🪙');
      return null;
    }
    if (!owned.contains('theme$theme')) theme = 0;
    me.coins -= cost;
    final room = Room(id: _newId('r'), name: name, ownerId: 'me', theme: theme, isPublic: isPublic);
    rooms.insert(0, room);
    _occupants[room.id] = {};
    _chat[room.id] = [ChatMessage.system('Комната создана')];
    _notify();
    return room;
  }

  void deleteRoom(String id) {
    final r = roomById(id);
    if (r == null || (r.ownerId != 'me' && me.role != Role.admin)) return;
    if (r.ownerId == 'me') {
      for (final f in r.furniture) {
        furnInv[f.kind] = (furnInv[f.kind] ?? 0) + 1;
      }
    } else {
      _log('Админ удалил комнату «${r.name}»');
    }
    rooms.removeWhere((x) => x.id == id);
    _occupants.remove(id);
    _chat.remove(id);
    invites.removeWhere((i) => i.roomId == id);
    _notify();
  }

  void setRoomTheme(Room r, int theme) {
    if (!canEdit(r) || !owned.contains('theme$theme')) return;
    r.theme = theme;
    _notify();
  }

  void toggleLike(String roomId) {
    final r = roomById(roomId);
    if (r == null) return;
    if (r.likedBy.remove('me')) {
      r.likes--;
    } else {
      r.likedBy.add('me');
      r.likes++;
    }
    _notify();
  }

  bool canPlace(Room room, String kind, int x, int y, {String? ignoreUid}) {
    final s = furnCatalog[kind]!;
    if (x < 0 || y < 0 || x + s.w > roomGrid || y + s.d > roomGrid) return false;
    for (final f in room.furniture) {
      if (f.uid == ignoreUid) continue;
      final o = furnCatalog[f.kind]!;
      if (s.walkable != o.walkable) continue;
      final overlap = x < f.x + o.w && x + s.w > f.x && y < f.y + o.d && y + s.d > f.y;
      if (overlap) return false;
    }
    return true;
  }

  bool placeFurniture(Room room, String kind, int x, int y) {
    if (!canEdit(room) || (furnInv[kind] ?? 0) <= 0 || !canPlace(room, kind, x, y)) return false;
    furnInv[kind] = furnInv[kind]! - 1;
    room.furniture.add(Furniture(uid: _newId('f'), kind: kind, x: x, y: y));
    _notify();
    return true;
  }

  void removeFurniture(Room room, Furniture f) {
    if (!canEdit(room)) return;
    room.furniture.remove(f);
    furnInv[f.kind] = (furnInv[f.kind] ?? 0) + 1;
    _notify();
  }

  void enterRoom(String roomId) {
    final room = roomById(roomId);
    currentRoomId = roomId;
    final occ = _occupants.putIfAbsent(roomId, () => {});
    occ['me'] = room == null ? const Offset(6.5, 6.5) : _randomFree(room);
    _paths.remove('me');
    _chat.putIfAbsent(roomId, () => []).add(ChatMessage.system('Вы вошли в комнату'));
    _tick?.cancel();
    _tickCount = 0;
    _tick = Timer.periodic(const Duration(seconds: 3), (_) => _botTick());
  }

  void leaveRoom() {
    final id = currentRoomId;
    if (id == null) return;
    _occupants[id]?.remove('me');
    _paths.remove('me');
    emotes.clear();
    bubbles.clear();
    currentRoomId = null;
    _tick?.cancel();
    _tick = null;
    Future.microtask(_notify);
  }

  void _botTick() {
    final id = currentRoomId;
    if (id == null) return;
    final room = roomById(id);
    final occ = _occupants[id];
    if (room == null || occ == null) return;

    _tickCount++;
    if (_tickCount % 10 == 0 && settings.presenceReward > 0) {
      me.coins += settings.presenceReward;
      toast('+${settings.presenceReward} 🪙 за время в комнате');
    }

    final bots = occ.keys.where((k) => k != 'me').toList();
    for (final b in bots) {
      final u = users[b]!;
      final r = _rng.nextDouble();
      if (r < 0.40) {
        final t = _randomFree(room);
        _paths[b] = _findPath(room, occ[b]!, t.dx.floor(), t.dy.floor());
      } else if (r < 0.50 && !u.muted) {
        _say(id, b, _phrases[_rng.nextInt(_phrases.length)]);
      } else if (r < 0.55) {
        _emote(b, '💃', 4);
      } else if (r < 0.59) {
        occ.remove(b);
        _paths.remove(b);
        _system(id, '${u.name} вышел(а)');
      }
    }
    if (occ.length < 6 && _rng.nextDouble() < 0.3) {
      final cand = users.keys.where((k) => k != 'me' && !occ.containsKey(k) && !users[k]!.banned).toList();
      if (cand.isNotEmpty) {
        final b = cand[_rng.nextInt(cand.length)];
        _removeFromAllRooms(b);
        occ[b] = _randomFree(room);
        _system(id, '${users[b]!.name} зашёл(ла)');
      }
    }
    if (emotes['me'] == '💃' && bots.isNotEmpty && _rng.nextDouble() < 0.5) {
      final b = users[bots[_rng.nextInt(bots.length)]]!;
      if (b.coins >= 5) {
        b.coins -= 5;
        me.coins += 5;
        _system(id, '${b.name} оценил(а) ваш танец: +5 🪙');
      }
    }
    _notify();
  }

  void _removeFromAllRooms(String userId) {
    for (final m in _occupants.values) {
      m.remove(userId);
    }
    _paths.remove(userId);
  }

  void _say(String roomId, String userId, String text) {
    final list = _chat.putIfAbsent(roomId, () => []);
    list.add(ChatMessage(userId, text));
    if (list.length > 200) list.removeRange(0, list.length - 200);
    messagesSent++;
    bubbles[userId] = text;
    _later(const Duration(seconds: 5), () {
      if (bubbles[userId] == text) {
        bubbles.remove(userId);
        _notify();
      }
    });
  }

  void _system(String roomId, String text) {
    _chat.putIfAbsent(roomId, () => []).add(ChatMessage.system(text));
  }

  void _emote(String userId, String emoji, int seconds) {
    emotes[userId] = emoji;
    _later(Duration(seconds: seconds), () {
      if (emotes[userId] == emoji) {
        emotes.remove(userId);
        _notify();
      }
    });
  }

  void moveMe(int tx, int ty) {
    if (currentRoomId == null) return;
    walkTo('me', tx, ty);
  }

  void sendMessage(String text) {
    final id = currentRoomId;
    var t = text.trim();
    if (id == null || t.isEmpty) return;
    if (me.muted) {
      toast('Вам запрещено писать в чат');
      return;
    }
    for (final w in badWords) {
      if (t.toLowerCase().contains(w)) {
        t = t.replaceAll(RegExp(RegExp.escape(w), caseSensitive: false), '***');
      }
    }
    _say(id, 'me', t);
    _notify();
    if (_rng.nextDouble() < 0.4) {
      _later(const Duration(milliseconds: 1500), () {
        final occ = _occupants[id];
        if (currentRoomId != id || occ == null) return;
        final bots = occ.keys.where((k) => k != 'me' && !users[k]!.muted).toList();
        if (bots.isEmpty) return;
        _say(id, bots[_rng.nextInt(bots.length)], _phrases[_rng.nextInt(_phrases.length)]);
        _notify();
      });
    }
  }

  void sendEmote(String emoji) {
    if (currentRoomId == null) return;
    _emote('me', emoji, emoji == '💃' ? 6 : 2);
    _notify();
  }

  // ---------- Приглашения ----------

  void inviteFriend(String friendId) {
    final id = currentRoomId;
    if (id == null) return;
    final room = roomById(id);
    _system(id, 'Вы пригласили ${users[friendId]!.name}');
    _later(const Duration(seconds: 3), () {
      final occ = _occupants[id];
      if (room != null && currentRoomId == id && occ != null && !occ.containsKey(friendId)) {
        _removeFromAllRooms(friendId);
        occ[friendId] = _randomFree(room);
        _system(id, '${users[friendId]!.name} принял(а) приглашение');
        _notify();
      }
    });
    _notify();
  }

  Room? acceptInvite(Invite inv) {
    invites.removeWhere((i) => i.id == inv.id);
    _notify();
    return roomById(inv.roomId);
  }

  void declineInvite(Invite inv) {
    invites.removeWhere((i) => i.id == inv.id);
    _notify();
  }

  void _scheduleIncomingInvite(int attempt) {
    if (attempt > 5) return;
    _later(Duration(seconds: 20 + attempt * 10), () {
      final from = friends.toList();
      final open = rooms.where((r) => r.isPublic && !r.closed).toList();
      if (from.isNotEmpty && open.isNotEmpty) {
        invites.add(Invite(
          id: _newId('i'),
          roomId: open[_rng.nextInt(open.length)].id,
          fromId: from[_rng.nextInt(from.length)],
        ));
        _notify();
      }
      _scheduleIncomingInvite(attempt + 1);
    });
  }

  // ---------- Друзья ----------

  void acceptRequest(String userId) {
    incomingRequests.remove(userId);
    friends.add(userId);
    _notify();
  }

  void declineRequest(String userId) {
    incomingRequests.remove(userId);
    _notify();
  }

  void sendRequest(String userId) {
    outgoingRequests.add(userId);
    _notify();
    _later(const Duration(seconds: 2), () {
      outgoingRequests.remove(userId);
      friends.add(userId);
      _notify();
    });
  }

  void removeFriend(String userId) {
    friends.remove(userId);
    _notify();
  }

  // ---------- Профиль ----------

  void updateProfile({String? name}) {
    if (name != null && name.trim().isNotEmpty) me.name = name.trim();
    _notify();
  }

  // ---------- Валюта и магазин ----------

  bool get dailyReady {
    final d = lastDaily;
    if (d == null) return true;
    final n = DateTime.now();
    return !(d.year == n.year && d.month == n.month && d.day == n.day);
  }

  void claimDaily() {
    if (!dailyReady) return;
    final d = lastDaily;
    final y = DateTime.now().subtract(const Duration(days: 1));
    final wasYesterday = d != null && d.year == y.year && d.month == y.month && d.day == y.day;
    streak = wasYesterday ? streak + 1 : 1;
    final coins = settings.dailyBonus + min(streak - 1, 5) * 20;
    me.coins += coins;
    var msg = '+$coins 🪙 ежедневный бонус (серия: $streak)';
    if (streak % 7 == 0) {
      me.gems += 1;
      msg += ' и +1 💎';
    }
    lastDaily = DateTime.now();
    toast(msg);
    _notify();
  }

  bool owns(ShopItem it) =>
      it.cat == 'furn' ? false : (owned.contains(it.id) || (it.price == 0 && !it.gems));

  bool isEquipped(ShopItem it) {
    switch (it.cat) {
      case 'top':
        return me.top == it.color;
      case 'bottom':
        return me.bottom == it.color;
      case 'shoes':
        return me.shoes == it.color;
      case 'hair':
        return me.hair == it.index;
      case 'hairc':
        return me.hairColor == it.color;
      case 'hat':
        return me.hat == it.index;
    }
    return false;
  }

  /// Покупка (для мебели — каждая покупка добавляет штуку на склад).
  bool buy(ShopItem it) {
    if (it.cat != 'furn' && owns(it)) return true;
    final bal = it.gems ? me.gems : me.coins;
    if (bal < it.price) {
      toast(it.gems ? 'Не хватает кристаллов 💎' : 'Не хватает монет 🪙');
      return false;
    }
    if (it.gems) {
      me.gems -= it.price;
    } else {
      me.coins -= it.price;
    }
    if (it.cat == 'furn') {
      final k = it.id.substring(5);
      furnInv[k] = (furnInv[k] ?? 0) + 1;
      toast('${it.name} добавлен(а) на склад');
    } else {
      owned.add(it.id);
      equip(it);
    }
    _notify();
    return true;
  }

  void equip(ShopItem it) {
    if (!owns(it) && it.cat != 'furn') return;
    switch (it.cat) {
      case 'top':
        me.top = it.color!;
      case 'bottom':
        me.bottom = it.color!;
      case 'shoes':
        me.shoes = it.color!;
      case 'hair':
        me.hair = it.index;
      case 'hairc':
        me.hairColor = it.color!;
      case 'hat':
        me.hat = it.index;
    }
    _notify();
  }

  void removeHat() {
    me.hat = 0;
    _notify();
  }

  bool tip(String userId, int amount) {
    final u = users[userId];
    if (u == null || amount <= 0) return false;
    if (me.coins < amount) {
      toast('Не хватает монет 🪙');
      return false;
    }
    me.coins -= amount;
    u.coins += amount;
    final id = currentRoomId;
    if (id != null) _system(id, 'Вы отправили ${u.name} $amount 🪙');
    toast('Отправлено $amount 🪙 → ${u.name}');
    _notify();
    return true;
  }

  // ---------- Модерация и админ ----------

  int get coinsInCirculation => users.values.fold(0, (a, u) => a + u.coins);

  void setMuted(String uid, bool v) {
    users[uid]?.muted = v;
    _log('${v ? 'Мут' : 'Снят мут'}: ${users[uid]?.name}');
    _notify();
  }

  void setBanned(String uid, bool v) {
    final u = users[uid];
    if (u == null || uid == 'me') return;
    u.banned = v;
    if (v) _removeFromAllRooms(uid);
    _log('${v ? 'Бан' : 'Разбан'}: ${u.name}');
    _notify();
  }

  void kick(String uid) {
    final loc = locationOf(uid);
    if (loc == null || uid == 'me') return;
    _removeFromAllRooms(uid);
    _system(loc, '${users[uid]!.name} выгнан(а) из комнаты');
    _log('Кик: ${users[uid]!.name}');
    _notify();
  }

  void setRole(String uid, Role r) {
    if (uid == 'me') return;
    users[uid]?.role = r;
    _log('Роль «${roleName(r)}»: ${users[uid]?.name}');
    _notify();
  }

  void grant(String uid, {int coins = 0, int gems = 0}) {
    final u = users[uid];
    if (u == null) return;
    u.coins = max(0, u.coins + coins);
    u.gems = max(0, u.gems + gems);
    _log('Выдано ${u.name}: $coins 🪙 $gems 💎');
    _notify();
  }

  void broadcast(String text) {
    final t = text.trim();
    if (t.isEmpty) return;
    for (final id in _chat.keys) {
      _chat[id]!.add(ChatMessage.system('📢 $t', announce: true));
    }
    _log('Объявление: $t');
    toast('📢 $t');
    _notify();
  }

  void closeRoom(String roomId, bool v) {
    final r = roomById(roomId);
    if (r == null) return;
    r.closed = v;
    if (v) {
      for (final uid in (_occupants[roomId]?.keys.toList() ?? <String>[])) {
        if (uid != 'me') {
          _occupants[roomId]!.remove(uid);
          _paths.remove(uid);
        }
      }
    }
    _log('${v ? 'Закрыта' : 'Открыта'} комната «${r.name}»');
    _notify();
  }

  void addBadWord(String w) {
    final t = w.trim().toLowerCase();
    if (t.isEmpty) return;
    badWords.add(t);
    _log('Стоп-слово добавлено: $t');
    _notify();
  }

  void removeBadWord(String w) {
    badWords.remove(w);
    _notify();
  }

  void report(String targetId, String reason) {
    reports.insert(0, Report(_newId('p'), 'me', targetId, reason));
    toast('Жалоба отправлена модераторам');
    _notify();
  }

  void resolveReport(Report r) {
    r.resolved = true;
    _notify();
  }

  void touch() => _notify();

  @override
  void dispose() {
    _disposed = true;
    _tick?.cancel();
    for (final t in _timers) {
      t.cancel();
    }
    super.dispose();
  }
}

class StoreScope extends InheritedNotifier<AppStore> {
  const StoreScope({super.key, required AppStore store, required super.child})
      : super(notifier: store);

  static AppStore of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<StoreScope>()!.notifier!;
}
