// Минимальный WebSocket-сервер (RFC 6455) без зависимостей: только текстовые кадры.
import { createHash } from 'node:crypto';

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_PAYLOAD = 16 * 1024;

export class WsConn {
  constructor(socket) {
    this.socket = socket;
    this.buf = Buffer.alloc(0);
    this.fragments = [];
    this.alive = true;
    this.onmessage = () => {};
    this.onclose = () => {};
    socket.on('data', (d) => this._data(d));
    socket.on('close', () => this._closed());
    socket.on('error', () => this._closed());
  }

  _closed() {
    if (!this.alive) return;
    this.alive = false;
    this.onclose();
  }

  _data(chunk) {
    this.buf = Buffer.concat([this.buf, chunk]);
    if (this.buf.length > MAX_PAYLOAD * 4) return this.close(1009);
    for (;;) {
      const f = this._frame();
      if (!f) return;
      if (f.fail) return this.close(1002);
      this._handle(f);
    }
  }

  _frame() {
    const b = this.buf;
    if (b.length < 2) return null;
    const fin = (b[0] & 0x80) !== 0;
    const op = b[0] & 0x0f;
    const masked = (b[1] & 0x80) !== 0;
    let len = b[1] & 0x7f;
    let off = 2;
    if (len === 126) {
      if (b.length < 4) return null;
      len = b.readUInt16BE(2);
      off = 4;
    } else if (len === 127) {
      if (b.length < 10) return null;
      const big = b.readBigUInt64BE(2);
      if (big > BigInt(MAX_PAYLOAD)) return { fail: true };
      len = Number(big);
      off = 10;
    }
    if (!masked) return { fail: true }; // клиент обязан маскировать
    if (len > MAX_PAYLOAD) return { fail: true };
    if (b.length < off + 4 + len) return null;
    const mask = b.subarray(off, off + 4);
    const payload = Buffer.from(b.subarray(off + 4, off + 4 + len));
    for (let i = 0; i < len; i++) payload[i] ^= mask[i & 3];
    this.buf = b.subarray(off + 4 + len);
    return { fin, op, payload };
  }

  _handle({ fin, op, payload }) {
    if (op === 0x8) return this.close(1000);
    if (op === 0x9) return this._send(0xa, payload);
    if (op === 0xa) return;
    if (op === 0x1 || op === 0x0) {
      this.fragments.push(payload);
      if (this.fragments.reduce((a, p) => a + p.length, 0) > MAX_PAYLOAD) return this.close(1009);
      if (fin) {
        const msg = Buffer.concat(this.fragments).toString('utf8');
        this.fragments = [];
        this.onmessage(msg);
      }
    }
  }

  _send(op, payload) {
    if (!this.alive || this.socket.destroyed) return;
    const len = payload.length;
    let head;
    if (len < 126) head = Buffer.from([0x80 | op, len]);
    else if (len < 65536) {
      head = Buffer.alloc(4);
      head[0] = 0x80 | op;
      head[1] = 126;
      head.writeUInt16BE(len, 2);
    } else {
      head = Buffer.alloc(10);
      head[0] = 0x80 | op;
      head[1] = 127;
      head.writeBigUInt64BE(BigInt(len), 2);
    }
    this.socket.write(Buffer.concat([head, payload]));
  }

  send(text) {
    this._send(0x1, Buffer.from(text, 'utf8'));
  }
  ping() {
    this._send(0x9, Buffer.alloc(0));
  }
  close(code = 1000) {
    if (!this.alive) return;
    const p = Buffer.alloc(2);
    p.writeUInt16BE(code);
    this._send(0x8, p);
    this.socket.end();
    this._closed();
  }
}

/** Обрабатывает событие 'upgrade' http-сервера. accept(req) -> context | null. */
export function handleUpgrade(req, socket, accept, onConn) {
  const key = req.headers['sec-websocket-key'];
  if (req.headers.upgrade?.toLowerCase() !== 'websocket' || !key) {
    socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
    return;
  }
  const ctx = accept(req);
  if (!ctx) {
    socket.end('HTTP/1.1 401 Unauthorized\r\n\r\n');
    return;
  }
  const acceptKey = createHash('sha1').update(key + GUID).digest('base64');
  socket.write(
    'HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n' +
      `Sec-WebSocket-Accept: ${acceptKey}\r\n\r\n`,
  );
  onConn(new WsConn(socket), ctx);
}
