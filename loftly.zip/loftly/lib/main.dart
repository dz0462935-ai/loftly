import 'package:flutter/material.dart';

import 'screens/home.dart';
import 'store.dart';

void main() => runApp(const LoftlyApp());

class LoftlyApp extends StatefulWidget {
  const LoftlyApp({super.key});

  @override
  State<LoftlyApp> createState() => _LoftlyAppState();
}

class _LoftlyAppState extends State<LoftlyApp> {
  final AppStore _store = AppStore();

  @override
  void dispose() {
    _store.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StoreScope(
      store: _store,
      child: MaterialApp(
        scaffoldMessengerKey: messengerKey,
        title: 'Loftly',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7E57C2)),
        ),
        darkTheme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF7E57C2),
            brightness: Brightness.dark,
          ),
        ),
        home: const HomeScreen(),
      ),
    );
  }
}
