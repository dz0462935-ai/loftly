import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../clothes.dart';
import '../models.dart';

Color shade(Color c, double f) => Color.lerp(c, Colors.black, f)!;

RRect _rr(double l, double t, double r, double b, double rad) =>
    RRect.fromLTRBR(l, t, r, b, Radius.circular(rad));

/// Рисует персонажа-«чиби»: ноги в точке [feet], рост ≈ 100 условных единиц * [k].
/// [back] — вид со спины (когда идёт вглубь комнаты).
void paintAvatar(
  Canvas canvas,
  User u,
  Offset feet,
  double k, {
  double t = 0,
  bool moving = false,
  bool dancing = false,
  bool back = false,
}) {
  canvas.save();
  canvas.translate(feet.dx, feet.dy);
  canvas.scale(k);
  final p = Paint()..isAntiAlias = true;

  // вещи из студии одежды: картинка поверх тела, а их средний цвет красит рукава и штанины
  final cTop = u.custom['top'];
  final cBottom = u.custom['bottom'];
  final cShoes = u.custom['shoes'];
  final cHat = u.custom['hat'];
  final topImg = cTop == null ? null : clothesCache.image(cTop);
  final bottomImg = cBottom == null ? null : clothesCache.image(cBottom);
  final shoesImg = cShoes == null ? null : clothesCache.image(cShoes);
  final hatImg = cHat == null ? null : clothesCache.image(cHat);
  final topColor = (cTop == null ? null : clothesCache.average(cTop)) ?? u.top;
  final bottomColor = (cBottom == null ? null : clothesCache.average(cBottom)) ?? u.bottom;
  final shoesColor = (cShoes == null ? null : clothesCache.average(cShoes)) ?? u.shoes;

  // тень
  p.color = const Color(0x33000000);
  canvas.drawOval(Rect.fromCenter(center: const Offset(0, -1), width: 36, height: 11), p);

  final swing = moving ? math.sin(t * 11) : 0.0;
  final bob = moving
      ? -math.sin(t * 11).abs() * 2.5
      : (dancing ? -math.sin(t * 8).abs() * 4 : 0.0);
  canvas.translate(0, bob);
  if (dancing) canvas.rotate(math.sin(t * 8) * 0.1);

  // длинные волосы сзади
  if (u.hair == 2) {
    p.color = u.hairColor;
    canvas.drawRRect(_rr(-27, -98, 27, -46, 14), p);
  }

  // ноги и обувь
  final lf = -math.max(0.0, swing) * 4;
  final rf = -math.max(0.0, -swing) * 4;
  p.color = bottomColor;
  canvas.drawRRect(_rr(-10, -30, -1, -8 + lf, 3), p);
  canvas.drawRRect(_rr(1, -30, 10, -8 + rf, 3), p);
  if (bottomImg != null) paintClothLayer(canvas, 'bottom', bottomImg);
  p.color = shoesColor;
  canvas.drawRRect(_rr(-11.5, -9 + lf, 0, 0 + lf, 3.5), p);
  canvas.drawRRect(_rr(0, -9 + rf, 11.5, 0 + rf, 3.5), p);
  if (shoesImg != null) {
    paintClothLayer(canvas, 'shoes', shoesImg, dy: lf, part: 1);
    paintClothLayer(canvas, 'shoes', shoesImg, dy: rf, part: 2);
  }

  // туловище (со спины рисунок на груди не виден)
  p.color = topColor;
  canvas.drawRRect(_rr(-14, -54, 14, -26, 8), p);
  p.color = shade(topColor, 0.12);
  canvas.drawRRect(_rr(-14, -34, 14, -26, 6), p);
  if (topImg != null && !back) paintClothLayer(canvas, 'top', topImg);

  // руки
  final up = dancing ? 2.4 + math.sin(t * 10) * 0.3 : 0.0;
  void arm(double side, double ang) {
    canvas.save();
    canvas.translate(side * 14, -50);
    canvas.rotate(ang);
    p.color = u.skin;
    canvas.drawRRect(_rr(-3.5, 0, 3.5, 22, 3.5), p);
    p.color = topColor;
    canvas.drawRRect(_rr(-4, 0, 4, 10, 3), p);
    canvas.restore();
  }

  arm(-1, 0.12 + swing * 0.5 + up);
  arm(1, -0.12 + swing * 0.5 - up);

  // голова
  const headC = Offset(0, -76);
  p.color = u.skin;
  canvas.drawOval(Rect.fromCenter(center: headC, width: 52, height: 54), p);

  if (!back) {
    p.color = const Color(0xFF2B2B2B);
    canvas.drawOval(Rect.fromCenter(center: const Offset(-9, -72), width: 5.4, height: 7), p);
    canvas.drawOval(Rect.fromCenter(center: const Offset(9, -72), width: 5.4, height: 7), p);
    p.color = Colors.white;
    canvas.drawCircle(const Offset(-8, -74), 1.2, p);
    canvas.drawCircle(const Offset(10, -74), 1.2, p);
    p.color = const Color(0x40FF6F91);
    canvas.drawCircle(const Offset(-15, -65), 4.5, p);
    canvas.drawCircle(const Offset(15, -65), 4.5, p);
    final mouth = Paint()
      ..isAntiAlias = true
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round
      ..color = const Color(0xFF7A3E3E);
    canvas.drawPath(
      Path()
        ..moveTo(-4, -62)
        ..quadraticBezierTo(0, -58.5, 4, -62),
      mouth,
    );
  }

  // причёска
  if (u.hair != 0) {
    p.color = u.hairColor;
    if (back) {
      canvas.drawOval(Rect.fromCenter(center: headC, width: 54, height: 56), p);
    } else {
      canvas.drawPath(
        Path()
          ..moveTo(-27, -76)
          ..arcTo(Rect.fromCenter(center: headC, width: 54, height: 58), math.pi, math.pi, false)
          ..quadraticBezierTo(15, -86, 0, -80)
          ..quadraticBezierTo(-15, -86, -27, -76)
          ..close(),
        p,
      );
    }
    if (u.hair == 3) canvas.drawCircle(const Offset(0, -106), 9, p);
  }

  // головные уборы
  switch (u.hat) {
    case 1: // кепка
      p.color = const Color(0xFFD32F2F);
      canvas.drawPath(
        Path()
          ..moveTo(-26, -80)
          ..arcTo(Rect.fromCenter(center: const Offset(0, -80), width: 54, height: 50), math.pi, math.pi, false)
          ..close(),
        p,
      );
      if (!back) canvas.drawRRect(_rr(-4, -85, 32, -79, 3), p);
      break;
    case 2: // корона
      p.color = const Color(0xFFFFC107);
      canvas.drawPath(
        Path()
          ..moveTo(-14, -97)
          ..lineTo(-14, -110)
          ..lineTo(-7, -103)
          ..lineTo(0, -113)
          ..lineTo(7, -103)
          ..lineTo(14, -110)
          ..lineTo(14, -97)
          ..close(),
        p,
      );
      break;
    case 3: // шапка
      p.color = const Color(0xFF7E57C2);
      canvas.drawPath(
        Path()
          ..moveTo(-27, -82)
          ..arcTo(Rect.fromCenter(center: const Offset(0, -82), width: 54, height: 54), math.pi, math.pi, false)
          ..close(),
        p,
      );
      p.color = const Color(0xFFB39DDB);
      canvas.drawRRect(_rr(-27, -86, 27, -80, 3), p);
      canvas.drawCircle(const Offset(0, -110), 6, p);
      break;
    case 4: // бант
      p.color = const Color(0xFFEC407A);
      canvas.drawPath(
        Path()
          ..moveTo(14, -100)
          ..lineTo(28, -108)
          ..lineTo(28, -92)
          ..close()
          ..moveTo(14, -100)
          ..lineTo(2, -108)
          ..lineTo(2, -92)
          ..close(),
        p,
      );
      canvas.drawCircle(const Offset(14, -100), 3.5, p..color = const Color(0xFFC2185B));
      break;
  }
  if (hatImg != null) paintClothLayer(canvas, 'hat', hatImg);
  canvas.restore();
}

/// Статичная фигурка для профиля, магазина и карточек.
class AvatarFigure extends StatelessWidget {
  final User user;
  final double size;
  const AvatarFigure({super.key, required this.user, this.size = 40});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size * 0.8,
      height: size * 1.25,
      child: CustomPaint(painter: _FigurePainter(user)),
    );
  }
}

class _FigurePainter extends CustomPainter {
  final User user;
  _FigurePainter(this.user);

  @override
  void paint(Canvas canvas, Size size) {
    final k = size.height / 120;
    paintAvatar(canvas, user, Offset(size.width / 2, size.height - 4 * k), k);
  }

  @override
  bool shouldRepaint(_FigurePainter old) => true;
}

/// Маленький круглый аватар для списков.
class AvatarBadge extends StatelessWidget {
  final User user;
  final double radius;

  const AvatarBadge({super.key, required this.user, this.radius = 20});

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: radius,
      backgroundColor: user.top,
      child: Text(
        user.name.isEmpty ? '?' : user.name.characters.first.toUpperCase(),
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: radius * 0.9,
        ),
      ),
    );
  }
}
