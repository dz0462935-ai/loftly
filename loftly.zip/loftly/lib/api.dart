import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiException implements Exception {
  final String code;
  final String message;
  ApiException(this.code, this.message);

  @override
  String toString() => message;
}

String normalizeServerUrl(String raw) {
  var s = raw.trim();
  if (s.isEmpty) return s;
  if (!s.startsWith('http://') && !s.startsWith('https://')) s = 'https://$s';
  while (s.endsWith('/')) {
    s = s.substring(0, s.length - 1);
  }
  return s;
}

/// Клиент REST-API сервера Loftly.
class ApiClient {
  ApiClient(this.baseUrl, [this.token]);

  final String baseUrl;
  String? token;

  Future<Map<String, dynamic>> _call(String method, String path, [Map<String, dynamic>? body]) async {
    final uri = Uri.parse('$baseUrl$path');
    final headers = <String, String>{'Content-Type': 'application/json'};
    final t = token;
    if (t != null) headers['Authorization'] = 'Bearer $t';
    final encoded = body == null ? null : jsonEncode(body);

    http.Response res;
    try {
      final Future<http.Response> f = switch (method) {
        'GET' => http.get(uri, headers: headers),
        'PUT' => http.put(uri, headers: headers, body: encoded),
        'DELETE' => http.delete(uri, headers: headers),
        _ => http.post(uri, headers: headers, body: encoded),
      };
      // Бесплатные хостинги просыпаются до минуты — ждём подольше.
      res = await f.timeout(const Duration(seconds: 60));
    } catch (_) {
      throw ApiException('network', 'Нет связи с сервером');
    }

    Map<String, dynamic> data;
    try {
      data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
    } catch (_) {
      throw ApiException('bad_response', 'Сервер ответил некорректно (${res.statusCode})');
    }
    if (res.statusCode >= 400) {
      throw ApiException(
        (data['error'] ?? 'error').toString(),
        (data['message'] ?? 'Ошибка ${res.statusCode}').toString(),
      );
    }
    return data;
  }

  /// Возвращает {token, profile}.
  Future<Map<String, dynamic>> register(String username, String password, String name) =>
      _call('POST', '/api/register', {'username': username, 'password': password, 'name': name});

  Future<Map<String, dynamic>> login(String username, String password) =>
      _call('POST', '/api/login', {'username': username, 'password': password});

  Future<Map<String, dynamic>> me() => _call('GET', '/api/me');

  /// Возвращает {gained: {coins, gems}, profile}.
  Future<Map<String, dynamic>> daily() => _call('POST', '/api/daily', {});

  /// Возвращает профиль.
  Future<Map<String, dynamic>> buy(String itemId) => _call('POST', '/api/shop/buy', {'itemId': itemId});

  /// Возвращает профиль. itemId == null снимает шляпу.
  Future<Map<String, dynamic>> equip(String slot, String? itemId) =>
      _call('POST', '/api/equip', {'slot': slot, 'itemId': itemId});

  /// Адрес WebSocket для комнат.
  String get wsUrl => '${baseUrl.replaceFirst('http', 'ws')}/ws?token=$token';

  Future<Map<String, dynamic>> rooms() => _call('GET', '/api/rooms');

  /// Возвращает {room, profile}.
  Future<Map<String, dynamic>> createRoom(String name, int theme, bool isPublic) =>
      _call('POST', '/api/rooms', {'name': name, 'theme': theme, 'isPublic': isPublic});

  Future<Map<String, dynamic>> deleteRoom(int id) => _call('DELETE', '/api/rooms/$id');

  Future<Map<String, dynamic>> likeRoom(int id) => _call('POST', '/api/rooms/$id/like', {});

  Future<Map<String, dynamic>> setRoomTheme(int id, int theme) =>
      _call('POST', '/api/rooms/$id/theme', {'theme': theme});

  Future<Map<String, dynamic>> saveLayout(int id, List<Map<String, dynamic>> items) =>
      _call('PUT', '/api/rooms/$id/layout', {'items': items});

  Future<Map<String, dynamic>> adminSet(int userId, Map<String, dynamic> patch) =>
      _call('POST', '/api/admin/users/$userId', patch);

  Future<Map<String, dynamic>> kick(int userId) => _call('POST', '/api/admin/users/$userId/kick', {});

  /// Каталог вещей из студии: {clothes: [{id, slot, name, price, gems}], spec}.
  Future<Map<String, dynamic>> clothes() => _call('GET', '/api/clothes');

  /// Картинка вещи: {id, slot, png (base64)}.
  Future<Map<String, dynamic>> cloth(String id) => _call('GET', '/api/clothes/$id');

  /// Все вещи, включая снятые с продажи (только админ).
  Future<Map<String, dynamic>> adminClothes() => _call('GET', '/api/admin/clothes');

  /// Создаёт вещь: {slot, name, price, gems, png}. Возвращает {cloth, profile}.
  Future<Map<String, dynamic>> adminCreateCloth(Map<String, dynamic> body) =>
      _call('POST', '/api/admin/clothes', body);

  /// Меняет вещь: name, price, gems, active, png.
  Future<Map<String, dynamic>> adminUpdateCloth(String id, Map<String, dynamic> patch) =>
      _call('POST', '/api/admin/clothes/$id', patch);

  /// Событие в комнате: minutes == 0 завершает его.
  Future<Map<String, dynamic>> roomEvent(int id, String title, int minutes) =>
      _call('POST', '/api/rooms/$id/event', {'title': title, 'minutes': minutes});

  Future<Map<String, dynamic>> dmInbox() => _call('GET', '/api/dm');

  Future<Map<String, dynamic>> dmThread(int userId) => _call('GET', '/api/dm/$userId');

  Future<Map<String, dynamic>> sendDm(int userId, String text) =>
      _call('POST', '/api/dm/$userId', {'text': text});

  /// {following: [{id, name, online, room: {id, name}?, ...}]}
  Future<Map<String, dynamic>> following() => _call('GET', '/api/following');

  /// Подписаться / отписаться: {following, followers, followingCount}.
  Future<Map<String, dynamic>> follow(int userId) => _call('POST', '/api/follow/$userId', {});

  Future<Map<String, dynamic>> lottery() => _call('GET', '/api/lottery');

  /// Возвращает {results: [...], profile}.
  Future<Map<String, dynamic>> roll(String box, int count) =>
      _call('POST', '/api/lottery/roll', {'box': box, 'count': count});
}

// ---------- Сохранение входа ----------

Future<({String url, String? token})> loadSession() async {
  final p = await SharedPreferences.getInstance();
  return (url: p.getString('server_url') ?? '', token: p.getString('token'));
}

Future<void> saveSession(String url, String? token) async {
  final p = await SharedPreferences.getInstance();
  await p.setString('server_url', url);
  if (token != null) await p.setString('token', token);
}

Future<void> clearToken() async {
  final p = await SharedPreferences.getInstance();
  await p.remove('token');
}
