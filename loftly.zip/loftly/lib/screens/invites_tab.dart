import 'package:flutter/material.dart';

import '../store.dart';
import '../ui.dart';
import '../widgets/avatar.dart';
import 'room_screen.dart';

class InvitesTab extends StatelessWidget {
  const InvitesTab({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final invites = store.invites;
    if (invites.isEmpty) {
      return const EmptyState(
        icon: Icons.mail_outline_rounded,
        title: 'Приглашений нет',
        text: 'Когда друг позовёт вас в комнату, приглашение появится здесь.',
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 120),
      itemCount: invites.length,
      itemBuilder: (context, i) {
        final inv = invites[i];
        final from = store.users[inv.fromId];
        final room = store.roomById(inv.roomId);
        if (from == null || room == null) return const SizedBox.shrink();
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: GlassCard(
            padding: const EdgeInsets.all(14),
            gradient: LinearGradient(colors: [Ui.a(Ui.violet, .28), Ui.a(Ui.accent, .14)]),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  AvatarBadge(user: from, radius: 24),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text.rich(
                      TextSpan(children: [
                        TextSpan(
                          text: from.name,
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                        const TextSpan(text: ' зовёт вас в комнату '),
                        TextSpan(
                          text: '«${room.name}»',
                          style: const TextStyle(fontWeight: FontWeight.w900, color: Ui.gold),
                        ),
                      ]),
                      style: const TextStyle(fontSize: 15, height: 1.3),
                    ),
                  ),
                ]),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => store.declineInvite(inv),
                        child: const Text('Отклонить'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      flex: 2,
                      child: GradientButton(
                        label: 'Принять',
                        icon: Icons.login_rounded,
                        onPressed: () {
                          final r = store.acceptInvite(inv);
                          if (r == null) return;
                          Navigator.of(context).push(MaterialPageRoute<void>(
                            builder: (_) => RoomScreen(roomId: r.id),
                          ));
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
