import 'package:flutter/material.dart';

const List<Color> outfitColors = [
  Color(0xFF7E57C2),
  Color(0xFFEF5350),
  Color(0xFF26A69A),
  Color(0xFFFFA726),
  Color(0xFF42A5F5),
  Color(0xFFEC407A),
  Color(0xFF66BB6A),
  Color(0xFF8D6E63),
];

const List<Color> skinTones = [
  Color(0xFFF7D5BC),
  Color(0xFFF1C27D),
  Color(0xFFC68642),
  Color(0xFF8D5524),
];

const List<Color> hairColors = [
  Color(0xFF2B1B12),
  Color(0xFF6B4423),
  Color(0xFFD9A441),
  Color(0xFFB0413E),
  Color(0xFF3D5A80),
  Color(0xFFEEEEEE),
];

const List<String> hairNames = [
  'Лысый',
  'Короткие',
  'Длинные',
  'Пучок',
  'Хвост',
  'Афро',
  'Ёжик',
  'Каре',
];
const List<String> hatNames = ['Нет', 'Кепка', 'Корона', 'Шапка', 'Бант'];

enum Role { player, moderator, admin }

String roleName(Role r) => switch (r) {
      Role.player => 'Игрок',
      Role.moderator => 'Модератор',
      Role.admin => 'Админ',
    };

class User {
  final String id;
  String name;
  Color skin;
  Color top;
  Color bottom;
  Color shoes;
  Color hairColor;
  int hair;
  int hat;

  /// Вещи из студии одежды: слот (top, bottom, shoes, hat) -> id вещи.
  final Map<String, String> custom = {};
  Role role;
  bool muted;
  bool banned;
  int coins;
  int gems;

  User({
    required this.id,
    required this.name,
    required this.skin,
    required this.top,
    this.bottom = const Color(0xFF37474F),
    this.shoes = const Color(0xFFFAFAFA),
    this.hairColor = const Color(0xFF2B1B12),
    this.hair = 1,
    this.hat = 0,
    this.role = Role.player,
    this.muted = false,
    this.banned = false,
    this.coins = 0,
    this.gems = 0,
  });

  Color get outfit => top;
  bool get isStaff => role != Role.player;
}

/// Тема комнаты: стены, пол, отделка.
class RoomTheme {
  final String name;
  final Color wall;
  final Color floorA;
  final Color floorB;
  final Color trim;
  final bool planks;
  const RoomTheme(this.name, this.wall, this.floorA, this.floorB, this.trim,
      {this.planks = true});
}

const List<RoomTheme> roomThemes = [
  RoomTheme('Лофт', Color(0xFF5A3A28), Color(0xFFF6E7C8), Color(0xFFEFDDB8),
      Color(0xFFFFFFFF)),
  RoomTheme('Сирень', Color(0xFF9575CD), Color(0xFFEDE7F6), Color(0xFFD1C4E9),
      Color(0xFFFFFFFF),
      planks: false),
  RoomTheme('Мята', Color(0xFF4DB6AC), Color(0xFFE0F2F1), Color(0xFFB2DFDB),
      Color(0xFFFFFFFF),
      planks: false),
  RoomTheme('Закат', Color(0xFFE57373), Color(0xFFFFE0B2), Color(0xFFFFCC80),
      Color(0xFFFFF8E1)),
  RoomTheme('Ночь', Color(0xFF283593), Color(0xFF455A64), Color(0xFF37474F),
      Color(0xFFCFD8DC)),
];

/// Размер сетки комнаты (N x N клеток).
const int roomGrid = 8;

class Furniture {
  final String uid;
  final String kind;
  int x;
  int y;
  Furniture({required this.uid, required this.kind, required this.x, required this.y});
}

class Room {
  final String id;
  String name;
  final String ownerId;
  int theme;
  bool isPublic;
  bool closed;
  int likes = 0;
  final Set<String> likedBy = {};
  final List<Furniture> furniture = [];

  Room({
    required this.id,
    required this.name,
    required this.ownerId,
    this.theme = 0,
    this.isPublic = true,
    this.closed = false,
  });

  RoomTheme get t => roomThemes[theme % roomThemes.length];
  Color get floorColor => t.floorA;
}

class Invite {
  final String id;
  final String roomId;
  final String fromId;
  final DateTime time;

  Invite({required this.id, required this.roomId, required this.fromId})
      : time = DateTime.now();
}

class ChatMessage {
  /// null — системное сообщение.
  final String? userId;
  final String text;
  final DateTime time;
  final bool announce;

  ChatMessage(this.userId, this.text, {this.announce = false}) : time = DateTime.now();
  ChatMessage.system(String text, {bool announce = false})
      : this(null, text, announce: announce);

  bool get isSystem => userId == null;
}

/// Предмет магазина.
class ShopItem {
  final String id;
  final String cat; // top, bottom, shoes, hair, hat, furn, theme
  final String name;
  int price;
  final bool gems;
  final Color? color;
  final int index;

  /// Вещь, нарисованная в студии (картинка хранится на сервере).
  final bool custom;

  ShopItem(this.id, this.cat, this.name, this.price,
      {this.gems = false, this.color, this.index = 0, this.custom = false});
}

class LogEntry {
  final DateTime time;
  final String text;
  LogEntry(this.text) : time = DateTime.now();
}
