import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models.dart';
import 'avatar.dart';

// ---------- Каталог мебели ----------

class Part {
  final double dx, dy, w, d, z, h;
  final Color c;
  const Part(this.dx, this.dy, this.w, this.d, this.z, this.h, this.c);
}

class FurnSpec {
  final String name;
  final String emoji;
  final int w, d, price;
  final bool walkable;

  /// Высота сиденья (в клетках по Z). null — сесть нельзя.
  final double? seat;
  final List<Part> parts;
  const FurnSpec(this.name, this.emoji, this.w, this.d, this.price, this.parts,
      {this.walkable = false, this.seat});
}

const _cream = Color(0xFFF1E6D0);
const _wood = Color(0xFF8D6244);
const _woodL = Color(0xFFB88A5E);
const _dark = Color(0xFF2E2E34);
const _white = Color(0xFFF5F5F5);

const Map<String, FurnSpec> furnCatalog = {
  'sofa': FurnSpec('Диван', '🛋️', 2, 1, 300, [
    Part(0, 0, 2, 1, 0, .32, _cream),
    Part(0, 0, 2, .3, .32, .5, _cream),
    Part(0, 0, .22, 1, .32, .22, _cream),
    Part(1.78, 0, .22, 1, .32, .22, _cream),
  ], seat: .32),
  'table': FurnSpec('Журнальный столик', '☕', 2, 1, 120, [
    Part(.08, .08, .12, .12, 0, .3, _wood),
    Part(1.8, .08, .12, .12, 0, .3, _wood),
    Part(.08, .8, .12, .12, 0, .3, _wood),
    Part(1.8, .8, .12, .12, 0, .3, _wood),
    Part(0, 0, 2, 1, .3, .1, _woodL),
  ]),
  'rug': FurnSpec('Ковёр', '🟫', 3, 2, 80, [
    Part(0, 0, 3, 2, 0, .03, Color(0xFF7B5A43)),
    Part(.2, .2, 2.6, 1.6, .03, .01, Color(0xFF9C7A5B)),
  ], walkable: true),
  'tv': FurnSpec('Телевизор', '📺', 1, 1, 400, [
    Part(.1, .15, .8, .7, 0, .35, _white),
    Part(.15, .4, .7, .12, .35, .6, _dark),
  ]),
  'plant': FurnSpec('Растение', '🪴', 1, 1, 60, [
    Part(.25, .25, .5, .5, 0, .3, Color(0xFFB5651D)),
    Part(.15, .15, .7, .7, .3, .7, Color(0xFF2E7D32)),
    Part(.3, .3, .4, .4, 1.0, .35, Color(0xFF43A047)),
  ]),
  'bed': FurnSpec('Кровать', '🛏️', 2, 2, 500, [
    Part(0, 0, 2, 2, 0, .25, _wood),
    Part(0, 0, .1, 2, .25, .7, _wood),
    Part(.05, .05, 1.9, 1.9, .25, .2, _white),
    Part(.15, .15, .45, .7, .45, .12, Color(0xFFB3E5FC)),
    Part(.15, 1.15, .45, .7, .45, .12, Color(0xFFB3E5FC)),
    Part(.7, .05, 1.25, 1.9, .45, .08, Color(0xFF26A69A)),
  ], seat: .45),
  'lamp': FurnSpec('Торшер', '💡', 1, 1, 90, [
    Part(.4, .4, .2, .2, 0, 1.1, _dark),
    Part(.28, .28, .44, .44, 1.1, .3, Color(0xFFFFE082)),
  ]),
  'fridge': FurnSpec('Холодильник', '🧊', 1, 1, 250, [
    Part(.1, .1, .8, .8, 0, 1.5, Color(0xFFE0E0E0)),
    Part(.72, .1, .06, .06, .6, .5, Color(0xFF9E9E9E)),
  ]),
  'shelf': FurnSpec('Книжный шкаф', '📚', 2, 1, 200, [
    Part(0, 0, 2, .5, 0, 1.4, _wood),
    Part(.2, .1, .4, .3, 1.4, .3, Color(0xFFE57373)),
    Part(.8, .1, .3, .3, 1.4, .4, Color(0xFF64B5F6)),
  ]),
  'desk': FurnSpec('Стол с ноутбуком', '💻', 2, 1, 180, [
    Part(.06, .06, .1, .1, 0, .55, _dark),
    Part(1.84, .06, .1, .1, 0, .55, _dark),
    Part(.06, .84, .1, .1, 0, .55, _dark),
    Part(1.84, .84, .1, .1, 0, .55, _dark),
    Part(0, 0, 2, 1, .55, .08, _wood),
    Part(.6, .15, .6, .5, .63, .04, _dark),
    Part(.6, .15, .6, .06, .67, .38, Color(0xFF90CAF9)),
  ]),
  'chair': FurnSpec('Кресло', '🪑', 1, 1, 90, [
    Part(.2, .2, .6, .6, 0, .35, Color(0xFF9E9E9E)),
    Part(.2, .2, .6, .12, .35, .5, Color(0xFF9E9E9E)),
  ], seat: .35),
  'arcade': FurnSpec('Аркадный автомат', '🕹️', 1, 1, 350, [
    Part(.1, .1, .8, .8, 0, 1.5, Color(0xFF5E35B1)),
    Part(.15, .75, .7, .08, .8, .5, Color(0xFF80DEEA)),
  ]),
};

// ---------- Геометрия ----------

class IsoGeom {
  final double tw, th, ox, oy, unit, wallH;
  const IsoGeom._(this.tw, this.th, this.ox, this.oy, this.unit, this.wallH);

  factory IsoGeom(Size s) {
    const n = roomGrid;
    final tw = math.min(
      s.width * 0.94 / n,
      s.height * 0.92 / (n * 0.5 + 2.5 * 0.62 + 0.25),
    );
    final th = tw / 2;
    final unit = tw * 0.62;
    final wallH = unit * 2.5;
    final total = n * th + wallH + unit * 0.25;
    return IsoGeom._(tw, th, s.width / 2, (s.height - total) / 2 + wallH, unit, wallH);
  }

  Offset p(double x, double y, [double z = 0]) => Offset(
        ox + (x - y) * tw / 2,
        oy + (x + y) * th / 2 - z * unit,
      );

  /// Экранная точка -> координаты сетки.
  Offset toGrid(Offset s) {
    final a = (s.dx - ox) / (tw / 2);
    final b = (s.dy - oy) / (th / 2);
    return Offset((a + b) / 2, (b - a) / 2);
  }

  double get avatarK => tw * 0.0125;

  Rect avatarRect(Offset grid) {
    final f = p(grid.dx, grid.dy);
    final k = avatarK;
    return Rect.fromLTRB(f.dx - 20 * k, f.dy - 120 * k, f.dx + 20 * k, f.dy + 2 * k);
  }
}

Furniture? furnAt(Room room, int tx, int ty) {
  for (final f in room.furniture.reversed) {
    final s = furnCatalog[f.kind]!;
    if (tx >= f.x && tx < f.x + s.w && ty >= f.y && ty < f.y + s.d) return f;
  }
  return null;
}

// ---------- Рисование комнаты ----------

class RoomPainter extends CustomPainter {
  final Room room;
  final Map<String, Offset> pos;
  final Map<String, User> users;
  final Map<String, String> emotes;
  final Map<String, String> bubbles;
  final Set<String> moving;
  final Set<String> backFacing;

  /// Кто смотрит влево на экране (остальные — вправо).
  final Set<String> faceLeft;

  /// Кто сидит на мебели.
  final Set<String> sitting;
  final double t;
  final String? placeKind;
  final Offset? placeTile;
  final bool placeOk;

  RoomPainter({
    required this.room,
    required this.pos,
    required this.users,
    required this.emotes,
    required this.bubbles,
    required this.moving,
    required this.backFacing,
    this.faceLeft = const {},
    this.sitting = const {},
    required this.t,
    this.placeKind,
    this.placeTile,
    this.placeOk = true,
  });

  Color _a(Color c, double a) => c.withAlpha((255 * a).round());

  void _poly(Canvas c, List<Offset> pts, Color col) {
    c.drawPath(Path()..addPolygon(pts, true), Paint()..color = col..isAntiAlias = true);
  }

  void _box(Canvas c, IsoGeom g, double x, double y, double w, double d, double z,
      double h, Color col, [double alpha = 1]) {
    _poly(c, [g.p(x, y + d, z + h), g.p(x + w, y + d, z + h), g.p(x + w, y + d, z), g.p(x, y + d, z)],
        _a(shade(col, .15), alpha));
    _poly(c, [g.p(x + w, y, z + h), g.p(x + w, y + d, z + h), g.p(x + w, y + d, z), g.p(x + w, y, z)],
        _a(shade(col, .3), alpha));
    _poly(c, [g.p(x, y, z + h), g.p(x + w, y, z + h), g.p(x + w, y + d, z + h), g.p(x, y + d, z + h)],
        _a(col, alpha));
  }

  void _furn(Canvas c, IsoGeom g, FurnSpec s, double x, double y, [double alpha = 1]) {
    for (final p in s.parts) {
      _box(c, g, x + p.dx, y + p.dy, p.w, p.d, p.z, p.h, p.c, alpha);
    }
  }

  void _wallQuad(Canvas c, IsoGeom g, bool left, double a0, double a1, double z0,
      double z1, Color col) {
    final pts = left
        ? [g.p(0, a0, z0), g.p(0, a1, z0), g.p(0, a1, z1), g.p(0, a0, z1)]
        : [g.p(a0, 0, z0), g.p(a1, 0, z0), g.p(a1, 0, z1), g.p(a0, 0, z1)];
    _poly(c, pts, col);
  }

  void _shell(Canvas c, IsoGeom g, RoomTheme th) {
    final n = roomGrid.toDouble();
    final wu = g.wallH / g.unit;
    // край пола (толщина)
    _poly(c, [g.p(0, n), g.p(n, n), g.p(n, n, -.22), g.p(0, n, -.22)], shade(th.trim, .12));
    _poly(c, [g.p(n, 0), g.p(n, n), g.p(n, n, -.22), g.p(n, 0, -.22)], shade(th.trim, .25));
    // пол
    _poly(c, [g.p(0, 0), g.p(n, 0), g.p(n, n), g.p(0, n)], th.floorA);
    if (th.planks) {
      for (var i = 1; i < roomGrid * 2; i += 2) {
        _poly(c, [g.p(0, i / 2), g.p(n, i / 2), g.p(n, (i + 1) / 2), g.p(0, (i + 1) / 2)], th.floorB);
      }
    } else {
      for (var ix = 0; ix < roomGrid; ix++) {
        for (var iy = 0; iy < roomGrid; iy++) {
          if ((ix + iy).isOdd) {
            _poly(c, [g.p(ix.toDouble(), iy.toDouble()), g.p(ix + 1.0, iy.toDouble()),
                g.p(ix + 1.0, iy + 1.0), g.p(ix.toDouble(), iy + 1.0)], th.floorB);
          }
        }
      }
    }
    // стены
    _poly(c, [g.p(0, 0), g.p(0, n), g.p(0, n, wu), g.p(0, 0, wu)], shade(th.wall, .12));
    _poly(c, [g.p(0, 0), g.p(n, 0), g.p(n, 0, wu), g.p(0, 0, wu)], th.wall);
    final line = Paint()
      ..color = const Color(0x22000000)
      ..strokeWidth = 1;
    for (var i = 1; i < roomGrid * 2; i++) {
      c.drawLine(g.p(0, i / 2), g.p(0, i / 2, wu), line);
      c.drawLine(g.p(i / 2, 0), g.p(i / 2, 0, wu), line);
    }
    // отделка
    for (final left in [true, false]) {
      _wallQuad(c, g, left, 0, n, wu - .14, wu, th.trim);
      _wallQuad(c, g, left, 0, n, 0, .14, shade(th.trim, .05));
    }
    // окно справа
    final night = th.name == 'Ночь';
    _wallQuad(c, g, false, 5, 6.8, .9, 2.1, _white);
    _wallQuad(c, g, false, 5.1, 6.7, 1.0, 2.0, night ? const Color(0xFF1A237E) : const Color(0xFF9AD0F5));
    if (!night) _wallQuad(c, g, false, 5.1, 6.7, 1.0, 1.3, const Color(0xFF7CB342));
    _wallQuad(c, g, false, 5.85, 5.95, 1.0, 2.0, _white);
    // картина слева
    _wallQuad(c, g, true, 2.2, 3.8, .9, 2.0, Colors.black);
    _wallQuad(c, g, true, 2.3, 3.7, 1.0, 1.9, const Color(0xFFF3E9D2));
    _wallQuad(c, g, true, 2.5, 2.9, 1.2, 1.7, const Color(0xFFE57373));
    _wallQuad(c, g, true, 3.0, 3.5, 1.1, 1.5, const Color(0xFF4DB6AC));
  }

  /// Мебель под сидящим и высота сиденья (в клетках).
  (Furniture, double)? _seatOf(String id, Offset p) {
    if (!sitting.contains(id)) return null;
    final f = furnAt(room, p.dx.floor(), p.dy.floor());
    final z = f == null ? null : furnCatalog[f.kind]?.seat;
    if (f == null || z == null) return null;
    return (f, z);
  }

  TextPainter _tp(String s, TextStyle st, {double maxW = 200, int lines = 1}) =>
      TextPainter(
        text: TextSpan(text: s, style: st),
        textDirection: TextDirection.ltr,
        maxLines: lines,
        ellipsis: '…',
      )..layout(maxWidth: maxW);

  @override
  void paint(Canvas canvas, Size size) {
    final g = IsoGeom(size);
    _shell(canvas, g, room.t);

    // ковры
    for (final f in room.furniture) {
      final s = furnCatalog[f.kind]!;
      if (s.walkable) _furn(canvas, g, s, f.x.toDouble(), f.y.toDouble());
    }

    // предпросмотр размещения
    if (placeKind != null && placeTile != null) {
      final s = furnCatalog[placeKind]!;
      final x = placeTile!.dx, y = placeTile!.dy;
      _poly(canvas, [g.p(x, y), g.p(x + s.w, y), g.p(x + s.w, y + s.d), g.p(x, y + s.d)],
          placeOk ? const Color(0x6600E676) : const Color(0x66FF1744));
    }

    // мебель и аватары по глубине
    final items = <(double, void Function())>[];
    for (final f in room.furniture) {
      final s = furnCatalog[f.kind]!;
      if (s.walkable) continue;
      items.add((f.x + s.w / 2 + f.y + s.d / 2, () => _furn(canvas, g, s, f.x.toDouble(), f.y.toDouble())));
    }
    for (final e in pos.entries) {
      final u = users[e.key];
      if (u == null) continue;
      final id = e.key;
      final seat = _seatOf(id, e.value);
      var depth = e.value.dx + e.value.dy + 0.001;
      if (seat != null) {
        final s = furnCatalog[seat.$1.kind]!;
        depth = seat.$1.x + s.w / 2 + seat.$1.y + s.d / 2 + 0.01;
      }
      items.add((depth, () {
        paintAvatar(
          canvas,
          u,
          g.p(e.value.dx, e.value.dy, seat?.$2 ?? 0),
          g.avatarK,
          t: t + (id.hashCode % 7) * .3,
          moving: moving.contains(id),
          emote: emotes[id],
          back: backFacing.contains(id),
          faceLeft: faceLeft.contains(id),
          sitting: seat != null,
          turned: true,
        );
      }));
    }
    items.sort((a, b) => a.$1.compareTo(b.$1));
    for (final it in items) {
      it.$2();
    }

    // подписи, эмоции, реплики
    for (final e in pos.entries) {
      final u = users[e.key];
      if (u == null) continue;
      final feet = g.p(e.value.dx, e.value.dy, _seatOf(e.key, e.value)?.$2 ?? 0);
      var y = feet.dy - (sitting.contains(e.key) ? 108 : 120) * g.avatarK - 4;
      final name = _tp(
        (u.isStaff ? '★ ' : '') + u.name,
        TextStyle(
          color: u.role == Role.admin
              ? const Color(0xFFFF8A80)
              : u.role == Role.moderator
                  ? const Color(0xFFA5D6A7)
                  : Colors.white,
          fontSize: 11,
          fontWeight: e.key == 'me' ? FontWeight.bold : FontWeight.w500,
        ),
        maxW: 110,
      );
      final nr = Rect.fromCenter(
        center: Offset(feet.dx, y - name.height / 2),
        width: name.width + 10,
        height: name.height + 3,
      );
      canvas.drawRRect(RRect.fromRectAndRadius(nr, const Radius.circular(8)),
          Paint()..color = const Color(0x99000000));
      name.paint(canvas, Offset(nr.left + 5, nr.top + 1.5));
      y = nr.top - 3;

      final b = bubbles[e.key];
      if (b != null) {
        final bt = _tp(b, const TextStyle(color: Colors.black87, fontSize: 11), maxW: 130, lines: 3);
        final br = Rect.fromLTWH(feet.dx - bt.width / 2 - 6, y - bt.height - 10, bt.width + 12, bt.height + 8);
        canvas.drawRRect(RRect.fromRectAndRadius(br, const Radius.circular(9)), Paint()..color = Colors.white);
        canvas.drawPath(
          Path()
            ..moveTo(feet.dx - 4, br.bottom)
            ..lineTo(feet.dx + 4, br.bottom)
            ..lineTo(feet.dx, br.bottom + 5)
            ..close(),
          Paint()..color = Colors.white,
        );
        bt.paint(canvas, Offset(br.left + 6, br.top + 4));
        y = br.top - 2;
      }
      final em = emotes[e.key];
      if (em != null) {
        final et = _tp(em, const TextStyle(fontSize: 24));
        et.paint(canvas, Offset(feet.dx - et.width / 2, y - et.height));
      }
    }
  }

  @override
  bool shouldRepaint(RoomPainter old) => true;
}
