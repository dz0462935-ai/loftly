import 'package:flutter/material.dart';

import '../clothes.dart';
import '../models.dart';
import '../store.dart';
import '../ui.dart';
import '../widgets/avatar.dart';
import '../widgets/iso.dart';
import 'lottery_screen.dart';

class _Cat {
  final String title;
  final IconData icon;
  final List<String> cats;
  const _Cat(this.title, this.icon, this.cats);
}

const _cats = <_Cat>[
  _Cat('Одежда', Icons.checkroom_rounded, ['top', 'bottom', 'shoes']),
  _Cat('Волосы', Icons.content_cut_rounded, ['hair', 'hairc']),
  _Cat('Шляпы', Icons.emoji_people_rounded, ['hat']),
  _Cat('Мебель', Icons.chair_rounded, ['furn']),
  _Cat('Темы', Icons.palette_rounded, ['theme']),
];

const _gemGradient = LinearGradient(colors: [Color(0xFF3DD9EB), Color(0xFF6C7BFF)]);

class ShopTab extends StatefulWidget {
  const ShopTab({super.key});

  @override
  State<ShopTab> createState() => _ShopTabState();
}

class _ShopTabState extends State<ShopTab> {
  int _cat = 0;

  @override
  void initState() {
    super.initState();
    // новые вещи из студии одежды появляются при каждом открытии магазина
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      context.getInheritedWidgetOfExactType<StoreScope>()?.notifier?.loadClothes();
    });
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final cat = _cats[_cat];
    final items = store.shop.where((i) => cat.cats.contains(i.cat)).toList();
    final showNoHat = cat.title == 'Шляпы';

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 120),
      children: [
        _WalletCard(store: store),
        if (store.api != null) ...[
          const SizedBox(height: 12),
          GlassCard(
            gradient: LinearGradient(colors: [Ui.a(Ui.cyan, .35), Ui.a(Ui.violet, .45)]),
            borderColor: Ui.a(Colors.white, .22),
            onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
              builder: (_) => LotteryScreen(store: store, api: store.api!),
            )),
            child: Row(
              children: [
                const Text('🎰', style: TextStyle(fontSize: 34)),
                const SizedBox(width: 14),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Капсулы удачи',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                      SizedBox(height: 2),
                      Text('Одежда, шляпы и мебель с шансом на редкость',
                          style: TextStyle(color: Ui.dim, fontSize: 12.5)),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right_rounded, size: 28),
              ],
            ),
          ),
        ],
        const SizedBox(height: 14),
        SizedBox(
          height: 42,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              for (var i = 0; i < _cats.length; i++)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    avatar: Icon(_cats[i].icon, size: 18),
                    label: Text(_cats[i].title),
                    selected: _cat == i,
                    showCheckmark: false,
                    onSelected: (_) => setState(() => _cat = i),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (showNoHat) ...[
          GlassCard(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            child: Row(
              children: [
                const Icon(Icons.not_interested_rounded, color: Ui.dim),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text('Без головного убора', style: TextStyle(fontWeight: FontWeight.w700)),
                ),
                if (store.me.hat == 0 && !store.me.custom.containsKey('hat'))
                  const Tag('Надето', color: Ui.green)
                else
                  FilledButton.tonal(
                    onPressed: store.removeHat,
                    style: FilledButton.styleFrom(minimumSize: const Size(64, 38)),
                    child: const Text('Снять'),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
        ],
        if (items.isEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 30),
            child: EmptyState(icon: Icons.inventory_2_outlined, title: 'Здесь пока ничего нет'),
          )
        else
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 0.74,
            ),
            itemCount: items.length,
            itemBuilder: (context, i) => _ItemCard(item: items[i]),
          ),
      ],
    );
  }
}

class _WalletCard extends StatelessWidget {
  final AppStore store;
  const _WalletCard({required this.store});

  @override
  Widget build(BuildContext context) {
    final me = store.me;
    return GlassCard(
      padding: const EdgeInsets.all(16),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Ui.a(Ui.violet, .5), Ui.a(Ui.accent, .32)],
      ),
      borderColor: Ui.a(Colors.white, .22),
      child: Row(
        children: [
          Container(
            width: 84,
            height: 104,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              color: Ui.a(Colors.black, .22),
            ),
            alignment: Alignment.center,
            child: AvatarFigure(user: me, size: 72),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Баланс', style: TextStyle(color: Ui.dim, fontSize: 12)),
                const SizedBox(height: 4),
                Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  children: [
                    CurrencyPill(emoji: '🪙', value: me.coins),
                    CurrencyPill(emoji: '💎', value: me.gems),
                  ],
                ),
                const SizedBox(height: 12),
                GradientButton(
                  height: 44,
                  gradient: Ui.goldGrad,
                  icon: Icons.card_giftcard_rounded,
                  label: store.dailyReady ? 'Бонус дня' : 'Серия: ${store.streak} дн.',
                  onPressed: store.dailyReady ? store.claimDaily : null,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ItemCard extends StatelessWidget {
  final ShopItem item;
  const _ItemCard({required this.item});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final isFurn = item.cat == 'furn';
    final owned = !isFurn && store.owns(item);
    final equipped = owned && item.cat != 'theme' && store.isEquipped(item);

    Widget action;
    if (isFurn) {
      action = _buyButton(store);
    } else if (owned) {
      if (item.cat == 'theme') {
        action = const _StateButton(label: 'Куплено', done: true);
      } else if (equipped) {
        action = const _StateButton(label: 'Надето', done: true);
      } else {
        action = _StateButton(label: 'Надеть', onTap: () => store.equip(item));
      }
    } else {
      action = _buyButton(store);
    }

    return GlassCard(
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
      borderColor: equipped ? Ui.a(Ui.green, .8) : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Ui.a(Colors.white, .10), Ui.a(Colors.white, .03)],
                ),
              ),
              child: Stack(
                children: [
                  Center(child: _ItemArt(item: item)),
                  if (item.gems)
                    const Positioned(top: 6, right: 6, child: Tag('Редкое', color: Ui.cyan)),
                  if (item.custom)
                    const Positioned(top: 6, left: 6, child: Tag('Новинка', color: Ui.accent)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            item.name,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13, height: 1.15),
          ),
          if (isFurn)
            Text(
              'На складе: ${store.furnInv[item.id.substring(5)] ?? 0}',
              style: const TextStyle(color: Ui.dim, fontSize: 11.5),
            ),
          const SizedBox(height: 8),
          action,
        ],
      ),
    );
  }

  Widget _buyButton(AppStore store) {
    return GradientButton(
      height: 40,
      gradient: item.gems ? _gemGradient : Ui.goldGrad,
      label: '${item.price} ${item.gems ? '💎' : '🪙'}',
      onPressed: () => store.buy(item),
    );
  }
}

class _StateButton extends StatelessWidget {
  final String label;
  final bool done;
  final VoidCallback? onTap;
  const _StateButton({required this.label, this.done = false, this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 40,
      child: done
          ? Container(
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Ui.a(Ui.green, .2),
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: Ui.a(Ui.green, .6)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.check_rounded, size: 18, color: Ui.green),
                  const SizedBox(width: 4),
                  Text(label, style: const TextStyle(fontWeight: FontWeight.w800, color: Ui.green)),
                ],
              ),
            )
          : FilledButton.tonal(
              onPressed: onTap,
              style: FilledButton.styleFrom(minimumSize: const Size(64, 40)),
              child: Text(label),
            ),
    );
  }
}

/// Картинка предмета в карточке магазина.
class _ItemArt extends StatelessWidget {
  final ShopItem item;
  const _ItemArt({required this.item});

  @override
  Widget build(BuildContext context) {
    if (item.custom) return ClothThumb(id: item.id, slot: item.cat, size: 72);
    switch (item.cat) {
      case 'furn':
        return Text(furnCatalog[item.id.substring(5)]!.emoji, style: const TextStyle(fontSize: 52));
      case 'theme':
        final t = roomThemes[item.index];
        return Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Ui.a(Colors.white, .3), width: 2),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [t.wall, t.wall, t.floorA, t.floorA],
              stops: const [0, .5, .5, 1],
            ),
          ),
        );
      case 'hair':
        return Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(shape: BoxShape.circle, color: Ui.a(Colors.white, .1)),
          child: const Icon(Icons.face_retouching_natural_rounded, size: 38),
        );
      case 'hairc':
        return Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: item.color ?? Colors.brown,
            border: Border.all(color: Ui.a(Colors.white, .5), width: 2),
          ),
          child: const Icon(Icons.content_cut_rounded, size: 26, color: Colors.white70),
        );
      case 'hat':
        return const Text('🎩', style: TextStyle(fontSize: 48));
      default:
        return CustomPaint(
          size: const Size(64, 64),
          painter: _GarmentPainter(item.cat, item.color ?? Colors.grey),
        );
    }
  }
}

class _GarmentPainter extends CustomPainter {
  final String kind;
  final Color color;
  _GarmentPainter(this.kind, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 60, size.height / 60);
    final path = Path();
    switch (kind) {
      case 'top':
        path
          ..moveTo(18, 8)
          ..quadraticBezierTo(30, 20, 42, 8)
          ..lineTo(56, 18)
          ..lineTo(49, 29)
          ..lineTo(42, 25)
          ..lineTo(42, 54)
          ..lineTo(18, 54)
          ..lineTo(18, 25)
          ..lineTo(11, 29)
          ..lineTo(4, 18)
          ..close();
        break;
      case 'bottom':
        path
          ..moveTo(14, 6)
          ..lineTo(46, 6)
          ..lineTo(49, 54)
          ..lineTo(34, 54)
          ..lineTo(30, 22)
          ..lineTo(26, 54)
          ..lineTo(11, 54)
          ..close();
        break;
      default:
        path
          ..moveTo(6, 30)
          ..lineTo(6, 18)
          ..lineTo(22, 18)
          ..lineTo(28, 30)
          ..lineTo(50, 34)
          ..quadraticBezierTo(56, 36, 55, 44)
          ..lineTo(55, 48)
          ..lineTo(6, 48)
          ..close();
    }
    canvas.drawPath(path.shift(const Offset(1.5, 2.5)), Paint()..color = const Color(0x33000000));
    canvas.drawPath(path, Paint()..color = color);
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6
        ..strokeJoin = StrokeJoin.round
        ..color = const Color(0x55FFFFFF),
    );
    if (kind == 'shoes') {
      canvas.drawRect(
        const Rect.fromLTWH(6, 44, 49, 4),
        Paint()..color = const Color(0xCCFFFFFF),
      );
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _GarmentPainter old) => old.kind != kind || old.color != color;
}
